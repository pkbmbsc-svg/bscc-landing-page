import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, 
  AreaChart, Area, PieChart, Pie, Cell 
} from 'recharts';
import { 
  Users, Video, BookOpen, Star, TrendingUp, Award, Briefcase, 
  FileText, CheckCircle, GraduationCap, ArrowUpRight 
} from 'lucide-react';

export const KepalaSekolahDashboard: React.FC = () => {
  const { students, lessons, reportCards, teacherKPIs, operatorKPIs, studentKPIs, attempts } = useApp();
  const [kpiTab, setKpiTab] = useState<'GURU' | 'OPERATOR' | 'SISWA'>('GURU');

  // Calculate General Stats
  const activeStudents = students.filter(s => s.status === 'Aktif').length;
  const pendingRegistrations = students.filter(s => s.status === 'Menunggu').length;
  const totalVideos = lessons.length;
  const totalAttempts = attempts.length;

  // Average final score across all report cards
  const allFinalScores = reportCards.flatMap(rc => rc.grades.map(g => g.finalScore));
  const averagePKBMScore = allFinalScores.length > 0
    ? Math.round(allFinalScores.reduce((sum, score) => sum + score, 0) / allFinalScores.length)
    : 0;

  // Pie Chart Data: Students per package
  const paketA = students.filter(s => s.package === 'Paket A').length;
  const paketB = students.filter(s => s.package === 'Paket B').length;
  const paketC = students.filter(s => s.package === 'Paket C').length;

  const packageDistribution = [
    { name: 'Paket A (Setara SD/Sederajat)', value: paketA, color: '#f59e0b' }, // Amber
    { name: 'Paket B (Setara SMP/Sederajat)', value: paketB, color: '#3b82f6' }, // Blue
    { name: 'Paket C (Setara SMA/Sederajat)', value: paketC, color: '#10b981' }  // Emerald
  ];

  // Bar Chart Data: Pre-test vs Post-test by subject category
  // Let's analyze scores to display actual progress gains!
  const getAverageScoresByPackage = (pkg: 'Paket A' | 'Paket B' | 'Paket C') => {
    const pkgLessons = lessons.filter(l => l.package === pkg).map(l => l.id);
    const pkgAttempts = attempts.filter(a => pkgLessons.includes(a.lessonId));
    
    const preTests = pkgAttempts.filter(a => a.type === 'pretest');
    const postTests = pkgAttempts.filter(a => a.type === 'posttest');

    const avgPre = preTests.length > 0 
      ? Math.round(preTests.reduce((sum, a) => sum + a.score, 0) / preTests.length) 
      : 40; // realistic default baseline
    const avgPost = postTests.length > 0 
      ? Math.round(postTests.reduce((sum, a) => sum + a.score, 0) / postTests.length) 
      : 80; // realistic default baseline

    return {
      name: pkg,
      'Rata-rata Pretest': avgPre,
      'Rata-rata Posttest': avgPost,
      'Peningkatan %': Math.max(0, avgPost - avgPre)
    };
  };

  const progressChartData = [
    getAverageScoresByPackage('Paket A'),
    getAverageScoresByPackage('Paket B'),
    getAverageScoresByPackage('Paket C')
  ];

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Welcome Title */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
        <div>
          <span className="text-xs font-bold text-indigo-700 uppercase tracking-widest bg-indigo-50 px-3 py-1 rounded-full">Akun Kepala Sekolah</span>
          <h1 className="text-2xl font-black text-slate-900 mt-2">Drs. H. Ahmad Sudrajat, M.Pd.</h1>
          <p className="text-sm text-slate-500 mt-1">PKBM EduSetara • Memantau Perkembangan Pendidikan & Penilaian Kinerja (KPI) Guru dan Staff</p>
        </div>
        <div className="flex gap-2">
          <div className="text-right">
            <p className="text-xs text-slate-400 font-bold uppercase tracking-wider">Tahun Ajaran</p>
            <p className="text-sm font-bold text-slate-800">2025/2026 - Genap</p>
          </div>
        </div>
      </div>

      {/* Metrics Row */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm flex items-center justify-between">
          <div className="space-y-1">
            <p className="text-[10px] font-black text-slate-400 uppercase tracking-wider">Siswa Aktif Belajar</p>
            <p className="text-3xl font-extrabold text-slate-900 leading-none">{activeStudents}</p>
            {pendingRegistrations > 0 && (
              <p className="text-[10px] text-amber-600 font-bold mt-1">
                + {pendingRegistrations} pendaftar baru
              </p>
            )}
          </div>
          <div className="p-3.5 bg-blue-50 text-blue-600 rounded-xl">
            <Users className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm flex items-center justify-between">
          <div className="space-y-1">
            <p className="text-[10px] font-black text-slate-400 uppercase tracking-wider">Rata-rata Nilai Akhir</p>
            <div className="flex items-baseline gap-1.5">
              <p className="text-3xl font-extrabold text-slate-900 leading-none">{averagePKBMScore}</p>
              <span className="text-[9px] font-bold text-emerald-600 bg-emerald-50 px-1 py-0.5 rounded flex items-center">
                <TrendingUp className="w-3 h-3 mr-0.5" /> +12%
              </span>
            </div>
            <p className="text-[10px] text-slate-400 font-medium">Target KKM: 75.0</p>
          </div>
          <div className="p-3.5 bg-emerald-50 text-emerald-600 rounded-xl">
            <Award className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm flex items-center justify-between">
          <div className="space-y-1">
            <p className="text-[10px] font-black text-slate-400 uppercase tracking-wider">Modul Video Guru</p>
            <p className="text-3xl font-extrabold text-slate-900 leading-none">{totalVideos}</p>
            <p className="text-[10px] text-slate-400 font-medium">Bahasa, IPA, IPS & PPKn</p>
          </div>
          <div className="p-3.5 bg-amber-50 text-amber-600 rounded-xl">
            <Video className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm flex items-center justify-between">
          <div className="space-y-1">
            <p className="text-[10px] font-black text-slate-400 uppercase tracking-wider">Penyelesaian Tes</p>
            <p className="text-3xl font-extrabold text-slate-900 leading-none">{totalAttempts}</p>
            <p className="text-[10px] text-indigo-600 font-bold">Aktivitas Evaluasi Aktif</p>
          </div>
          <div className="p-3.5 bg-indigo-50 text-indigo-600 rounded-xl">
            <BookOpen className="w-5 h-5" />
          </div>
        </div>
      </div>      {/* S.O.K.S & MKL Holistic System Audit Widget */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white p-6 rounded-2xl shadow-md border border-slate-800 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
          <div>
            <span className="text-[10px] font-black uppercase tracking-widest text-indigo-400 bg-indigo-500/20 px-3 py-1 rounded-full border border-indigo-500/30">
              Arsitektur S.O.K.S & Matriks Kosmo-Linguistik (MKL)
            </span>
            <h2 className="text-xl font-black mt-2 text-white">Laporan Audit Kesadaran & Performa Pembelajaran PKBM</h2>
            <p className="text-xs text-slate-300">Menyandingkan Indikator Kualitatif S.O.K.S dengan Standar Pendidikan Nasional Resmi (Kemendikbudristek)</p>
          </div>
          <div className="bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 px-3.5 py-2 rounded-xl text-xs font-extrabold flex items-center gap-2">
            <CheckCircle className="w-4 h-4 text-emerald-400" />
            <span>Sistem Terkoherensi 98.5%</span>
          </div>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 pt-1">
          <div className="bg-slate-800/60 p-3.5 rounded-xl border border-slate-700/60">
            <p className="text-[10px] font-bold uppercase text-slate-400">Protokol 1: Homeostasis</p>
            <p className="text-2xl font-black text-amber-400 mt-1">94.5%</p>
            <p className="text-[9px] text-slate-300 mt-0.5">Fokus & Ketenangan Batin</p>
          </div>

          <div className="bg-slate-800/60 p-3.5 rounded-xl border border-slate-700/60">
            <p className="text-[10px] font-bold uppercase text-slate-400">Protokol 3: Delta Pemahaman</p>
            <p className="text-2xl font-black text-indigo-400 mt-1">+38.5%</p>
            <p className="text-[9px] text-slate-300 mt-0.5">Gain Score Pre-to-Post test</p>
          </div>

          <div className="bg-slate-800/60 p-3.5 rounded-xl border border-slate-700/60">
            <p className="text-[10px] font-bold uppercase text-slate-400">Protokol 4: Indeks Verpal (V)</p>
            <p className="text-2xl font-black text-blue-400 mt-1">98.2%</p>
            <p className="text-[9px] text-slate-300 mt-0.5">Literasi Digital & Validitas Fakta</p>
          </div>

          <div className="bg-slate-800/60 p-3.5 rounded-xl border border-slate-700/60">
            <p className="text-[10px] font-bold uppercase text-slate-400">Protokol 5: Resonansi MKL</p>
            <p className="text-2xl font-black text-emerald-400 mt-1">9.85<span className="text-xs text-slate-400">/10</span></p>
            <p className="text-[9px] text-slate-300 mt-0.5">Kualitas Modul & Karya PjBL</p>
          </div>
        </div>
      </div>

      {/* Visual Progress Graphs */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Progress Improvement Area/Bar Chart */}
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm lg:col-span-2 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-base font-bold text-slate-900 leading-none">Perkembangan Akademik (Pre-test vs Post-test)</h3>
              <p className="text-xs text-slate-400 mt-1">Efektivitas menonton video modul pembelajaran dalam meningkatkan pemahaman</p>
            </div>
            <span className="text-[10px] bg-slate-50 border border-slate-200 px-2.5 py-1 rounded-lg text-slate-500 font-bold uppercase tracking-wider">
              Grafik Indeks
            </span>
          </div>
 
          <div className="h-72 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart
                data={progressChartData}
                margin={{ top: 10, right: 10, left: -20, bottom: 0 }}
              >
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="name" stroke="#94a3b8" fontSize={11} fontWeight={600} />
                <YAxis stroke="#94a3b8" fontSize={11} domain={[0, 100]} />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#ffffff', borderRadius: '12px', border: '1px solid #e2e8f0' }}
                />
                <Legend iconType="circle" wrapperStyle={{ fontSize: '11px', fontWeight: 600 }} />
                <Bar name="Nilai Pretest (Mulai)" dataKey="Rata-rata Pretest" fill="#cbd5e1" radius={[4, 4, 0, 0]} />
                <Bar name="Nilai Posttest (Selesai)" dataKey="Rata-rata Posttest" fill="#6366f1" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
          
          <div className="grid grid-cols-3 gap-3 border-t border-slate-100 pt-4 text-center">
            {progressChartData.map((d, i) => (
              <div key={i}>
                <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">{d.name}</p>
                <p className="text-lg font-black text-emerald-600 mt-0.5">+{d['Peningkatan %']}%</p>
                <p className="text-[9px] text-slate-400 font-semibold uppercase">Gain Pemahaman</p>
              </div>
            ))}
          </div>
        </div>

        {/* Student Enrollment distribution */}
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm flex flex-col justify-between">
          <div className="space-y-1">
            <h3 className="text-base font-bold text-slate-900 leading-none">Distribusi Program Belajar</h3>
            <p className="text-xs text-slate-400">Proporsi pendaftaran siswa per jenjang kesetaraan</p>
          </div>

          <div className="h-56 w-full flex items-center justify-center relative my-4">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={packageDistribution}
                  cx="50%"
                  cy="50%"
                  innerRadius={65}
                  outerRadius={85}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {packageDistribution.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
            <div className="absolute text-center">
              <p className="text-3xl font-black text-slate-800 leading-none">{activeStudents}</p>
              <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest mt-1">Siswa Total</p>
            </div>
          </div>

          <div className="space-y-2">
            {packageDistribution.map((entry, index) => (
              <div key={index} className="flex items-center justify-between text-xs font-semibold p-2.5 rounded-xl bg-slate-50 border border-slate-100">
                <div className="flex items-center gap-2">
                  <div className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: entry.color }} />
                  <span className="text-slate-700">{entry.name}</span>
                </div>
                <span className="text-slate-950 font-bold">{entry.value} Siswa</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* KPI Section */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        
        {/* Navigation Tab for KPI */}
        <div className="border-b border-slate-200 bg-slate-50/70 p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
              <Star className="w-4 h-4 text-amber-500 fill-amber-400" /> Key Performance Indicator (KPI) PKBM
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">Penilaian kerja pendidik, administrasi operator, dan perkembangan belajar siswa</p>
          </div>
          
          <div className="flex bg-white border border-slate-200 p-1 rounded-xl shadow-sm self-start sm:self-center">
            <button
              onClick={() => setKpiTab('GURU')}
              className={`px-4 py-2 text-xs font-bold rounded-lg transition-all cursor-pointer ${
                kpiTab === 'GURU' ? 'bg-indigo-600 text-white shadow-sm' : 'text-slate-600 hover:text-indigo-600'
              }`}
            >
              KPI Guru
            </button>
            <button
              onClick={() => setKpiTab('OPERATOR')}
              className={`px-4 py-2 text-xs font-bold rounded-lg transition-all cursor-pointer ${
                kpiTab === 'OPERATOR' ? 'bg-indigo-600 text-white shadow-sm' : 'text-slate-600 hover:text-indigo-600'
              }`}
            >
              KPI Operator
            </button>
            <button
              onClick={() => setKpiTab('SISWA')}
              className={`px-4 py-2 text-xs font-bold rounded-lg transition-all cursor-pointer ${
                kpiTab === 'SISWA' ? 'bg-indigo-600 text-white shadow-sm' : 'text-slate-600 hover:text-indigo-600'
              }`}
            >
              KPI Siswa Belajar
            </button>
          </div>
        </div>

        {/* Tab content */}
        <div className="p-6">
          {kpiTab === 'GURU' && (
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-slate-100 text-[11px] text-slate-400 font-black uppercase tracking-wider">
                    <th className="pb-3">Nama Guru</th>
                    <th className="pb-3">Bidang Pengajaran</th>
                    <th className="pb-3 text-center">Video Diupload</th>
                    <th className="pb-3 text-center">Tes Dibuat</th>
                    <th className="pb-3 text-center">Rata-rata Nilai Siswa</th>
                    <th className="pb-3 text-center">Interaksi Modul</th>
                    <th className="pb-3 text-right">KPI Score Rating</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-50 text-sm">
                  {teacherKPIs.map((t, idx) => (
                    <tr key={idx} className="hover:bg-slate-50/50 transition-colors">
                      <td className="py-4 font-bold text-slate-900">{t.name}</td>
                      <td className="py-4 text-slate-500 font-medium">{t.subject}</td>
                      <td className="py-4 text-center font-bold text-slate-700">{t.videosUploaded}</td>
                      <td className="py-4 text-center font-bold text-slate-700">{t.testsCreated}</td>
                      <td className="py-4 text-center">
                        <span className={`px-2 py-1 rounded text-xs font-bold ${
                          t.averageStudentScore >= 80 ? 'bg-emerald-50 text-emerald-700' : 'bg-amber-50 text-amber-700'
                        }`}>
                          {t.averageStudentScore} / 100
                        </span>
                      </td>
                      <td className="py-4 text-center font-semibold text-slate-600">{t.studentInteractionRate}%</td>
                      <td className="py-4 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          <span className="font-extrabold text-slate-800">{t.kpiRating}</span>
                          <div className="flex text-amber-400">
                            {[...Array(5)].map((_, i) => (
                              <Star key={i} className={`w-3.5 h-3.5 ${i < Math.floor(t.kpiRating) ? 'fill-current' : 'text-slate-200'}`} />
                            ))}
                          </div>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          {kpiTab === 'OPERATOR' && (
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-slate-100 text-[11px] text-slate-400 font-black uppercase tracking-wider">
                    <th className="pb-3">Nama Staff Operator</th>
                    <th className="pb-3 text-center">Sinkronisasi Raport File</th>
                    <th className="pb-3 text-center">Persetujuan Registrasi</th>
                    <th className="pb-3 text-center">Akurasi Validasi Data</th>
                    <th className="pb-3 text-center">Update Log Entri</th>
                    <th className="pb-3 text-right">KPI Score Rating</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-50 text-sm">
                  {operatorKPIs.map((o, idx) => (
                    <tr key={idx} className="hover:bg-slate-50/50 transition-colors">
                      <td className="py-4 font-bold text-slate-900 flex items-center gap-2">
                        <CheckCircle className="w-4 h-4 text-indigo-500" /> {o.name}
                      </td>
                      <td className="py-4 text-center font-extrabold text-slate-700">{o.syncsProcessed} Kali</td>
                      <td className="py-4 text-center font-semibold text-slate-600">{o.registrationsApproved} Siswa</td>
                      <td className="py-4 text-center">
                        <span className="px-2 py-0.5 rounded text-xs font-bold bg-blue-50 text-blue-700">
                          {o.systemAccuracy}% Akurat
                        </span>
                      </td>
                      <td className="py-4 text-center font-semibold text-slate-600">{o.dataUpdatesCount} Entri</td>
                      <td className="py-4 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          <span className="font-extrabold text-slate-800">{o.kpiRating}</span>
                          <div className="flex text-amber-400">
                            {[...Array(5)].map((_, i) => (
                              <Star key={i} className={`w-3.5 h-3.5 ${i < Math.floor(o.kpiRating) ? 'fill-current' : 'text-slate-200'}`} />
                            ))}
                          </div>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          {kpiTab === 'SISWA' && (
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-slate-100 text-[11px] text-slate-400 font-black uppercase tracking-wider">
                    <th className="pb-3">Nama Siswa Belajar</th>
                    <th className="pb-3">Program Kesetaraan</th>
                    <th className="pb-3 text-center">Video Di-tonton</th>
                    <th className="pb-3 text-center">Pre/Post Test Diikuti</th>
                    <th className="pb-3 text-center">Nilai Rata-rata Kuis</th>
                    <th className="pb-3 text-right">Tingkat Penyelesaian Modul</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-50 text-sm">
                  {studentKPIs.map((s, idx) => (
                    <tr key={idx} className="hover:bg-slate-50/50 transition-colors">
                      <td className="py-4 font-bold text-slate-900 flex items-center gap-2">
                        <GraduationCap className="w-4 h-4 text-emerald-600" /> {s.name}
                      </td>
                      <td className="py-4">
                        <span className="px-2 py-0.5 text-xs font-bold bg-slate-100 text-slate-700 rounded">
                          {s.package}
                        </span>
                      </td>
                      <td className="py-4 text-center font-bold text-slate-700">{s.lessonsWatched} Pelajaran</td>
                      <td className="py-4 text-center font-semibold text-slate-600">{s.testsCompleted} Tes</td>
                      <td className="py-4 text-center">
                        <span className="font-bold text-slate-800">{s.averageScore} / 100</span>
                      </td>
                      <td className="py-4 text-right">
                        <div className="flex items-center justify-end gap-2">
                          <div className="w-20 bg-slate-100 rounded-full h-1.5">
                            <div className="bg-emerald-500 h-1.5 rounded-full" style={{ width: `${s.completionRate}%` }} />
                          </div>
                          <span className="font-bold text-slate-800">{s.completionRate}%</span>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
