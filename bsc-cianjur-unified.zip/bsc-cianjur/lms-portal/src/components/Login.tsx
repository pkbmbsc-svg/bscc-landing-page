import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Role } from '../types';
import { LogIn, UserPlus, GraduationCap, ShieldAlert, Award, Briefcase, BookOpen, UserCheck } from 'lucide-react';
import { motion } from 'motion/react';

export const Login: React.FC = () => {
  const { login, users, addStudent } = useApp();
  const [isRegister, setIsRegister] = useState(false);
  
  // Login states
  const [selectedUserId, setSelectedUserId] = useState(users[0]?.id || '');
  
  // Registration states
  const [regName, setRegName] = useState('');
  const [regEmail, setRegEmail] = useState('');
  const [regPackage, setRegPackage] = useState<'Paket A' | 'Paket B' | 'Paket C'>('Paket C');
  const [regGender, setRegGender] = useState<'Laki-laki' | 'Perempuan'>('Laki-laki');
  const [regSuccess, setRegSuccess] = useState(false);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    login(selectedUserId);
  };

  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault();
    if (!regName || !regEmail) return;
    
    addStudent({
      name: regName,
      email: regEmail,
      package: regPackage,
      gender: regGender
    });
    
    setRegSuccess(true);
    setTimeout(() => {
      setRegSuccess(false);
      setIsRegister(false);
      // Auto-select the newly created student account
      const allUsers = JSON.parse(localStorage.getItem('es_users') || '[]');
      const newlyAdded = allUsers.find((u: any) => u.email === regEmail);
      if (newlyAdded) {
        setSelectedUserId(newlyAdded.id);
      }
    }, 2000);
    
    // Reset form
    setRegName('');
    setRegEmail('');
  };

  const getRoleBadge = (role: Role) => {
    switch(role) {
      case 'KEPALA_SEKOLAH':
        return <span className="inline-flex items-center gap-1 text-xs font-semibold px-2.5 py-1 rounded-full bg-rose-50 text-rose-700 border border-rose-200"><ShieldAlert className="w-3.5 h-3.5" /> Kepala Sekolah</span>;
      case 'OPERATOR':
        return <span className="inline-flex items-center gap-1 text-xs font-semibold px-2.5 py-1 rounded-full bg-blue-50 text-blue-700 border border-blue-200"><Briefcase className="w-3.5 h-3.5" /> Operator</span>;
      case 'GURU':
        return <span className="inline-flex items-center gap-1 text-xs font-semibold px-2.5 py-1 rounded-full bg-amber-50 text-amber-700 border border-amber-200"><Award className="w-3.5 h-3.5" /> Guru Pengajar</span>;
      case 'SISWA':
        return <span className="inline-flex items-center gap-1 text-xs font-semibold px-2.5 py-1 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200"><BookOpen className="w-3.5 h-3.5" /> Siswa Belajar</span>;
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col justify-center py-12 sm:px-6 lg:px-8">
      <div className="sm:mx-auto sm:w-full sm:max-w-md text-center">
        <div className="inline-flex items-center justify-center p-3 bg-indigo-600 rounded-2xl text-white shadow-xl shadow-indigo-100 mb-4">
          <GraduationCap className="w-10 h-10" />
        </div>
        <h2 className="text-3xl font-extrabold text-slate-900 tracking-tight">BSC EduSetara</h2>
        <p className="mt-2 text-sm text-slate-600 max-w">
          Portal Administrasi & Pembelajaran Kesetaraan Paket A, B, & C
        </p>
      </div>

      <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-lg">
        <div className="bg-white py-8 px-6 shadow-sm border border-slate-100 rounded-2xl sm:px-10">
          
          {/* Toggle Tab */}
          <div className="flex bg-slate-100 p-1 rounded-xl mb-8">
            <button
              onClick={() => setIsRegister(false)}
              className={`flex-1 py-2 text-sm font-medium rounded-lg transition-all ${!isRegister ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600 hover:text-slate-900'}`}
            >
              Multi Login Akun
            </button>
            <button
              onClick={() => setIsRegister(true)}
              className={`flex-1 py-2 text-sm font-medium rounded-lg transition-all ${isRegister ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600 hover:text-slate-900'}`}
            >
              Pendaftaran Siswa Baru
            </button>
          </div>

          {!isRegister ? (
            /* Login Form */
            <form className="space-y-6" onSubmit={handleLogin}>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">
                  Pilih Akun Pengguna Demo
                </label>
                <div className="space-y-3 max-h-80 overflow-y-auto pr-1">
                  {users.map((u) => (
                    <div
                      key={u.id}
                      onClick={() => setSelectedUserId(u.id)}
                      className={`flex items-center justify-between p-3.5 rounded-xl border-2 cursor-pointer transition-all ${
                        selectedUserId === u.id
                          ? 'border-indigo-600 bg-indigo-50/40 shadow-sm'
                          : 'border-slate-100 bg-white hover:border-slate-200'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <img
                          src={u.avatar || "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150"}
                          alt={u.name}
                          className="w-10 h-10 rounded-full object-cover border border-slate-200"
                        />
                        <div className="text-left">
                          <p className="text-sm font-semibold text-slate-900">{u.name}</p>
                          <p className="text-xs text-slate-500 font-mono">{u.email}</p>
                        </div>
                      </div>
                      <div className="flex flex-col items-end gap-1.5">
                        {getRoleBadge(u.role)}
                        {u.package && (
                          <span className="text-[10px] font-bold bg-slate-100 text-slate-700 px-2 py-0.5 rounded">
                            {u.package}
                          </span>
                        )}
                        {u.subject && (
                          <span className="text-[10px] font-bold bg-slate-100 text-slate-700 px-2 py-0.5 rounded">
                            {u.subject}
                          </span>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <button
                  type="submit"
                  className="w-full flex justify-center items-center gap-2 py-3 px-4 border border-transparent rounded-xl shadow-sm text-sm font-semibold text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition-all cursor-pointer"
                >
                  <LogIn className="w-4 h-4" /> Masuk ke Sistem Portal
                </button>
              </div>
            </form>
          ) : (
            /* Register Form */
            <form className="space-y-5" onSubmit={handleRegister}>
              {regSuccess && (
                <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200 flex items-center gap-2.5 text-emerald-800 text-sm">
                  <UserCheck className="w-5 h-5 text-emerald-600 flex-shrink-0" />
                  <div>
                    <span className="font-bold">Pendaftaran Berhasil!</span> Akun siswa baru terdaftar. Menunggu persetujuan Operator.
                  </div>
                </div>
              )}

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">
                  Nama Lengkap Siswa
                </label>
                <input
                  type="text"
                  required
                  placeholder="Contoh: Rian Hidayat"
                  value={regName}
                  onChange={(e) => setRegName(e.target.value)}
                  className="w-full px-4 py-2.5 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 text-sm outline-none bg-slate-50/50"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">
                  Email Aktif
                </label>
                <input
                  type="email"
                  required
                  placeholder="Contoh: rian.hidayat@gmail.com"
                  value={regEmail}
                  onChange={(e) => setRegEmail(e.target.value)}
                  className="w-full px-4 py-2.5 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 text-sm outline-none bg-slate-50/50"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">
                    Program Paket
                  </label>
                  <select
                    value={regPackage}
                    onChange={(e) => setRegPackage(e.target.value as any)}
                    className="w-full px-3 py-2.5 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 text-sm bg-white"
                  >
                    <option value="Paket A">Paket A (Setara SD)</option>
                    <option value="Paket B">Paket B (Setara SMP)</option>
                    <option value="Paket C">Paket C (Setara SMA)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">
                    Jenis Kelamin
                  </label>
                  <select
                    value={regGender}
                    onChange={(e) => setRegGender(e.target.value as any)}
                    className="w-full px-3 py-2.5 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 text-sm bg-white"
                  >
                    <option value="Laki-laki">Laki-laki</option>
                    <option value="Perempuan">Perempuan</option>
                  </select>
                </div>
              </div>

              <div className="pt-2">
                <button
                  type="submit"
                  disabled={regSuccess}
                  className="w-full flex justify-center items-center gap-2 py-3 px-4 border border-transparent rounded-xl shadow-sm text-sm font-semibold text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition-all cursor-pointer disabled:opacity-55"
                >
                  <UserPlus className="w-4 h-4" /> Daftar Akun Baru
                </button>
              </div>
            </form>
          )}

          <div className="mt-6 border-t border-slate-100 pt-4 text-center">
            <span className="text-xs text-slate-400">
              Sistem ini sepenuhnya berjalan lokal & terproteksi demi keamanan data PKBM.
            </span>
          </div>

        </div>
      </div>
    </div>
  );
};
