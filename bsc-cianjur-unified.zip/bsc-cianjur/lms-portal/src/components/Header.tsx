import React from 'react';
import { useApp } from '../context/AppContext';
import { Role } from '../types';
import { 
  LogOut, ShieldAlert, Briefcase, Award, BookOpen 
} from 'lucide-react';

export const Header: React.FC = () => {
  const { currentUser, logout } = useApp();

  const getRoleIcon = (role: Role) => {
    switch (role) {
      case 'KEPALA_SEKOLAH':
        return <ShieldAlert className="w-4 h-4 text-rose-600" />;
      case 'OPERATOR':
        return <Briefcase className="w-4 h-4 text-blue-600" />;
      case 'GURU':
        return <Award className="w-4 h-4 text-amber-600" />;
      case 'SISWA':
        return <BookOpen className="w-4 h-4 text-emerald-600" />;
    }
  };

  const getRoleColor = (role: Role) => {
    switch (role) {
      case 'KEPALA_SEKOLAH': return 'bg-rose-50 border-rose-100 text-rose-700';
      case 'OPERATOR': return 'bg-blue-50 border-blue-100 text-blue-700';
      case 'GURU': return 'bg-amber-50 border-amber-100 text-amber-700';
      case 'SISWA': return 'bg-emerald-50 border-emerald-100 text-emerald-700';
    }
  };

  const getRoleNameInIndonesian = (role: Role) => {
    switch (role) {
      case 'KEPALA_SEKOLAH': return 'Kepala Sekolah';
      case 'OPERATOR': return 'Operator PKBM';
      case 'GURU': return 'Guru Pengajar';
      case 'SISWA': return 'Siswa Belajar';
    }
  };

  return (
    <div className="print:hidden">
      {/* Main Branding Navigation bar */}
      <header className="bg-white border border-slate-200 px-6 py-4 flex items-center justify-between shadow-sm rounded-2xl">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 bg-indigo-600 rounded-lg flex items-center justify-center shadow-md shadow-indigo-100">
            <span className="text-white font-black text-lg">B</span>
          </div>
          <div className="text-left">
            <span className="text-[10px] font-bold tracking-wider text-indigo-600 uppercase">BSC EduSetara PKBM</span>
            <h1 className="text-base font-black text-slate-900 tracking-tight leading-tight">Portal Kesetaraan Nasional</h1>
          </div>
        </div>

        {currentUser && (
          <div className="flex items-center gap-4">
            {/* Active profile badge */}
            <div className="hidden sm:flex items-center gap-2.5 px-3 py-1.5 border border-slate-200 rounded-xl bg-slate-50/50">
              <div className="text-right">
                <p className="text-xs font-bold text-slate-900">{currentUser.name}</p>
                <p className="text-[9px] text-slate-400 font-mono font-medium">{currentUser.email}</p>
              </div>
              <img
                src={currentUser.avatar || "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150"}
                alt={currentUser.name}
                className="w-8 h-8 rounded-lg object-cover border border-slate-200"
              />
            </div>

            {/* Role indicator badge */}
            <span className={`px-3.5 py-1.5 rounded-xl border text-xs font-bold flex items-center gap-1.5 ${getRoleColor(currentUser.role)}`}>
              {getRoleIcon(currentUser.role)}
              {getRoleNameInIndonesian(currentUser.role)}
            </span>

            {/* Logout Button */}
            <button
              onClick={logout}
              className="p-2 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-xl transition-all border border-transparent hover:border-rose-100 cursor-pointer"
              title="Keluar dari Akun"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        )}
      </header>
    </div>
  );
};
