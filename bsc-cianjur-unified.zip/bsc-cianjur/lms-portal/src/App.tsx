import { AppProvider, useApp } from './context/AppContext';
import { Header } from './components/Header';
import { Login } from './components/Login';
import { KepalaSekolahDashboard } from './components/KepalaSekolahDashboard';
import { OperatorPortal } from './components/OperatorPortal';
import { GuruPortal } from './components/GuruPortal';
import { SiswaPortal } from './components/SiswaPortal';

function MainAppContent() {
  const { currentUser } = useApp();

  if (!currentUser) {
    return <Login />;
  }

  const renderActivePortal = () => {
    switch (currentUser.role) {
      case 'KEPALA_SEKOLAH':
        return <KepalaSekolahDashboard />;
      case 'OPERATOR':
        return <OperatorPortal />;
      case 'GURU':
        return <GuruPortal />;
      case 'SISWA':
        return <SiswaPortal />;
      default:
        return <Login />;
    }
  };

  return (
    <div className="min-h-screen bg-[#F8FAFC] text-slate-800 pb-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-6 space-y-6">
        <Header />
        <main className="mt-4">
          {renderActivePortal()}
        </main>
      </div>
    </div>
  );
}

export default function App() {
  return (
    <AppProvider>
      <MainAppContent />
    </AppProvider>
  );
}

