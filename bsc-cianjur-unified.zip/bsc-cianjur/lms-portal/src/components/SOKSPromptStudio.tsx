import React, { useState } from 'react';
import { 
  Bot, Sparkles, Copy, Check, FileText, Send, HelpCircle, 
  BookOpen, ShieldCheck, RefreshCw, Code, Layers, Zap, Heart, Compass
} from 'lucide-react';

export const SOKSPromptStudio: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'TUTOR' | 'STUDIO_MODUL' | 'VERPAL_QUIZ'>('TUTOR');
  const [copiedSection, setCopiedSection] = useState<string | null>(null);

  // Studio Modul Generator state
  const [moduleTopic, setModuleTopic] = useState('');
  const [moduleRawText, setModuleRawText] = useState('Sistem Ekosistem dan Lingkungan Hidup serta dampaknya terhadap keseimbangan alam');
  const [isGeneratingModule, setIsGeneratingModule] = useState(false);
  const [generatedModuleResult, setGeneratedModuleResult] = useState('');

  // Verpal Quiz Generator state
  const [quizSubject, setQuizSubject] = useState('Bahasa Indonesia & Literasi Digital');
  const [quizTopic, setQuizTopic] = useState('Anatomi Berita Hoaks vs Informasi Resmi');
  const [isGeneratingQuiz, setIsGeneratingQuiz] = useState(false);
  const [generatedQuizResult, setGeneratedQuizResult] = useState('');

  const copyToClipboard = (text: string, sectionId: string) => {
    navigator.clipboard.writeText(text);
    setCopiedSection(sectionId);
    setTimeout(() => setCopiedSection(null), 2000);
  };

  // Generate Resonant Module with Gemini API
  const handleGenerateModule = async () => {
    if (!moduleRawText.trim() && !moduleTopic.trim()) return;
    setIsGeneratingModule(true);
    setGeneratedModuleResult('');

    try {
      const res = await fetch('/api/guru/generate-resonant-module', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          topic: moduleTopic,
          rawMaterial: moduleRawText
        })
      });

      if (!res.ok) throw new Error('Gagal menghasilkan modul resonan');
      const data = await res.json();
      setGeneratedModuleResult(data.text);
    } catch (err: any) {
      setGeneratedModuleResult(`Error: ${err.message || 'Terjadi kesalahan saat menghubungi server AI.'}`);
    } finally {
      setIsGeneratingModule(false);
    }
  };

  // Generate Verpal Quiz with Gemini API
  const handleGenerateQuiz = async () => {
    if (!quizSubject.trim() && !quizTopic.trim()) return;
    setIsGeneratingQuiz(true);
    setGeneratedQuizResult('');

    try {
      const res = await fetch('/api/guru/generate-verpal-quiz', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          subject: quizSubject,
          topic: quizTopic
        })
      });

      if (!res.ok) throw new Error('Gagal menghasilkan kuis verpal');
      const data = await res.json();
      setGeneratedQuizResult(data.text);
    } catch (err: any) {
      setGeneratedQuizResult(`Error: ${err.message || 'Terjadi kesalahan saat menghubungi server AI.'}`);
    } finally {
      setIsGeneratingQuiz(false);
    }
  };

  const promptTutorCode = `Role & System Directive:
Anda adalah S.O.K.S AI Tutor, asisten pembelajaran interaktif untuk siswa pendidikan kesetaraan (PKBM Paket A, B, dan C). Tugas Anda adalah mendampingi siswa memahami materi pelajaran tanpa memberikan jawaban kuis secara langsung.

Aturan Komunikasi Matriks Kosmo-Linguistik (Aturan 40/30/20):
Setiap kali Anda memberikan penjelasan atau merespons siswa, gunakan formula berikut:
- 40% Fakta & Ilmu Akurat (I): Jelaskan konsep/teori akademis secara ringkas, jelas, dan faktual.
- 30% Narasi Empati (Φ): Gunakan nada bicara yang hangat, menyemangati, dan relevan dengan kehidupan sehari-hari siswa agar menenangkan pikiran (Protokol Homeostasis).
- 20% Pertanyaan Reflektif (Δ): Akhiri respons Anda dengan 1 pertanyaan pemicu pemikiran kritis (critical thinking) agar siswa menyimpulkan sendiri solusinya.
- 10% Minimkan Ego (E): Hindari kata-kata menggurui atau menghakimi.

Instruksi Khusus Pertanyaan Kuis:
Jika siswa menanyakan jawaban soal/kuis, jangan berikan jawaban langsung (A/B/C/D). Berikan petunjuk konsep, analogi sederhana, dan panduan langkah berpikinya saja.`;

  const promptStudioModulCode = `Task: Ubah materi pembelajaran berikut menjadi Modul Artikel Resonan (A_res) yang ramah dan mudah diserap oleh warga belajar PKBM.

Materi Mentah:
[Masukkan topik/materi ajar di sini, misal: "Sistem Ekosistem dan Lingkungan Hidup"]

Format Output yang Wajib Dihasilkan:
1. Inti Fakta (Data Core - 40%): Sajikan 3–5 poin fakta ilmiah/akademis utama dengan bahasa yang sangat sederhana.
2. Kontekstualisasi Empatis (30%): Berikan narasi/contoh analogi yang dekat dengan pekerjaan atau kehidupan harian warga belajar.
3. Kotak Refleksi Siswa (20%): Buat 2 pertanyaan terbuka yang menanyakan pendapat atau pengalaman pribadi siswa terkait materi tersebut.
4. Micro-Summary (10%): Buat rangkuman 1 kalimat ringkas untuk mengikat pemahaman.`;

  const promptVerpalQuizCode = `Task: Buat 3 soal kuis studi kasus berstruktur Verpal Engine untuk mata pelajaran [Masukkan Mata Pelajaran].

Struktur Setiap Soal:
Berikan sebuah narasi studi kasus singkat atau potongan berita pendek (2–3 kalimat).
Mintalah siswa menganalisis dan membedakan:
a) Realitas Fisik (Rp): Mana fakta objek/angka nyata dalam narasi tersebut?
b) Aktivitas Faktual (Af): Tindakan/kejadian nyata apa yang terjadi?
c) Distorsi/Manipulasi (Im): Mana opini, asumsi, atau hoaks yang berpotensi menyesatkan?

Sertakan kunci jawaban dan penjelasan berbasis fitrah / logika jernih.`;

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white p-6 rounded-2xl border border-slate-800 shadow-md flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <span className="text-[10px] font-black uppercase tracking-widest text-amber-400 bg-amber-500/20 px-3 py-1 rounded-full border border-amber-500/30">
            Studio Prompt S.O.K.S & Matriks Kosmo-Linguistik
          </span>
          <h2 className="text-xl font-black mt-2">Bank System Prompt & Generator AI Otomatis</h2>
          <p className="text-xs text-slate-300">
            Dokumentasi lengkap dan generator langsung untuk Asisten AI Tutor 40/30/20, Studio Modul Resonan, serta Verpal Quiz Engine.
          </p>
        </div>

        <div className="flex items-center gap-2 bg-indigo-500/20 border border-indigo-500/30 px-3.5 py-2 rounded-xl text-xs font-bold text-indigo-300 shrink-0">
          <Sparkles className="w-4 h-4 text-indigo-400" />
          <span>Gemini 3.6 Flash Engine</span>
        </div>
      </div>

      {/* Tabs Bar */}
      <div className="flex border-b border-slate-200 gap-2 bg-slate-100 p-1.5 rounded-2xl overflow-x-auto no-scrollbar">
        <button
          onClick={() => setActiveTab('TUTOR')}
          className={`px-4 py-2.5 text-xs font-bold rounded-xl transition-all flex items-center gap-2 whitespace-nowrap cursor-pointer ${
            activeTab === 'TUTOR' ? 'bg-white text-indigo-700 shadow-sm' : 'text-slate-600 hover:text-indigo-600'
          }`}
        >
          <Bot className="w-4 h-4 text-indigo-600" />
          <span>1. System Prompt AI Tutor (40/30/20)</span>
        </button>

        <button
          onClick={() => setActiveTab('STUDIO_MODUL')}
          className={`px-4 py-2.5 text-xs font-bold rounded-xl transition-all flex items-center gap-2 whitespace-nowrap cursor-pointer ${
            activeTab === 'STUDIO_MODUL' ? 'bg-white text-indigo-700 shadow-sm' : 'text-slate-600 hover:text-indigo-600'
          }`}
        >
          <BookOpen className="w-4 h-4 text-amber-500" />
          <span>2. Studio Modul Resonan Generator</span>
        </button>

        <button
          onClick={() => setActiveTab('VERPAL_QUIZ')}
          className={`px-4 py-2.5 text-xs font-bold rounded-xl transition-all flex items-center gap-2 whitespace-nowrap cursor-pointer ${
            activeTab === 'VERPAL_QUIZ' ? 'bg-white text-indigo-700 shadow-sm' : 'text-slate-600 hover:text-indigo-600'
          }`}
        >
          <ShieldCheck className="w-4 h-4 text-emerald-500" />
          <span>3. Verpal Quiz Analytical Engine</span>
        </button>
      </div>

      {/* TAB 1: SYSTEM PROMPT AI TUTOR */}
      {activeTab === 'TUTOR' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* System Prompt Code Box */}
          <div className="bg-slate-900 text-slate-100 p-6 rounded-2xl border border-slate-800 space-y-4 flex flex-col justify-between">
            <div className="space-y-3">
              <div className="flex justify-between items-center border-b border-slate-800 pb-3">
                <div className="flex items-center gap-2">
                  <Code className="w-4 h-4 text-indigo-400" />
                  <span className="text-xs font-bold text-white">Role & System Directive (AI Tutor)</span>
                </div>
                <button
                  onClick={() => copyToClipboard(promptTutorCode, 'promptTutor')}
                  className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white text-[11px] font-bold rounded-lg transition-all cursor-pointer flex items-center gap-1.5"
                >
                  {copiedSection === 'promptTutor' ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedSection === 'promptTutor' ? 'Tersalin!' : 'Salin System Prompt'}</span>
                </button>
              </div>

              <pre className="text-xs font-mono text-slate-300 leading-relaxed bg-slate-950 p-4 rounded-xl border border-slate-800/80 overflow-x-auto whitespace-pre-wrap">
                {promptTutorCode}
              </pre>
            </div>

            <div className="p-3 bg-indigo-950/60 border border-indigo-900/60 rounded-xl text-[11px] text-indigo-200">
              <strong className="block mb-0.5 text-indigo-300">Catatan Implementasi API:</strong>
              Prompt ini sudah terintegrasi aktif secara bawaan pada endpoint <code className="text-amber-300 font-mono">POST /api/tutor/chat</code> di server Node.js BSC EduSetara.
            </div>
          </div>

          {/* Explanation & Breakdown */}
          <div className="bg-white border border-slate-200 p-6 rounded-2xl shadow-sm space-y-5">
            <h3 className="font-black text-slate-900 text-base border-b border-slate-100 pb-3">
              Struktur Formulasi S.O.K.S & MKL (40/30/20)
            </h3>

            <div className="space-y-3">
              <div className="p-3.5 bg-amber-50 border border-amber-200 rounded-xl text-xs space-y-1">
                <span className="font-extrabold text-amber-900 block">40% Fakta & Ilmu Akurat ($I$)</span>
                <p className="text-slate-700 leading-relaxed">
                  Menyajikan dasar teori ilmiah atau akademis secara ringkas tanpa istilah rumit yang membebankan mental siswa.
                </p>
              </div>

              <div className="p-3.5 bg-emerald-50 border border-emerald-200 rounded-xl text-xs space-y-1">
                <span className="font-extrabold text-emerald-900 block">30% Narasi Empati ($\Phi$)</span>
                <p className="text-slate-700 leading-relaxed">
                  Protokol Homeostasis untuk meredakan kecemasan, menghilangkan rasa bersalah/takut gagal, dan mengapresiasi tekad belajar siswa.
                </p>
              </div>

              <div className="p-3.5 bg-indigo-50 border border-indigo-200 rounded-xl text-xs space-y-1">
                <span className="font-extrabold text-indigo-900 block">20% Pertanyaan Reflektif ($\Delta$)</span>
                <p className="text-slate-700 leading-relaxed">
                  Protokol Algoritma Sentrifugal: 1 pertanyaan pembawa kesadaran kritis agar siswa terlatih menyimpulkan solusi sendiri.
                </p>
              </div>

              <div className="p-3.5 bg-slate-100 border border-slate-200 rounded-xl text-xs space-y-1">
                <span className="font-extrabold text-slate-800 block">10% Minimkan Ego ($E$)</span>
                <p className="text-slate-600 leading-relaxed">
                  Menjaga bahasa tetap santun, setara, tidak menggurui, dan menaruh empati utuh.
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: STUDIO MODUL RESONAN GENERATOR */}
      {activeTab === 'STUDIO_MODUL' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Left: Form & Prompt Template */}
          <div className="space-y-6">
            <div className="bg-slate-900 text-slate-100 p-6 rounded-2xl border border-slate-800 space-y-3">
              <div className="flex justify-between items-center border-b border-slate-800 pb-2">
                <span className="text-xs font-bold text-amber-400">Template Prompt Studio Guru</span>
                <button
                  onClick={() => copyToClipboard(promptStudioModulCode, 'promptModul')}
                  className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 text-[10px] font-bold rounded-md transition-all cursor-pointer flex items-center gap-1"
                >
                  {copiedSection === 'promptModul' ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                  <span>Salin Prompt</span>
                </button>
              </div>
              <pre className="text-[11px] font-mono text-slate-300 leading-relaxed bg-slate-950 p-3 rounded-xl border border-slate-800 overflow-x-auto whitespace-pre-wrap">
                {promptStudioModulCode}
              </pre>
            </div>

            {/* Generator Form */}
            <div className="bg-white border border-slate-200 p-6 rounded-2xl shadow-sm space-y-4">
              <h3 className="font-black text-slate-900 text-sm">Generator Modul Resonan AI Studio</h3>
              <p className="text-xs text-slate-500">Masukkan topik atau materi mentah untuk diolah otomatis oleh Gemini AI:</p>

              <form onSubmit={(e) => { e.preventDefault(); handleGenerateModule(); }} className="space-y-3 text-xs">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Topik Pelajaran / Judul Modul</label>
                  <input
                    type="text"
                    value={moduleTopic}
                    onChange={(e) => setModuleTopic(e.target.value)}
                    placeholder="Contoh: Ekosistem & Keseimbangan Alam"
                    className="w-full p-2.5 border border-slate-200 rounded-xl bg-slate-50 font-bold"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Materi Mentah / Catatan Guru</label>
                  <textarea
                    rows={4}
                    value={moduleRawText}
                    onChange={(e) => setModuleRawText(e.target.value)}
                    placeholder="Tuliskan poin penting atau rangkuman materi..."
                    className="w-full p-2.5 border border-slate-200 rounded-xl bg-slate-50"
                    required
                  />
                </div>

                <button
                  type="submit"
                  disabled={isGeneratingModule}
                  className="w-full py-3 bg-amber-500 hover:bg-amber-600 text-white font-black text-xs rounded-xl shadow-md cursor-pointer transition-all flex items-center justify-center gap-2"
                >
                  {isGeneratingModule ? (
                    <>
                      <RefreshCw className="w-4 h-4 animate-spin" />
                      <span>Memproses Modul Resonan 40/30/20...</span>
                    </>
                  ) : (
                    <>
                      <Zap className="w-4 h-4" />
                      <span>Generate Artikel Resonan ($A_{`res`}$)</span>
                    </>
                  )}
                </button>
              </form>
            </div>
          </div>

          {/* Right: AI Output Display */}
          <div className="bg-white border border-slate-200 p-6 rounded-2xl shadow-sm space-y-4 flex flex-col">
            <div className="flex justify-between items-center border-b border-slate-100 pb-3">
              <h3 className="font-black text-slate-900 text-sm flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-amber-500" /> Hasil Output Modul Resonan ($A_{`res`}$)
              </h3>
              {generatedModuleResult && (
                <button
                  onClick={() => copyToClipboard(generatedModuleResult, 'outputModul')}
                  className="text-[10px] font-bold text-indigo-600 hover:underline flex items-center gap-1 cursor-pointer"
                >
                  {copiedSection === 'outputModul' ? <Check className="w-3 h-3 text-emerald-600" /> : <Copy className="w-3 h-3" />}
                  <span>Salin Hasil</span>
                </button>
              )}
            </div>

            <div className="flex-1 bg-slate-50 p-4 rounded-xl border border-slate-200 overflow-y-auto max-h-[500px]">
              {generatedModuleResult ? (
                <pre className="text-xs font-sans text-slate-800 leading-relaxed whitespace-pre-wrap">
                  {generatedModuleResult}
                </pre>
              ) : (
                <div className="h-full flex flex-col items-center justify-center text-slate-400 text-xs py-12 space-y-2 text-center">
                  <BookOpen className="w-8 h-8 text-slate-300" />
                  <p>Klik button "Generate Artikel Resonan" untuk memproses materi secara otomatis dengan formula MKL 40/30/20.</p>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: VERPAL QUIZ ANALYTICAL ENGINE */}
      {activeTab === 'VERPAL_QUIZ' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Left: Prompt Code & Form */}
          <div className="space-y-6">
            <div className="bg-slate-900 text-slate-100 p-6 rounded-2xl border border-slate-800 space-y-3">
              <div className="flex justify-between items-center border-b border-slate-800 pb-2">
                <span className="text-xs font-bold text-emerald-400">Template Prompt Verpal Engine</span>
                <button
                  onClick={() => copyToClipboard(promptVerpalQuizCode, 'promptVerpal')}
                  className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 text-[10px] font-bold rounded-md transition-all cursor-pointer flex items-center gap-1"
                >
                  {copiedSection === 'promptVerpal' ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                  <span>Salin Prompt</span>
                </button>
              </div>
              <pre className="text-[11px] font-mono text-slate-300 leading-relaxed bg-slate-950 p-3 rounded-xl border border-slate-800 overflow-x-auto whitespace-pre-wrap">
                {promptVerpalQuizCode}
              </pre>
            </div>

            {/* Form */}
            <div className="bg-white border border-slate-200 p-6 rounded-2xl shadow-sm space-y-4">
              <h3 className="font-black text-slate-900 text-sm">Generator Kuis Verpal Analytical AI</h3>
              <p className="text-xs text-slate-500">Buat 3 studi kasus yang melatih siswa membedakan Realitas Fisik ($R_p$), Aktivitas Faktual ($A_f$), dan Distorsi/Hoaks ($I_m$):</p>

              <form onSubmit={(e) => { e.preventDefault(); handleGenerateQuiz(); }} className="space-y-3 text-xs">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Mata Pelajaran</label>
                  <input
                    type="text"
                    value={quizSubject}
                    onChange={(e) => setQuizSubject(e.target.value)}
                    className="w-full p-2.5 border border-slate-200 rounded-xl bg-slate-50 font-bold"
                    required
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Topik / Tema Studi Kasus</label>
                  <input
                    type="text"
                    value={quizTopic}
                    onChange={(e) => setQuizTopic(e.target.value)}
                    className="w-full p-2.5 border border-slate-200 rounded-xl bg-slate-50 font-bold"
                    required
                  />
                </div>

                <button
                  type="submit"
                  disabled={isGeneratingQuiz}
                  className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs rounded-xl shadow-md cursor-pointer transition-all flex items-center justify-center gap-2"
                >
                  {isGeneratingQuiz ? (
                    <>
                      <RefreshCw className="w-4 h-4 animate-spin" />
                      <span>Memproses Kuis Verpal Engine...</span>
                    </>
                  ) : (
                    <>
                      <ShieldCheck className="w-4 h-4" />
                      <span>Generate Kuis Verpal (3 Soal)</span>
                    </>
                  )}
                </button>
              </form>
            </div>
          </div>

          {/* Right: Output Result */}
          <div className="bg-white border border-slate-200 p-6 rounded-2xl shadow-sm space-y-4 flex flex-col">
            <div className="flex justify-between items-center border-b border-slate-100 pb-3">
              <h3 className="font-black text-slate-900 text-sm flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-emerald-600" /> Output Kuis Verpal Engine ($R_p, A_f, I_m$)
              </h3>
              {generatedQuizResult && (
                <button
                  onClick={() => copyToClipboard(generatedQuizResult, 'outputQuiz')}
                  className="text-[10px] font-bold text-indigo-600 hover:underline flex items-center gap-1 cursor-pointer"
                >
                  {copiedSection === 'outputQuiz' ? <Check className="w-3 h-3 text-emerald-600" /> : <Copy className="w-3 h-3" />}
                  <span>Salin Hasil</span>
                </button>
              )}
            </div>

            <div className="flex-1 bg-slate-50 p-4 rounded-xl border border-slate-200 overflow-y-auto max-h-[500px]">
              {generatedQuizResult ? (
                <pre className="text-xs font-sans text-slate-800 leading-relaxed whitespace-pre-wrap">
                  {generatedQuizResult}
                </pre>
              ) : (
                <div className="h-full flex flex-col items-center justify-center text-slate-400 text-xs py-12 space-y-2 text-center">
                  <ShieldCheck className="w-8 h-8 text-slate-300" />
                  <p>Klik button "Generate Kuis Verpal" untuk menghasilkan 3 soal studi kasus verifikasi fakta otomatis.</p>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
