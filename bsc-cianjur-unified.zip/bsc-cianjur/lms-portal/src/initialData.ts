import { 
  User, Student, Lesson, Test, TestAttempt, ReportCard, 
  TeacherKPI, OperatorKPI, StudentKPI, StudentGoal, VocationalProject, VerpalQuizItem 
} from './types';

export const INITIAL_USERS: User[] = [
  {
    id: 'usr-kepala',
    name: 'Drs. H. Ahmad Sudrajat, M.Pd.',
    email: 'ahmad.sudrajat@edusetara.sch.id',
    role: 'KEPALA_SEKOLAH',
    avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150'
  },
  {
    id: 'usr-op1',
    name: 'Budi Santoso, S.Kom.',
    email: 'budi.operator@edusetara.sch.id',
    role: 'OPERATOR',
    avatar: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=150'
  },
  {
    id: 'usr-guru1',
    name: 'Siti Rahmah, S.Pd.',
    email: 'siti.rahmah@edusetara.sch.id',
    role: 'GURU',
    subject: 'Bahasa Indonesia & PPKn',
    avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=150'
  },
  {
    id: 'usr-guru2',
    name: 'Irwan Hermawan, M.Si.',
    email: 'irwan.hermawan@edusetara.sch.id',
    role: 'GURU',
    subject: 'Matematika & IPA',
    avatar: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?w=150'
  },
  {
    id: 'usr-siswa1',
    name: 'Rian Hidayat',
    email: 'rian.hidayat@gmail.com',
    role: 'SISWA',
    package: 'Paket C',
    avatar: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=150'
  },
  {
    id: 'usr-siswa2',
    name: 'Siti Aminah',
    email: 'siti.aminah@gmail.com',
    role: 'SISWA',
    package: 'Paket B',
    avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=150'
  },
  {
    id: 'usr-siswa3',
    name: 'Dewi Lestari',
    email: 'dewi.lestari@gmail.com',
    role: 'SISWA',
    package: 'Paket A',
    avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150'
  }
];

export const INITIAL_STUDENTS: Student[] = [
  {
    id: 'std-001',
    name: 'Rian Hidayat',
    email: 'rian.hidayat@gmail.com',
    package: 'Paket C',
    status: 'Aktif',
    registrationDate: '2025-01-10',
    gender: 'Laki-laki'
  },
  {
    id: 'std-002',
    name: 'Siti Aminah',
    email: 'siti.aminah@gmail.com',
    package: 'Paket B',
    status: 'Aktif',
    registrationDate: '2025-01-15',
    gender: 'Perempuan'
  },
  {
    id: 'std-003',
    name: 'Dewi Lestari',
    email: 'dewi.lestari@gmail.com',
    package: 'Paket A',
    status: 'Aktif',
    registrationDate: '2025-02-01',
    gender: 'Perempuan'
  },
  {
    id: 'std-004',
    name: 'Fajar Nugraha',
    email: 'fajar.nugraha@gmail.com',
    package: 'Paket C',
    status: 'Aktif',
    registrationDate: '2025-01-12',
    gender: 'Laki-laki'
  },
  {
    id: 'std-005',
    name: 'Andi Wijaya',
    email: 'andi.wijaya@gmail.com',
    package: 'Paket B',
    status: 'Menunggu',
    registrationDate: '2026-07-20',
    gender: 'Laki-laki'
  },
  {
    id: 'std-006',
    name: 'Bambang Tri',
    email: 'bambang.tri@gmail.com',
    package: 'Paket C',
    status: 'Lulus',
    registrationDate: '2024-06-15',
    gender: 'Laki-laki'
  }
];

export const INITIAL_LESSONS: Lesson[] = [
  // Paket C Lessons
  {
    id: 'les-001',
    title: 'Pancasila sebagai Ideologi Terbuka',
    subject: 'PPKn',
    package: 'Paket C',
    videoUrl: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ', // Placeholder, can display embedded player
    videoDuration: '10:15',
    description: 'Menjelaskan makna Pancasila sebagai ideologi yang mampu menyesuaikan diri dengan perkembangan zaman tanpa kehilangan nilai dasarnya.',
    teacherId: 'usr-guru1',
    teacherName: 'Siti Rahmah, S.Pd.'
  },
  {
    id: 'les-002',
    title: 'Teks Prosedur Kompleks',
    subject: 'Bahasa Indonesia',
    package: 'Paket C',
    videoUrl: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
    videoDuration: '14:20',
    description: 'Mempelajari struktur, ciri kebahasaan, dan langkah-langkah menyusun teks prosedur kompleks yang baik dan komunikatif.',
    teacherId: 'usr-guru1',
    teacherName: 'Siti Rahmah, S.Pd.'
  },
  {
    id: 'les-003',
    title: 'Fungsi Kuadrat dan Grafiknya',
    subject: 'Matematika',
    package: 'Paket C',
    videoUrl: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
    videoDuration: '18:10',
    description: 'Memahami bentuk umum fungsi kuadrat, titik puncak, sumbu simetri, serta bagaimana cara menggambar grafik parabola.',
    teacherId: 'usr-guru2',
    teacherName: 'Irwan Hermawan, M.Si.'
  },
  // Paket B Lessons
  {
    id: 'les-004',
    title: 'Sistem Organ Manusia',
    subject: 'IPA',
    package: 'Paket B',
    videoUrl: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
    videoDuration: '12:30',
    description: 'Pengenalan organ-organ penyusun sistem pencernaan dan pernapasan manusia beserta fungsinya masing-masing.',
    teacherId: 'usr-guru2',
    teacherName: 'Irwan Hermawan, M.Si.'
  },
  {
    id: 'les-005',
    title: 'Interaksi Sosial Kemasyarakatan',
    subject: 'IPS',
    package: 'Paket B',
    videoUrl: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
    videoDuration: '11:05',
    description: 'Memahami bentuk-bentuk interaksi sosial asosiatif dan disosiatif di lingkungan kehidupan sehari-hari.',
    teacherId: 'usr-guru1',
    teacherName: 'Siti Rahmah, S.Pd.'
  },
  // Paket A Lessons
  {
    id: 'les-006',
    title: 'Mengenal Suku Kata dan Membaca Lancar',
    subject: 'Bahasa Indonesia',
    package: 'Paket A',
    videoUrl: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
    videoDuration: '08:45',
    description: 'Belajar mengeja suku kata terbuka dan tertutup dengan metode yang ceria untuk membantu kelancaran membaca.',
    teacherId: 'usr-guru1',
    teacherName: 'Siti Rahmah, S.Pd.'
  }
];

export const INITIAL_TESTS: Test[] = [
  // PPKn - Pancasila
  {
    id: 'test-pre-001',
    lessonId: 'les-001',
    type: 'pretest',
    questions: [
      {
        id: 'q-pre-001-1',
        text: 'Pancasila lahir sebagai hasil kesepakatan para pendiri bangsa pada tanggal...',
        options: ['1 Juni 1945', '17 Agustus 1945', '18 Agustus 1945', '22 Juni 1945'],
        correctAnswerIndex: 0
      },
      {
        id: 'q-pre-001-2',
        text: 'Ideologi Pancasila bersifat terbuka, artinya...',
        options: [
          'Dapat diubah sesuai keinginan masyarakat modern',
          'Nilai dasarnya tetap, namun penjabarannya dinamis mengikuti perkembangan zaman',
          'Sama persis dengan ideologi liberal barat',
          'Tertutup terhadap pengaruh asing luar negeri'
        ],
        correctAnswerIndex: 1
      }
    ]
  },
  {
    id: 'test-post-001',
    lessonId: 'les-001',
    type: 'posttest',
    questions: [
      {
        id: 'q-post-001-1',
        text: 'Salah satu dimensi Pancasila sebagai ideologi terbuka yang menekankan bahwa nilai-nilai tersebut bersumber dari realitas kehidupan masyarakat adalah...',
        options: ['Dimensi Idealisme', 'Dimensi Normatif', 'Dimensi Realitas', 'Dimensi Fleksibilitas'],
        correctAnswerIndex: 2
      },
      {
        id: 'q-post-001-2',
        text: 'Nilai-nilai Pancasila yang terkandung dalam pembukaan UUD 1945 bersifat tetap dan tidak boleh diubah. Ini disebut nilai...',
        options: ['Nilai Dasar', 'Nilai Instrumental', 'Nilai Praktis', 'Nilai Utama'],
        correctAnswerIndex: 0
      },
      {
        id: 'q-post-001-3',
        text: 'Menghormati hak asasi sesama manusia merupakan cerminan dari sila Pancasila ke...',
        options: ['Sila ke-1', 'Sila ke-2', 'Sila ke-3', 'Sila ke-4'],
        correctAnswerIndex: 1
      }
    ]
  },

  // Teks Prosedur Kompleks
  {
    id: 'test-pre-002',
    lessonId: 'les-002',
    type: 'pretest',
    questions: [
      {
        id: 'q-pre-002-1',
        text: 'Teks yang berisi langkah-langkah sistematis untuk menyelesaikan suatu pekerjaan disebut...',
        options: ['Teks Laporan', 'Teks Prosedur', 'Teks Eksplanasi', 'Teks Deskripsi'],
        correctAnswerIndex: 1
      }
    ]
  },
  {
    id: 'test-post-002',
    lessonId: 'les-002',
    type: 'posttest',
    questions: [
      {
        id: 'q-post-002-1',
        text: 'Bagian teks prosedur yang menyatakan tujuan umum dari kegiatan yang dilakukan adalah...',
        options: ['Langkah-langkah', 'Penutup', 'Pernyataan Umum (Tujuan)', 'Bahan-bahan'],
        correctAnswerIndex: 2
      },
      {
        id: 'q-post-002-2',
        text: 'Kata kerja "tambahkan", "aduklah", "siapkan" dalam teks prosedur digolongkan sebagai kalimat...',
        options: ['Kalimat Imperatif (Perintah)', 'Kalimat Deklaratif (Berita)', 'Kalimat Interogatif (Tanya)', 'Kalimat Pasif'],
        correctAnswerIndex: 0
      }
    ]
  },

  // Fungsi Kuadrat
  {
    id: 'test-pre-003',
    lessonId: 'les-003',
    type: 'pretest',
    questions: [
      {
        id: 'q-pre-003-1',
        text: 'Bentuk umum fungsi kuadrat adalah f(x) = ...',
        options: ['ax + b', 'ax^2 + bx + c', 'ax^3 + bx^2 + cx + d', 'a/x + b'],
        correctAnswerIndex: 1
      }
    ]
  },
  {
    id: 'test-post-003',
    lessonId: 'les-003',
    type: 'posttest',
    questions: [
      {
        id: 'q-post-003-1',
        text: 'Jika nilai koefisien a > 0 pada fungsi kuadrat, maka grafiknya akan...',
        options: ['Terbuka ke atas (tersenyum)', 'Terbuka ke bawah (cemberut)', 'Berbentuk garis lurus', 'Berbentuk lingkaran'],
        correctAnswerIndex: 0
      },
      {
        id: 'q-post-003-2',
        text: 'Titik potong dengan sumbu Y dari fungsi f(x) = x^2 - 4x + 5 diperoleh saat x = 0, yaitu di titik...',
        options: ['(0, -4)', '(0, 5)', '(0, -5)', '(5, 0)'],
        correctAnswerIndex: 1
      }
    ]
  }
];

export const INITIAL_ATTEMPTS: TestAttempt[] = [
  {
    id: 'att-001',
    studentId: 'std-001',
    studentName: 'Rian Hidayat',
    lessonId: 'les-001',
    testId: 'test-pre-001',
    type: 'pretest',
    score: 50,
    correctCount: 1,
    totalQuestions: 2,
    completedAt: '2026-07-20 09:30:15'
  },
  {
    id: 'att-002',
    studentId: 'std-001',
    studentName: 'Rian Hidayat',
    lessonId: 'les-001',
    testId: 'test-post-001',
    type: 'posttest',
    score: 100,
    correctCount: 3,
    totalQuestions: 3,
    completedAt: '2026-07-20 10:15:22'
  },
  {
    id: 'att-003',
    studentId: 'std-001',
    studentName: 'Rian Hidayat',
    lessonId: 'les-002',
    testId: 'test-pre-002',
    type: 'pretest',
    score: 100,
    correctCount: 1,
    totalQuestions: 1,
    completedAt: '2026-07-21 14:02:11'
  },
  {
    id: 'att-004',
    studentId: 'std-001',
    studentName: 'Rian Hidayat',
    lessonId: 'les-002',
    testId: 'test-post-002',
    type: 'posttest',
    score: 100,
    correctCount: 2,
    totalQuestions: 2,
    completedAt: '2026-07-21 14:45:30'
  },
  {
    id: 'att-005',
    studentId: 'std-004',
    studentName: 'Fajar Nugraha',
    lessonId: 'les-001',
    testId: 'test-pre-001',
    type: 'pretest',
    score: 100,
    correctCount: 2,
    totalQuestions: 2,
    completedAt: '2026-07-18 10:10:00'
  },
  {
    id: 'att-006',
    studentId: 'std-004',
    studentName: 'Fajar Nugraha',
    lessonId: 'les-001',
    testId: 'test-post-001',
    type: 'posttest',
    score: 67,
    correctCount: 2,
    totalQuestions: 3,
    completedAt: '2026-07-18 10:45:00'
  }
];

export const INITIAL_REPORT_CARDS: ReportCard[] = [
  {
    id: 'rep-001',
    studentId: 'std-001',
    studentName: 'Rian Hidayat',
    package: 'Paket C',
    academicYear: '2025/2026 - Genap',
    verpalIndex: 94,
    focusLevel: 98,
    coherenceScore: 92,
    grades: [
      { subject: 'PPKn', preTestScore: 50, postTestScore: 100, finalScore: 85, teacherNote: 'Sangat memahami nilai ideologi terbuka.' },
      { subject: 'Bahasa Indonesia', preTestScore: 100, postTestScore: 100, finalScore: 100, teacherNote: 'Luar biasa dalam menyusun teks prosedur.' },
      { subject: 'Matematika', preTestScore: null, postTestScore: null, finalScore: 75, teacherNote: 'Tingkatkan latihan grafik fungsi kuadrat.' },
      { subject: 'Sosiologi', preTestScore: null, postTestScore: null, finalScore: 80, teacherNote: 'Aktif berdiskusi tentang dinamika kelompok.' }
    ],
    attendanceRate: 96,
    characterNote: 'Sopan, disiplin, mandiri, berkeadaban digital tinggi, dan aktif dalam pembelajaran modul video.',
    status: 'Sedang Belajar',
    updatedAt: '2026-07-21 15:00:00'
  },
  {
    id: 'rep-002',
    studentId: 'std-002',
    studentName: 'Siti Aminah',
    package: 'Paket B',
    academicYear: '2025/2026 - Genap',
    verpalIndex: 88,
    focusLevel: 92,
    coherenceScore: 85,
    grades: [
      { subject: 'IPA', preTestScore: 0, postTestScore: 80, finalScore: 80, teacherNote: 'Bagus dalam memahami struktur pencernaan.' },
      { subject: 'IPS', preTestScore: null, postTestScore: null, finalScore: 85, teacherNote: 'Memahami interaksi sosial dengan sangat baik.' },
      { subject: 'Bahasa Indonesia', preTestScore: null, postTestScore: null, finalScore: 78, teacherNote: 'Mampu menulis paragraf argumentatif.' }
    ],
    attendanceRate: 92,
    characterNote: 'Tekun belajar, selalu menyelesaikan tugas tepat waktu.',
    status: 'Sedang Belajar',
    updatedAt: '2026-07-22 11:30:00'
  },
  {
    id: 'rep-003',
    studentId: 'std-003',
    studentName: 'Dewi Lestari',
    package: 'Paket A',
    academicYear: '2025/2026 - Genap',
    verpalIndex: 85,
    focusLevel: 90,
    coherenceScore: 88,
    grades: [
      { subject: 'Bahasa Indonesia', preTestScore: null, postTestScore: null, finalScore: 90, teacherNote: 'Sudah lancar membaca kalimat panjang.' },
      { subject: 'Matematika', preTestScore: null, postTestScore: null, finalScore: 82, teacherNote: 'Paham penjumlahan dan perkalian bersusun.' }
    ],
    attendanceRate: 98,
    characterNote: 'Sangat ceria, memiliki motivasi belajar yang luar biasa tinggi.',
    status: 'Sedang Belajar',
    updatedAt: '2026-07-23 10:00:00'
  }
];

export const INITIAL_TEACHER_KPI: TeacherKPI[] = [
  {
    teacherId: 'usr-guru1',
    name: 'Siti Rahmah, S.Pd.',
    subject: 'Bahasa Indonesia & PPKn',
    videosUploaded: 12,
    testsCreated: 24, // 12 pre, 12 post
    averageStudentScore: 87.5,
    studentInteractionRate: 92,
    resonanceScore: 9.88,
    kpiRating: 4.8
  },
  {
    teacherId: 'usr-guru2',
    name: 'Irwan Hermawan, M.Si.',
    subject: 'Matematika & IPA',
    videosUploaded: 9,
    testsCreated: 18,
    averageStudentScore: 79.2,
    studentInteractionRate: 85,
    resonanceScore: 9.65,
    kpiRating: 4.5
  }
];

// S.O.K.S Initial Sample Data
export const INITIAL_STUDENT_GOALS: StudentGoal[] = [
  {
    id: 'goal-001',
    studentId: 'std-001',
    targetCareer: 'Wirausaha Digital & Pemilik Usaha Sablon Kreatif',
    motivationReason: 'Ingin mandiri secara finansial, menciptakan lapangan kerja bagi pemuda sekitar, dan melanjutkan pendidikan ke bangku kuliah.',
    targetGraduationYear: '2026',
    skillsToMaster: ['Pemasaran Digital', 'Manajemen Keuangan UMKM', 'Komunikasi Publik'],
    createdAt: '2026-01-15'
  },
  {
    id: 'goal-002',
    studentId: 'std-002',
    targetCareer: 'Tenaga Administrasi & Pelayanan Kesehatan',
    motivationReason: 'Bercita-cita membantu RSUD/Klinik di desa serta meningkatkan derajat ekonomi keluarga.',
    targetGraduationYear: '2027',
    skillsToMaster: ['Pengolahan Data Excel', 'Literasi Kesehatan', 'Etika Pelayanan'],
    createdAt: '2026-02-01'
  }
];

export const INITIAL_VOCATIONAL_PROJECTS: VocationalProject[] = [
  {
    id: 'prj-001',
    studentId: 'std-001',
    studentName: 'Rian Hidayat',
    package: 'Paket C',
    title: 'Digitalisasi Kasir & Katalog UMKM Kerajinan Bambu Desa',
    category: 'UMKM & Kewirausahaan',
    description: 'Proyek pembuatan sistem pencatatan stok dan kasir sederhana berbasis spreadsheet online untuk kelompok pengrajin bambu di lingkungan tempat tinggal.',
    impactNote: 'Membantu 8 pengrajin lokal mencatat penjualan secara rapi dan menaikkan omzet bulanan hingga 25%.',
    imageUrl: 'https://images.unsplash.com/photo-1556740758-90de374c12ad?w=600',
    status: 'Terpublikasi',
    coherenceScore: 94,
    createdAt: '2026-06-10'
  },
  {
    id: 'prj-002',
    studentId: 'std-002',
    studentName: 'Siti Aminah',
    package: 'Paket B',
    title: 'Rintisan Bank Sampah Organik & Kompos Rumah Tangga',
    category: 'Lingkungan',
    description: 'Mengedukasi 15 RT setempat tentang pemilahan sampah dapur menjadi pupuk organik cair yang bermanfaat bagi kebun sayur keluarga.',
    impactNote: 'Mengurangi limbah organik hingga 40kg per minggu dan menghasilkan 20 botol pupuk cair siap pakai.',
    imageUrl: 'https://images.unsplash.com/photo-1542601906990-b4d3fb778b09?w=600',
    status: 'Terpublikasi',
    coherenceScore: 89,
    createdAt: '2026-06-25'
  }
];

export const INITIAL_VERPAL_ITEMS: VerpalQuizItem[] = [
  {
    id: 'vp-001',
    title: 'Deteksi Hoaks Informasi Bantuan Beasiswa',
    contextSnippet: 'Beredar pesan berantai di WhatsApp yang mengklaim: "Pemerintah membagikan tunjangan dana tunai 10 juta tanpa syarat cukup klik tautan bit.ly/dana-kaget-2026".',
    statement: 'Pesan tersebut merupakan berita bohong (hoaks) & jebakan phishing.',
    isFact: true,
    explanation: 'FAKTA VALID: Tautan bit.ly acak bukan domain resmi pemerintah (.go.id atau .sch.id). Pemerintah tidak pernah membagikan bantuan tanpa proses verifikasi data identitas resmi.',
    category: 'Literasi Digital'
  },
  {
    id: 'vp-002',
    title: 'Validasi Fakta Grafik Fungsi Kuadrat Dalam Bisnis',
    contextSnippet: 'Sebuah artikel bisnis menyebutkan bahwa kurva keuntungan usaha yang berbentuk parabola terbuka ke bawah menunjukkan profit maksimum tercapai di titik puncak.',
    statement: 'Pernyataan tersebut secara ilmiah matematika adalah Fakta Benar.',
    isFact: true,
    explanation: 'FAKTA VALID: Pada fungsi kuadrat f(x) = ax^2 + bx + c dengan a < 0 (parabola terbuka ke bawah), nilai y maksimum terletak tepat pada titik puncak (Xp, Yp).',
    category: 'Sains & Kesehatan'
  },
  {
    id: 'vp-003',
    title: 'Klarifikasi Isu Ijazah Kesetaraan di Dunia Kerja',
    contextSnippet: 'Sebuah postingan di media sosial mengklaim bahwa Ijazah Paket C tidak diakui untuk mendaftar kuliah atau tes CPNS.',
    statement: 'Klaim tersebut adalah mitos / tidak benar.',
    isFact: false,
    explanation: 'MITOS / TIDAK BENAR: Berdasarkan UU No. 20 Tahun 2003 tentang Sistem Pendidikan Nasional, Ijazah Kesetaraan (Paket A, B, C) memiliki legalitas hukum yang sama dan diakui secara resmi untuk melanjutkan kuliah maupun melamar pekerjaan.',
    category: 'Sosial & Ekonomi'
  }
];

export const INITIAL_OPERATOR_KPI: OperatorKPI[] = [
  {
    operatorId: 'usr-op1',
    name: 'Budi Santoso, S.Kom.',
    syncsProcessed: 14,
    registrationsApproved: 38,
    dataUpdatesCount: 112,
    systemAccuracy: 99.8,
    kpiRating: 4.9
  }
];

export const INITIAL_STUDENT_KPI: StudentKPI[] = [
  {
    studentId: 'std-001',
    name: 'Rian Hidayat',
    package: 'Paket C',
    lessonsWatched: 5,
    testsCompleted: 4,
    averageScore: 92.5,
    completionRate: 80
  },
  {
    studentId: 'std-002',
    name: 'Siti Aminah',
    package: 'Paket B',
    lessonsWatched: 3,
    testsCompleted: 2,
    averageScore: 80.0,
    completionRate: 66
  },
  {
    studentId: 'std-003',
    name: 'Dewi Lestari',
    package: 'Paket A',
    lessonsWatched: 2,
    testsCompleted: 0,
    averageScore: 0,
    completionRate: 33
  }
];
