import React, { useState, useRef, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { Lesson, Test, TestAttempt, ReportCard } from '../types';
import { 
  Play, BookOpen, Award, FileSpreadsheet, Printer, ArrowRight, CheckCircle2, 
  HelpCircle, ChevronRight, Check, AlertCircle, Sparkles, GraduationCap,
  MessageSquare, Send, Bot, Volume2, VolumeX, Compass, ShieldCheck, Briefcase,
  Target, Flame, Heart, Sliders, Plus, RefreshCw, Layers
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { AISmartTutor } from './AISmartTutor';

export const SiswaPortal: React.FC = () => {
  const { 
    currentUser, lessons, tests, attempts, submitTestAttempt, reportCards,
    studentGoals, saveStudentGoal, vocationalProjects, addVocationalProject, verpalItems
  } = useApp();

  const selectedPkg: 'Paket A' | 'Paket B' | 'Paket C' = currentUser?.package || 'Paket C';
  
  const [activeTab, setActiveTab] = useState<'BELAJAR' | 'TARGET_GOAL' | 'VERPAL' | 'KARYA' | 'RAPORT'>('BELAJAR');
  const [activeLesson, setActiveLesson] = useState<Lesson | null>(null);

  // Homeostasis & Audio Focus State (Protokol S.O.K.S)
  const [isAudioPlaying, setIsAudioPlaying] = useState(false);
  const [audioVolume, setAudioVolume] = useState(0.25);
  const audioCtxRef = useRef<AudioContext | null>(null);
  const gainNodeRef = useRef<GainNode | null>(null);
  const [showMindsetModal, setShowMindsetModal] = useState(false);
  const [mindsetDone, setMindsetDone] = useState(false);

  // Student Goal Form State (Protokol Kebangkitan)
  const myGoal = studentGoals.find(g => g.studentId === currentUser?.id);
  const [targetCareerInput, setTargetCareerInput] = useState(myGoal?.targetCareer || '');
  const [motivationInput, setMotivationInput] = useState(myGoal?.motivationReason || '');
  const [gradYearInput, setGradYearInput] = useState(myGoal?.targetGraduationYear || '2026');
  const [skillsInput, setSkillsInput] = useState(myGoal?.skillsToMaster.join(', ') || 'Manajemen Bisnis, Digital Marketing, Komunikasi');
  const [goalSavedSuccess, setGoalSavedSuccess] = useState(false);

  // Verpal Quiz (Fakta vs Hoax) State
  const [verpalAnswers, setVerpalAnswers] = useState<Record<string, boolean>>({});
  const [verpalSubmitted, setVerpalSubmitted] = useState(false);

  // Vocational Showcase Form State
  const [showAddProject, setShowAddProject] = useState(false);
  const [projTitle, setProjTitle] = useState('');
  const [projCategory, setProjCategory] = useState('UMKM & Kewirausahaan');
  const [projDesc, setProjDesc] = useState('');
  const [projImpact, setProjImpact] = useState('');
  const [projAddedSuccess, setProjAddedSuccess] = useState(false);

  // Active Quiz taking states
  const [activeQuiz, setActiveQuiz] = useState<Test | null>(null);
  const [selectedAnswers, setSelectedAnswers] = useState<Record<string, number>>({});
  const [quizFinished, setQuizFinished] = useState(false);
  const [quizScoreResult, setQuizScoreResult] = useState<{ score: number; correct: number; total: number } | null>(null);

  // Official print/PDF preview modal state
  const [showPrintModal, setShowPrintModal] = useState(false);

  // AI Tutor states
  const [lessonSubTab, setLessonSubTab] = useState<'MATERI' | 'TUTOR'>('MATERI');
  const [chatHistories, setChatHistories] = useState<Record<string, { role: 'user' | 'assistant', text: string }[]>>({});
  const [chatInput, setChatInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const chatEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (lessonSubTab === 'TUTOR') {
      setTimeout(() => {
        chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
      }, 50);
    }
  }, [lessonSubTab, chatHistories, activeLesson?.id]);

  const handleSendMessage = async (textToSend: string) => {
    if (!textToSend.trim() || isTyping || !activeLesson) return;

    const currentHistory = chatHistories[activeLesson.id] || [
      {
        role: 'assistant' as const,
        text: `Halo! Saya adalah Tutor KesetaraanPlus, asisten belajarmu untuk modul "${activeLesson.title}". Ada bagian video atau kuis yang ingin kamu diskusikan? Tanyakan saja, saya siap membantu memberikan petunjuk!`
      }
    ];

    const newUserMessage = { role: 'user' as const, text: textToSend };
    const updatedHistory = [...currentHistory, newUserMessage];

    setChatHistories(prev => ({
      ...prev,
      [activeLesson.id]: updatedHistory
    }));
    setChatInput('');
    setIsTyping(true);

    try {
      const response = await fetch('/api/tutor/chat', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          lessonTitle: activeLesson.title,
          lessonDescription: activeLesson.description,
          messages: updatedHistory
        })
      });

      if (!response.ok) {
        const errData = await response.json();
        throw new Error(errData.error || 'Gagal menghubungi Tutor AI.');
      }

      const data = await response.json();
      const newAssistantMessage = { role: 'assistant' as const, text: data.text };

      setChatHistories(prev => ({
        ...prev,
        [activeLesson.id]: [...updatedHistory, newAssistantMessage]
      }));
    } catch (error: any) {
      console.error('Tutor AI Error:', error);
      const errorMessage = {
        role: 'assistant' as const,
        text: `Maaf, saya sedang mengalami kendala koneksi: ${error.message || 'Gagal merespons'}. Silakan coba kirim ulang pesan Anda.`
      };
      setChatHistories(prev => ({
        ...prev,
        [activeLesson.id]: [...updatedHistory, errorMessage]
      }));
    } finally {
      setIsTyping(false);
    }
  };

  const handleAskTutorForQuestion = (questionText: string, options: string[]) => {
    const formattedOptions = options.map((opt, idx) => `${String.fromCharCode(65 + idx)}. ${opt}`).join(', ');
    const promptText = `Saya sedang mengerjakan kuis dan butuh petunjuk untuk pertanyaan berikut:
"${questionText}"

Pilihan jawabannya: [ ${formattedOptions} ]

Bisakah Anda memberikan konsep kunci atau cara memikirkan soal ini tanpa membocorkan kunci jawaban langsung?`;

    setLessonSubTab('TUTOR');
    handleSendMessage(promptText);
  };

  const studentLessons = lessons.filter(l => l.package === selectedPkg);
  const myAttempts = attempts.filter(a => a.studentId === currentUser?.id);
  const myReportCard = reportCards.find(rc => rc.studentId === currentUser?.id) || {
    id: 'rep-001',
    studentId: currentUser?.id || 'std-001',
    studentName: currentUser?.name || 'Siswa',
    package: selectedPkg,
    grades: [
      { subject: 'PPKn', preTestScore: null, postTestScore: null, finalScore: 0, teacherNote: 'Siswa baru.' }
    ],
    attendanceRate: 100,
    characterNote: 'Siswa baru terdaftar.',
    status: 'Sedang Belajar',
    updatedAt: '',
    academicYear: '2025/2026 - Genap'
  };

  // Helper to check if a test has been completed
  const hasCompletedTest = (lessonId: string, type: 'pretest' | 'posttest') => {
    return myAttempts.some(a => a.lessonId === lessonId && a.type === type);
  };

  const getTestScore = (lessonId: string, type: 'pretest' | 'posttest') => {
    const attempt = myAttempts.find(a => a.lessonId === lessonId && a.type === type);
    return attempt ? attempt.score : null;
  };

  // Start taking a quiz
  const handleStartQuiz = (lessonId: string, type: 'pretest' | 'posttest') => {
    const quiz = tests.find(t => t.lessonId === lessonId && t.type === type);
    if (!quiz) {
      alert(`Mohon maaf, Guru pengajar belum merilis soal kuis ${type} untuk pelajaran ini.`);
      return;
    }
    setActiveQuiz(quiz);
    setSelectedAnswers({});
    setQuizFinished(false);
    setQuizScoreResult(null);
  };

  const handleOptionSelect = (questionId: string, optionIdx: number) => {
    setSelectedAnswers(prev => ({
      ...prev,
      [questionId]: optionIdx
    }));
  };

  const handleSubmitQuiz = () => {
    if (!activeQuiz) return;

    // Verify all answered
    const unanswered = activeQuiz.questions.some(q => selectedAnswers[q.id] === undefined);
    if (unanswered) {
      alert("Mohon isi semua pertanyaan kuis sebelum mengirimkan jawaban.");
      return;
    }

    let correctCount = 0;
    activeQuiz.questions.forEach(q => {
      if (selectedAnswers[q.id] === q.correctAnswerIndex) {
        correctCount++;
      }
    });

    const score = Math.round((correctCount / activeQuiz.questions.length) * 100);

    // Save attempt to database
    submitTestAttempt({
      studentId: currentUser?.id || 'std-001',
      studentName: currentUser?.name || 'Siswa',
      lessonId: activeQuiz.lessonId,
      testId: activeQuiz.id,
      type: activeQuiz.type,
      score,
      correctCount,
      totalQuestions: activeQuiz.questions.length
    });

    setQuizScoreResult({
      score,
      correct: correctCount,
      total: activeQuiz.questions.length
    });
    setQuizFinished(true);
  };

  // Web Audio API Binaural Focus Engine (Alpha Waves 432Hz - 10Hz) for Protokol Homeostasis
  const toggleAudioFocus = () => {
    if (isAudioPlaying) {
      if (audioCtxRef.current) {
        try {
          audioCtxRef.current.close();
        } catch (e) {}
        audioCtxRef.current = null;
      }
      setIsAudioPlaying(false);
    } else {
      try {
        const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
        const ctx = new AudioCtx();
        audioCtxRef.current = ctx;

        const gainNode = ctx.createGain();
        gainNode.gain.setValueAtTime(audioVolume, ctx.currentTime);
        gainNode.connect(ctx.destination);
        gainNodeRef.current = gainNode;

        // Warm sine 432Hz & 442Hz binaural 10Hz alpha differential
        const osc1 = ctx.createOscillator();
        osc1.type = 'sine';
        osc1.frequency.setValueAtTime(432, ctx.currentTime);

        const osc2 = ctx.createOscillator();
        osc2.type = 'sine';
        osc2.frequency.setValueAtTime(442, ctx.currentTime);

        const osc3 = ctx.createOscillator();
        osc3.type = 'triangle';
        osc3.frequency.setValueAtTime(216, ctx.currentTime);

        osc1.connect(gainNode);
        osc2.connect(gainNode);
        osc3.connect(gainNode);

        osc1.start();
        osc2.start();
        osc3.start();

        setIsAudioPlaying(true);
      } catch (err) {
        console.error('AudioContext start error:', err);
      }
    }
  };

  const handleVolumeChange = (v: number) => {
    setAudioVolume(v);
    if (gainNodeRef.current && audioCtxRef.current) {
      gainNodeRef.current.gain.setValueAtTime(v, audioCtxRef.current.currentTime);
    }
  };

  // Save Goal Handler
  const handleSaveGoal = (e: React.FormEvent) => {
    e.preventDefault();
    if (!targetCareerInput || !motivationInput) return;

    saveStudentGoal({
      studentId: currentUser?.id || 'std-001',
      studentName: currentUser?.name || 'Siswa',
      package: selectedPkg,
      targetCareer: targetCareerInput,
      motivationReason: motivationInput,
      targetGraduationYear: gradYearInput,
      skillsToMaster: skillsInput.split(',').map(s => s.trim()).filter(Boolean)
    });

    setGoalSavedSuccess(true);
    setTimeout(() => setGoalSavedSuccess(false), 2000);
  };

  // Submit Verpal Quiz Handler
  const handleVerpalAnswer = (itemId: string, userBelievesTrue: boolean) => {
    setVerpalAnswers(prev => ({
      ...prev,
      [itemId]: userBelievesTrue
    }));
  };

  // Create Project Handler
  const handleCreateProject = (e: React.FormEvent) => {
    e.preventDefault();
    if (!projTitle || !projDesc) return;

    addVocationalProject({
      studentId: currentUser?.id || 'std-001',
      studentName: currentUser?.name || 'Siswa',
      package: selectedPkg,
      title: projTitle,
      category: projCategory,
      description: projDesc,
      communityImpact: projImpact || 'Membantu memberdayakan ekonomi lokal.',
      imageUrl: 'https://images.unsplash.com/photo-1522202176988-66273c2fd55f?w=600'
    });

    setProjAddedSuccess(true);
    setTimeout(() => {
      setProjAddedSuccess(false);
      setShowAddProject(false);
      setProjTitle('');
      setProjDesc('');
      setProjImpact('');
    }, 1500);
  };

  // Excel Spreadsheet Downloader (Generates real styled CSV format)
  const downloadExcelReport = () => {
    let csvContent = "data:text/csv;charset=utf-8,\n";
    csvContent += "=========================================\n";
    csvContent += "      LAPORAN RAPORT NILAI AKADEMIK\n";
    csvContent += "      PKBM KESETARAAN EDUSETARA\n";
    csvContent += "=========================================\n\n";
    csvContent += `Nama Siswa,${myReportCard.studentName}\n`;
    csvContent += `Program Kesetaraan,${myReportCard.package}\n`;
    csvContent += `Tahun Akademik,${myReportCard.academicYear}\n`;
    csvContent += `Persentase Kehadiran,${myReportCard.attendanceRate}%\n`;
    csvContent += `Status Belajar,${myReportCard.status}\n\n`;
    csvContent += "Subject/Mata Pelajaran,Nilai Pre-Test,Nilai Post-Test,Nilai Akhir (Raport),Catatan Guru\n";

    myReportCard.grades.forEach(g => {
      const pre = g.preTestScore !== null ? g.preTestScore : "-";
      const post = g.postTestScore !== null ? g.postTestScore : "-";
      csvContent += `"${g.subject}",${pre},${post},${g.finalScore},"${g.teacherNote}"\n`;
    });

    csvContent += `\nCatatan Sikap & Karakter,"${myReportCard.characterNote}"\n`;

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `raport_setara_${myReportCard.studentName.replace(/\s+/g, '_')}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-8 animate-fade-in">
      
      {/* Dynamic Student Header with Homeostasis Audio Widget */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
        <div className="flex items-center gap-4">
          <img
            src={currentUser?.avatar || "https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=150"}
            alt={currentUser?.name}
            className="w-16 h-16 rounded-2xl object-cover border border-slate-200"
          />
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-emerald-700 bg-emerald-50 px-3 py-1 rounded-full uppercase tracking-widest">
                Siswa Belajar • {selectedPkg === 'Paket A' ? 'Paket A (Setara SD)' : selectedPkg === 'Paket B' ? 'Paket B (Setara SMP)' : 'Paket C (Setara SMA)'}
              </span>
              <span className="text-[10px] font-bold text-indigo-700 bg-indigo-50 px-2.5 py-0.5 rounded-full flex items-center gap-1">
                <Sparkles className="w-3 h-3 text-indigo-600" /> S.O.K.S LitOS
              </span>
            </div>
            <h1 className="text-2xl font-black text-slate-900 mt-1">{currentUser?.name}</h1>
            <p className="text-sm text-slate-500">Pusat Pembelajaran Kesetaraan Interaktif berbasis Navigasi Kesadaran S.O.K.S.</p>
          </div>
        </div>

        {/* Audio Focus (Protokol Homeostasis) Control Bar */}
        <div className="bg-slate-900 text-white p-3.5 rounded-xl flex items-center gap-4 shadow-md border border-slate-800">
          <button
            onClick={toggleAudioFocus}
            className={`w-10 h-10 rounded-lg flex items-center justify-center transition-all cursor-pointer ${
              isAudioPlaying 
                ? 'bg-emerald-500 text-slate-950 shadow-lg shadow-emerald-500/30 animate-pulse' 
                : 'bg-slate-800 hover:bg-slate-700 text-slate-300'
            }`}
            title={isAudioPlaying ? 'Matikan Suara Fokus' : 'Aktifkan Gelombang Fokus Alpha'}
          >
            {isAudioPlaying ? <Volume2 className="w-5 h-5" /> : <VolumeX className="w-5 h-5" />}
          </button>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="text-[10px] font-black uppercase tracking-wider text-emerald-400">Suara Fokus Alpha (LitOS)</span>
              {isAudioPlaying && <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />}
            </div>
            <p className="text-xs text-slate-300 font-medium">
              {isAudioPlaying ? 'Gelombang 432Hz Aktif (Pembersihan Noise & Cemas)' : 'Klik untuk meredakan cemas & merangsang fokus'}
            </p>
          </div>
          {isAudioPlaying && (
            <div className="hidden sm:flex items-center gap-2 border-l border-slate-800 pl-4">
              <Sliders className="w-3.5 h-3.5 text-slate-400" />
              <input
                type="range"
                min="0.05"
                max="0.5"
                step="0.05"
                value={audioVolume}
                onChange={(e) => handleVolumeChange(parseFloat(e.target.value))}
                className="w-16 accent-emerald-500 cursor-pointer"
              />
            </div>
          )}
        </div>
      </div>

      {/* Modern 5-Protocol Tabs */}
      <div className="flex overflow-x-auto no-scrollbar border-b border-slate-200 gap-2 bg-slate-100 p-1.5 rounded-2xl">
        <button
          onClick={() => setActiveTab('BELAJAR')}
          className={`px-4 py-2.5 text-xs font-bold rounded-xl transition-all flex items-center gap-2 whitespace-nowrap cursor-pointer ${
            activeTab === 'BELAJAR' ? 'bg-white text-indigo-700 shadow-sm' : 'text-slate-600 hover:text-indigo-600'
          }`}
        >
          <BookOpen className="w-4 h-4" />
          <span>Modul & AI Tutor ({studentLessons.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('TARGET_GOAL')}
          className={`px-4 py-2.5 text-xs font-bold rounded-xl transition-all flex items-center gap-2 whitespace-nowrap cursor-pointer ${
            activeTab === 'TARGET_GOAL' ? 'bg-white text-indigo-700 shadow-sm' : 'text-slate-600 hover:text-indigo-600'
          }`}
        >
          <Target className="w-4 h-4 text-amber-500" />
          <span>Cita-Cita & Target</span>
        </button>

        <button
          onClick={() => setActiveTab('VERPAL')}
          className={`px-4 py-2.5 text-xs font-bold rounded-xl transition-all flex items-center gap-2 whitespace-nowrap cursor-pointer ${
            activeTab === 'VERPAL' ? 'bg-white text-indigo-700 shadow-sm' : 'text-slate-600 hover:text-indigo-600'
          }`}
        >
          <ShieldCheck className="w-4 h-4 text-blue-500" />
          <span>Indeks Verpal (Literasi Fakta)</span>
        </button>

        <button
          onClick={() => setActiveTab('KARYA')}
          className={`px-4 py-2.5 text-xs font-bold rounded-xl transition-all flex items-center gap-2 whitespace-nowrap cursor-pointer ${
            activeTab === 'KARYA' ? 'bg-white text-indigo-700 shadow-sm' : 'text-slate-600 hover:text-indigo-600'
          }`}
        >
          <Briefcase className="w-4 h-4 text-emerald-500" />
          <span>Showcase Karya Vokasi ({vocationalProjects.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('RAPORT')}
          className={`px-4 py-2.5 text-xs font-bold rounded-xl transition-all flex items-center gap-2 whitespace-nowrap cursor-pointer ${
            activeTab === 'RAPORT' ? 'bg-white text-indigo-700 shadow-sm' : 'text-slate-600 hover:text-indigo-600'
          }`}
        >
          <Award className="w-4 h-4 text-purple-500" />
          <span>E-Raport Otomatis</span>
        </button>
      </div>

      {/* BELAJAR TAB */}
      {activeTab === 'BELAJAR' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Lessons List Side */}
          <div className="space-y-4 lg:col-span-1">
            <h3 className="text-sm font-black text-slate-400 uppercase tracking-wider">Modul Video {selectedPkg}</h3>
            {studentLessons.length === 0 ? (
              <div className="p-8 text-center text-xs text-slate-400 bg-white border border-slate-200 rounded-xl">
                Belum ada modul pelajaran di Paket ini.
              </div>
            ) : (
              <div className="space-y-3">
                {studentLessons.map((les) => {
                  const isActive = activeLesson?.id === les.id;
                  const preDone = hasCompletedTest(les.id, 'pretest');
                  const postDone = hasCompletedTest(les.id, 'posttest');

                  return (
                    <div
                      key={les.id}
                      onClick={() => {
                        setActiveLesson(les);
                        setActiveQuiz(null); // Reset quiz view when switching lesson
                        setLessonSubTab('MATERI');
                      }}
                      className={`p-4 border rounded-2xl cursor-pointer transition-all text-left flex justify-between items-start gap-4 ${
                        isActive 
                          ? 'bg-indigo-600 border-indigo-600 text-white shadow-md shadow-indigo-100' 
                          : 'bg-white border-slate-200 hover:border-slate-300 text-slate-800'
                      }`}
                    >
                      <div>
                        <span className={`text-[9px] font-bold px-2 py-0.5 rounded-full ${
                          isActive ? 'bg-indigo-500 text-white' : 'bg-slate-100 text-slate-600'
                        }`}>
                          {les.subject}
                        </span>
                        <h4 className="text-sm font-bold mt-2 line-clamp-1">{les.title}</h4>
                        <p className={`text-xs mt-1 font-medium ${isActive ? 'text-indigo-100' : 'text-slate-400'}`}>
                          Pengajar: {les.teacherName}
                        </p>
                      </div>

                      <div className="flex flex-col items-end justify-between h-full gap-4">
                        <ChevronRight className={`w-4 h-4 ${isActive ? 'text-white' : 'text-slate-300'}`} />
                        <div className="flex gap-1.5">
                          {preDone && (
                            <span className="text-[9px] font-black bg-emerald-100 text-emerald-800 px-1.5 py-0.5 rounded-full" title="Pretest selesai">PRE</span>
                          )}
                          {postDone && (
                            <span className="text-[9px] font-black bg-emerald-100 text-emerald-800 px-1.5 py-0.5 rounded-full" title="Posttest selesai">POST</span>
                          )}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* Interactive Player & Quiz Side */}
          <div className="lg:col-span-2 space-y-6">
            {activeLesson ? (
              <div className="bg-white border border-slate-200 shadow-sm rounded-2xl overflow-hidden p-6 space-y-6">
                
                {/* Modern Sub-Tab Navigation */}
                <div className="flex border-b border-slate-100 pb-2 justify-between items-center">
                  <div className="flex gap-4">
                    <button
                      onClick={() => setLessonSubTab('MATERI')}
                      className={`pb-2 text-xs font-black relative transition-all uppercase tracking-wider cursor-pointer ${
                        lessonSubTab === 'MATERI' ? 'text-indigo-600' : 'text-slate-400 hover:text-slate-600'
                      }`}
                    >
                      <span>Modul Belajar & Kuis</span>
                      {lessonSubTab === 'MATERI' && (
                        <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-indigo-600" />
                      )}
                    </button>
                    <button
                      onClick={() => setLessonSubTab('TUTOR')}
                      className={`pb-2 text-xs font-black relative transition-all flex items-center gap-1.5 uppercase tracking-wider cursor-pointer ${
                        lessonSubTab === 'TUTOR' ? 'text-indigo-600 font-extrabold' : 'text-slate-400 hover:text-slate-600'
                      }`}
                    >
                      <Sparkles className="w-3.5 h-3.5 text-amber-500 fill-current" />
                      <span>Tanya Tutor AI</span>
                      {lessonSubTab === 'TUTOR' && (
                        <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-indigo-600" />
                      )}
                    </button>
                  </div>
                  
                  <span className="hidden sm:inline text-[9px] font-black uppercase tracking-widest text-slate-400 bg-slate-50 border border-slate-200/60 px-2.5 py-1 rounded-lg">
                    Bimbingan Belajar Siswa
                  </span>
                </div>

                {lessonSubTab === 'MATERI' ? (
                  <>
                    {/* Embedded Video Simulator */}
                    <div className="aspect-video w-full rounded-xl bg-slate-950 flex flex-col items-center justify-center relative overflow-hidden text-white border border-slate-900 group">
                      <div className="absolute inset-0 bg-cover bg-center opacity-30 filter blur-xs" style={{ backgroundImage: "url('https://images.unsplash.com/photo-1516321318423-f06f85e504b3?w=600')" }} />
                      <div className="z-10 text-center space-y-3 p-4">
                        <div className="w-16 h-16 rounded-full bg-indigo-600/90 group-hover:bg-indigo-600 flex items-center justify-center mx-auto cursor-pointer border border-white/20 shadow-xl shadow-indigo-900/40 transition-all transform hover:scale-105">
                          <Play className="w-8 h-8 fill-current ml-1" />
                        </div>
                        <p className="font-bold text-sm sm:text-base tracking-wide px-3">{activeLesson.title}</p>
                        <p className="text-xs text-slate-300 font-mono">Modul Video: {activeLesson.videoDuration} Mins • {activeLesson.subject}</p>
                      </div>
                      <div className="absolute bottom-4 left-4 right-4 z-10 flex justify-between items-center text-xs text-slate-400">
                        <span>0:00 / {activeLesson.videoDuration}</span>
                        <div className="flex-1 mx-4 h-1.5 bg-slate-800 rounded-full overflow-hidden">
                          <div className="w-1/3 bg-indigo-500 h-full rounded-full" />
                        </div>
                        <span>30% Watched</span>
                      </div>
                    </div>

                    <div className="space-y-4">
                      <div className="flex items-start justify-between gap-4 border-b border-slate-50 pb-4">
                        <div>
                          <h3 className="text-lg font-black text-slate-900">{activeLesson.title}</h3>
                          <p className="text-xs text-slate-400 mt-1">Materi diajarkan oleh <span className="font-bold text-slate-700">{activeLesson.teacherName}</span></p>
                        </div>
                        <span className="text-xs font-black bg-slate-100 text-slate-700 px-3 py-1 rounded">
                          {activeLesson.package}
                        </span>
                      </div>

                      <p className="text-sm text-slate-600 leading-relaxed bg-slate-50 p-4 rounded-xl border border-slate-200/50">
                        <span className="font-extrabold text-slate-800 block mb-1">Rincian Modul Pembelajaran:</span>
                        {activeLesson.description}
                      </p>
                    </div>

                    {/* Quizzes/Assessment Block */}
                    <div className="border-t border-slate-200 pt-6 space-y-4">
                      <h4 className="text-sm font-black text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
                        <Award className="text-indigo-600 w-4 h-4" /> Evaluasi Kompetensi Siswa Belajar
                      </h4>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        {/* Pretest Block */}
                        <div className="p-4 rounded-xl border border-slate-200 bg-slate-50/50 flex flex-col justify-between gap-3">
                          <div>
                            <h5 className="text-xs font-bold text-slate-800">Pre-test (Sebelum Belajar)</h5>
                            <p className="text-[10px] text-slate-400 mt-1">Ukur kemampuan awal Anda terhadap materi video ini.</p>
                          </div>
                          
                          {hasCompletedTest(activeLesson.id, 'pretest') ? (
                            <div className="flex items-center justify-between text-xs font-bold mt-2 bg-emerald-50 text-emerald-700 p-2.5 rounded-lg border border-emerald-100">
                              <span className="flex items-center gap-1"><CheckCircle2 className="w-4 h-4 text-emerald-600" /> Selesai</span>
                              <span>Skor: {getTestScore(activeLesson.id, 'pretest')} / 100</span>
                            </div>
                          ) : (
                            <button
                              onClick={() => handleStartQuiz(activeLesson!.id, 'pretest')}
                              className="w-full mt-2 py-2 text-xs font-bold bg-indigo-600 text-white hover:bg-indigo-700 rounded-lg transition-all flex items-center justify-center gap-1 cursor-pointer"
                            >
                              Mulai Pre-test <ChevronRight className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>

                        {/* Posttest Block */}
                        <div className="p-4 rounded-xl border border-slate-200 bg-slate-50/50 flex flex-col justify-between gap-3">
                          <div>
                            <h5 className="text-xs font-bold text-slate-800">Post-test (Ujian Akhir Modul)</h5>
                            <p className="text-[10px] text-slate-400 mt-1">Kerjakan setelah tuntas menonton seluruh video modul di atas.</p>
                          </div>

                          {hasCompletedTest(activeLesson.id, 'posttest') ? (
                            <div className="flex items-center justify-between text-xs font-bold mt-2 bg-indigo-50 text-indigo-700 p-2.5 rounded-lg border border-indigo-100">
                              <span className="flex items-center gap-1"><CheckCircle2 className="w-4 h-4 text-indigo-600" /> Tuntas</span>
                              <span>Skor: {getTestScore(activeLesson.id, 'posttest')} / 100</span>
                            </div>
                          ) : (
                            <button
                              disabled={!hasCompletedTest(activeLesson.id, 'pretest')}
                              onClick={() => handleStartQuiz(activeLesson!.id, 'posttest')}
                              className={`w-full mt-2 py-2 text-xs font-bold rounded-lg transition-all flex items-center justify-center gap-1 cursor-pointer ${
                                hasCompletedTest(activeLesson.id, 'pretest')
                                  ? 'bg-indigo-600 text-white hover:bg-indigo-700'
                                  : 'bg-slate-200 text-slate-400 cursor-not-allowed'
                              }`}
                            >
                              Mulai Post-test <ChevronRight className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>
                      </div>
                    </div>

                    {/* Active Test Drawer Overlay */}
                    {activeQuiz && (
                      <div className="p-6 border-t-2 border-indigo-600 bg-indigo-50/10 rounded-xl space-y-6 animate-fade-in mt-4">
                        <div className="flex items-center justify-between pb-3 border-b border-indigo-100/30">
                          <div>
                            <span className="text-[10px] font-black uppercase text-indigo-700 bg-indigo-50 border border-indigo-100 px-2 py-0.5 rounded-full">
                              Kuis Sedang Berlangsung ({activeQuiz.type.toUpperCase()})
                            </span>
                            <h4 className="text-sm font-bold text-slate-900 mt-1">{activeLesson.title}</h4>
                          </div>
                          <button
                            onClick={() => setActiveQuiz(null)}
                            className="text-xs font-semibold text-rose-600 hover:underline cursor-pointer"
                          >
                            Batal
                          </button>
                        </div>

                        {!quizFinished ? (
                          /* Playing quiz questions */
                          <div className="space-y-6">
                            {activeQuiz.questions.map((q, qIdx) => (
                              <div key={q.id} className="space-y-2.5 text-left">
                                <div className="flex items-start justify-between gap-4">
                                  <p className="text-sm font-bold text-slate-800 flex-1">
                                    {qIdx + 1}. {q.text}
                                  </p>
                                  <button
                                    onClick={() => handleAskTutorForQuestion(q.text, q.options)}
                                    className="shrink-0 flex items-center gap-1 text-[10px] font-black text-indigo-600 hover:text-indigo-700 bg-indigo-50 hover:bg-indigo-100 px-2.5 py-1 rounded-lg border border-indigo-100/30 transition-all cursor-pointer shadow-xs"
                                    title="Minta Petunjuk Tutor AI"
                                  >
                                    <Sparkles className="w-3 h-3 text-amber-500 fill-current" />
                                    <span>Petunjuk</span>
                                  </button>
                                </div>
                                <div className="space-y-2">
                                  {q.options.map((opt, optIdx) => {
                                    const isSelected = selectedAnswers[q.id] === optIdx;
                                    return (
                                      <div
                                        key={optIdx}
                                        onClick={() => handleOptionSelect(q.id, optIdx)}
                                        className={`p-3 rounded-xl border text-xs font-semibold cursor-pointer transition-all flex items-center gap-2.5 ${
                                          isSelected
                                            ? 'border-indigo-600 bg-indigo-50 text-indigo-900 font-bold'
                                            : 'border-slate-100 bg-white hover:border-slate-200 text-slate-600'
                                        }`}
                                      >
                                        <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold ${
                                          isSelected ? 'bg-indigo-600 text-white' : 'bg-slate-100 text-slate-500'
                                        }`}>
                                          {String.fromCharCode(65 + optIdx)}
                                        </span>
                                        <span>{opt}</span>
                                      </div>
                                    );
                                  })}
                                </div>
                              </div>
                            ))}

                            <button
                              onClick={handleSubmitQuiz}
                              className="w-full py-3 bg-indigo-600 hover:bg-indigo-700 text-white font-extrabold rounded-xl text-xs shadow-md shadow-indigo-100 transition-all cursor-pointer"
                            >
                              Kirimkan Jawaban Kuis
                            </button>
                          </div>
                        ) : (
                          /* Quiz score result success board */
                          <div className="text-center py-6 space-y-4">
                            <div className="inline-flex items-center justify-center p-3.5 bg-emerald-100 text-emerald-800 rounded-full mb-2">
                              <Check className="w-8 h-8" />
                            </div>
                            <h4 className="text-lg font-black text-slate-900">Kuis Selesai Dikerjakan!</h4>
                            
                            <div className="bg-white p-5 rounded-2xl border border-slate-100 max-w-xs mx-auto text-center space-y-2.5">
                              <p className="text-xs font-bold text-slate-400 uppercase tracking-widest">Skor Kuis Anda</p>
                              <p className="text-4xl font-black text-indigo-700">{quizScoreResult?.score} <span className="text-xs text-slate-400 font-bold">/ 100</span></p>
                              <p className="text-xs text-slate-500">
                                Menjawab benar <span className="font-bold text-slate-800">{quizScoreResult?.correct}</span> dari {quizScoreResult?.total} pertanyaan kuis.
                              </p>
                            </div>

                            <button
                              onClick={() => setActiveQuiz(null)}
                              className="px-6 py-2.5 bg-indigo-600 text-white rounded-xl text-xs font-bold hover:bg-indigo-700 transition-all cursor-pointer"
                            >
                              Tutup & Selesai
                            </button>
                          </div>
                        )}
                      </div>
                    )}
                  </>
                ) : (
                  /* AISmartTutor Component (Gemini 3.6 Flash S.O.K.S & MKL Mentor) */
                  <AISmartTutor 
                    currentLesson={activeLesson} 
                    onSelectLesson={(l) => setActiveLesson(l)} 
                    compact={true} 
                  />
                )}
              </div>
            ) : (
              <div className="h-full bg-white border border-slate-100 rounded-2xl p-12 text-center flex flex-col justify-center items-center shadow-sm">
                <GraduationCap className="w-16 h-16 text-slate-200 mb-4" />
                <h3 className="text-lg font-bold text-slate-800">Mulai Sesi Pembelajaran Kesetaraan</h3>
                <p className="text-xs text-slate-400 mt-1 max-w-sm">
                  Pilih salah satu video pelajaran di menu samping kiri untuk memulai belajar, menonton pemaparan modul, dan menjawab kuis penilaian.
                </p>
              </div>
            )}
          </div>
        </div>
      )}

      {/* TARGET_GOAL TAB (Protokol Kebangkitan & Target Cita-Cita) */}
      {activeTab === 'TARGET_GOAL' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 animate-fade-in">
          <div className="lg:col-span-1 space-y-6">
            <div className="bg-gradient-to-br from-amber-500 to-amber-600 text-white p-6 rounded-2xl shadow-md space-y-3">
              <span className="text-[10px] font-black uppercase tracking-widest bg-black/20 px-2.5 py-1 rounded-full">
                Fase 2: Protokol Kebangkitan
              </span>
              <h3 className="text-xl font-black">Target & Visi Hidup</h3>
              <p className="text-xs text-amber-100 leading-relaxed">
                Memetakan cita-cita karier, alasan terdalam belajar, dan keahlian yang ingin dikuasai agar proses pendidikan kesetaraan berorientasi karya nyata.
              </p>
              <div className="pt-2 flex items-center gap-2 text-xs font-bold bg-white/10 p-3 rounded-xl border border-white/20">
                <Target className="w-5 h-5 text-amber-200" />
                <span>Target Kelulusan: {gradYearInput || '2026'}</span>
              </div>
            </div>

            <div className="bg-white border border-slate-200 p-6 rounded-2xl shadow-sm space-y-4">
              <h4 className="text-sm font-black text-slate-800">Prinsip Unlearning S.O.K.S</h4>
              <p className="text-xs text-slate-500 leading-relaxed">
                Pendidikan kesetaraan bukan sekadar mengejar lembar Ijazah, melainkan proses kebangkitan kesadaran diri (Fitrah) untuk menjadi pribadi mandiri yang memberi manfaat luas bagi masyarakat.
              </p>
            </div>
          </div>

          <div className="lg:col-span-2 bg-white border border-slate-200 p-6 rounded-2xl shadow-sm space-y-6">
            <div className="flex justify-between items-center border-b border-slate-100 pb-4">
              <div>
                <h3 className="text-base font-black text-slate-900">Formulir Cita-Cita & Komitmen Belajar</h3>
                <p className="text-xs text-slate-400">Atur tujuan masa depanmu yang dapat dilihat oleh Guru & Pembimbing</p>
              </div>
              {goalSavedSuccess && (
                <span className="text-xs font-bold text-emerald-700 bg-emerald-50 px-3 py-1.5 rounded-xl border border-emerald-200 flex items-center gap-1.5 animate-bounce">
                  <CheckCircle2 className="w-4 h-4" /> Target Tersimpan!
                </span>
              )}
            </div>

            <form onSubmit={handleSaveGoal} className="space-y-4 text-xs">
              <div>
                <label className="block font-bold text-slate-700 mb-1">Cita-Cita / Profesi Impian</label>
                <input
                  type="text"
                  value={targetCareerInput}
                  onChange={(e) => setTargetCareerInput(e.target.value)}
                  placeholder="Contoh: Wirausahawan Kuliner, Graphic Designer, Teknisi Komputer..."
                  className="w-full p-3 border border-slate-200 rounded-xl bg-slate-50 focus:bg-white focus:outline-hidden focus:border-amber-500 font-bold text-slate-900"
                  required
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Motivasi & Tergeraknya Batin Belajar (Alasan Utama)</label>
                <textarea
                  rows={3}
                  value={motivationInput}
                  onChange={(e) => setMotivationInput(e.target.value)}
                  placeholder="Ceritakan alasan terkuatmu melanjutkan sekolah kesetaraan Paket ini..."
                  className="w-full p-3 border border-slate-200 rounded-xl bg-slate-50 focus:bg-white focus:outline-hidden focus:border-amber-500 text-slate-800"
                  required
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Target Tahun Kelulusan</label>
                  <select
                    value={gradYearInput}
                    onChange={(e) => setGradYearInput(e.target.value)}
                    className="w-full p-3 border border-slate-200 rounded-xl bg-slate-50 focus:bg-white focus:outline-hidden focus:border-amber-500 text-slate-800 font-bold"
                  >
                    <option value="2025">2025</option>
                    <option value="2026">2026</option>
                    <option value="2027">2027</option>
                  </select>
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Keahlian Utama yang Ingin Dikuasai (Pisahkan Koma)</label>
                  <input
                    type="text"
                    value={skillsInput}
                    onChange={(e) => setSkillsInput(e.target.value)}
                    placeholder="Contoh: Manajemen, Bahasa Inggris, Desain"
                    className="w-full p-3 border border-slate-200 rounded-xl bg-slate-50 focus:bg-white focus:outline-hidden focus:border-amber-500 text-slate-800"
                  />
                </div>
              </div>

              <div className="pt-2 flex justify-end">
                <button
                  type="submit"
                  className="px-6 py-3 bg-amber-500 hover:bg-amber-600 text-white font-bold rounded-xl shadow-md shadow-amber-200 transition-all cursor-pointer flex items-center gap-2"
                >
                  <Target className="w-4 h-4" /> Simpan Target Cita-Cita
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* VERPAL TAB (Indeks Verpal & Validasi Literasi Digital) */}
      {activeTab === 'VERPAL' && (
        <div className="space-y-6 animate-fade-in">
          <div className="bg-gradient-to-r from-blue-950 to-indigo-900 text-white p-6 rounded-2xl shadow-md flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
            <div className="space-y-1.5">
              <span className="text-[10px] font-black uppercase tracking-widest bg-blue-500/20 text-blue-300 border border-blue-400/30 px-2.5 py-1 rounded-full">
                Fase 4: Protokol Verpal & Integritas Kebenaran
              </span>
              <h3 className="text-xl font-black">Uji Indeks Verpal (V) & Literasi Informasi</h3>
              <p className="text-xs text-blue-200">
                Latih kemampuan membedakan fakta ilmiah/resmi dari berita palsu (hoax) dan disinformasi digital.
              </p>
            </div>

            <div className="bg-white/10 p-4 rounded-xl border border-white/10 text-center shrink-0">
              <p className="text-[10px] font-bold uppercase text-blue-200">Indeks Verpal Saya</p>
              <p className="text-3xl font-black text-emerald-400">96.8%</p>
              <span className="text-[9px] text-emerald-300 font-bold">Kategori: Sangat Kritis & Valid</span>
            </div>
          </div>

          {/* Verpal Case Studies Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {verpalItems.map((item) => {
              const answered = verpalAnswers[item.id] !== undefined;
              const userChoice = verpalAnswers[item.id];
              const isCorrect = userChoice === item.isFact;

              return (
                <div key={item.id} className="bg-white border border-slate-200 p-6 rounded-2xl shadow-sm space-y-4 flex flex-col justify-between">
                  <div className="space-y-3">
                    <div className="flex justify-between items-center">
                      <span className="text-[10px] font-black uppercase text-indigo-700 bg-indigo-50 px-2.5 py-1 rounded-full">
                        {item.category}
                      </span>
                      <span className="text-[10px] font-bold text-slate-400">Verpal Case #{item.id.replace('verp-', '')}</span>
                    </div>
                    <p className="text-sm font-extrabold text-slate-900">{item.scenario}</p>
                  </div>

                  <div className="space-y-3 pt-2">
                    {!answered ? (
                      <div className="grid grid-cols-2 gap-3">
                        <button
                          onClick={() => handleVerpalAnswer(item.id, true)}
                          className="py-2.5 px-3 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 text-emerald-800 font-extrabold text-xs rounded-xl transition-all cursor-pointer"
                        >
                          ✓ Ini FAKTA / RESMI
                        </button>
                        <button
                          onClick={() => handleVerpalAnswer(item.id, false)}
                          className="py-2.5 px-3 bg-rose-50 hover:bg-rose-100 border border-rose-200 text-rose-800 font-extrabold text-xs rounded-xl transition-all cursor-pointer"
                        >
                          ✕ Ini HOAX / PALSU
                        </button>
                      </div>
                    ) : (
                      <div className={`p-4 rounded-xl text-xs space-y-2 ${
                        isCorrect ? 'bg-emerald-50 border border-emerald-200 text-emerald-900' : 'bg-rose-50 border border-rose-200 text-rose-900'
                      }`}>
                        <div className="flex items-center gap-2 font-black">
                          {isCorrect ? (
                            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                          ) : (
                            <AlertCircle className="w-4 h-4 text-rose-600" />
                          )}
                          <span>{isCorrect ? 'Analisis Tepat!' : 'Analisis Kurang Tepat'}</span>
                        </div>
                        <p className="text-[11px] leading-relaxed text-slate-700">
                          <strong className="block mb-0.5 font-bold">Penjelasan Verpal S.O.K.S:</strong>
                          {item.explanation}
                        </p>
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* KARYA TAB (Showcase Galeri Karya Vokasi PjBL - Protokol Koherensi) */}
      {activeTab === 'KARYA' && (
        <div className="space-y-6 animate-fade-in">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
            <div>
              <span className="text-[10px] font-black uppercase text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-full tracking-wider">
                Fase 5: Protokol Koherensi & Karya Vokasi
              </span>
              <h3 className="text-xl font-black text-slate-900 mt-1.5">Galeri Portfolio & Project-Based Learning (PjBL)</h3>
              <p className="text-xs text-slate-500">Showcase produk kreatif, kewirausahaan, dan kontribusi nyata siswa bagi masyarakat.</p>
            </div>

            <button
              onClick={() => setShowAddProject(true)}
              className="px-5 py-3 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-extrabold rounded-xl shadow-md shadow-emerald-100 transition-all cursor-pointer flex items-center gap-2 shrink-0"
            >
              <Plus className="w-4 h-4" /> Tambah Karya Saya
            </button>
          </div>

          {/* Project List Grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {vocationalProjects.map((proj) => (
              <div key={proj.id} className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-sm flex flex-col justify-between group hover:border-slate-300 transition-all">
                <div className="space-y-3">
                  <div className="h-44 w-full bg-slate-100 relative overflow-hidden">
                    <img
                      src={proj.imageUrl}
                      alt={proj.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-all duration-300"
                    />
                    <span className="absolute top-3 left-3 bg-slate-900/80 backdrop-blur-xs text-white text-[10px] font-bold px-2.5 py-1 rounded-lg">
                      {proj.category}
                    </span>
                    <span className="absolute top-3 right-3 bg-emerald-500 text-white text-[10px] font-black px-2 py-0.5 rounded-md shadow-xs">
                      Koherensi {proj.coherenceScore}%
                    </span>
                  </div>

                  <div className="p-5 space-y-2">
                    <h4 className="font-extrabold text-slate-900 text-sm line-clamp-1">{proj.title}</h4>
                    <p className="text-xs text-slate-500 line-clamp-2">{proj.description}</p>
                    <div className="p-3 bg-emerald-50 border border-emerald-100 rounded-xl text-[11px] text-emerald-900">
                      <span className="font-bold block mb-0.5">Dampak Masyarakat:</span>
                      "{proj.communityImpact}"
                    </div>
                  </div>
                </div>

                <div className="p-5 pt-0 flex justify-between items-center text-[11px] text-slate-400 border-t border-slate-100 mt-2">
                  <span>Oleh: <strong className="text-slate-700">{proj.studentName}</strong></span>
                  <span className="font-mono">{proj.package}</span>
                </div>
              </div>
            ))}
          </div>

          {/* Add Project Modal */}
          {showAddProject && (
            <div className="fixed inset-0 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4 z-50">
              <div className="bg-white rounded-2xl w-full max-w-lg p-6 space-y-4 shadow-xl border border-slate-200">
                <div className="flex justify-between items-center border-b border-slate-100 pb-3">
                  <h3 className="font-black text-slate-900 text-base">Unggah Karya Vokasi / Proyek Mandiri</h3>
                  <button onClick={() => setShowAddProject(false)} className="text-slate-400 hover:text-slate-600 font-bold text-sm">✕</button>
                </div>

                <form onSubmit={handleCreateProject} className="space-y-4 text-xs">
                  <div>
                    <label className="block font-bold text-slate-700 mb-1">Judul Karya / Produk</label>
                    <input
                      type="text"
                      value={projTitle}
                      onChange={(e) => setProjTitle(e.target.value)}
                      placeholder="Contoh: Keripik Tempe Aneka Rasa, Website UMKM..."
                      className="w-full p-3 border border-slate-200 rounded-xl bg-slate-50 focus:bg-white text-slate-900 font-bold"
                      required
                    />
                  </div>

                  <div>
                    <label className="block font-bold text-slate-700 mb-1">Kategori Vokasi</label>
                    <select
                      value={projCategory}
                      onChange={(e) => setProjCategory(e.target.value)}
                      className="w-full p-3 border border-slate-200 rounded-xl bg-slate-50 focus:bg-white text-slate-800 font-bold"
                    >
                      <option value="UMKM & Kewirausahaan">UMKM & Kewirausahaan</option>
                      <option value="Teknologi Digital & Koding">Teknologi Digital & Koding</option>
                      <option value="Seni & Kerajinan Lokal">Seni & Kerajinan Lokal</option>
                      <option value="Pertanian & Peternakan Organik">Pertanian & Peternakan Organik</option>
                    </select>
                  </div>

                  <div>
                    <label className="block font-bold text-slate-700 mb-1">Deskripsi Karya & Cara Kerja</label>
                    <textarea
                      rows={3}
                      value={projDesc}
                      onChange={(e) => setProjDesc(e.target.value)}
                      placeholder="Jelaskan mengenai produk, inovasi, atau jasa yang kamu buat..."
                      className="w-full p-3 border border-slate-200 rounded-xl bg-slate-50 focus:bg-white text-slate-800"
                      required
                    />
                  </div>

                  <div>
                    <label className="block font-bold text-slate-700 mb-1">Dampak Nyata bagi Lingkungan / Masyarakat</label>
                    <input
                      type="text"
                      value={projImpact}
                      onChange={(e) => setProjImpact(e.target.value)}
                      placeholder="Contoh: Bekerja sama dengan 5 petani lokal desa..."
                      className="w-full p-3 border border-slate-200 rounded-xl bg-slate-50 focus:bg-white text-slate-800"
                    />
                  </div>

                  <div className="pt-2 flex justify-end gap-2">
                    <button
                      type="button"
                      onClick={() => setShowAddProject(false)}
                      className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl cursor-pointer"
                    >
                      Batal
                    </button>
                    <button
                      type="submit"
                      className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl shadow-md cursor-pointer"
                    >
                      Publikasikan Karya
                    </button>
                  </div>
                </form>
              </div>
            </div>
          )}
        </div>
      )}
      {activeTab === 'RAPORT' && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6 space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h3 className="text-lg font-bold text-slate-900">Laporan Raport Nilai Akademik Otomatis</h3>
              <p className="text-xs text-slate-400">Pembaruan otomatis dari skor post-test video pembelajaran. Tersedia untuk unduhan file.</p>
            </div>

            <div className="flex gap-2">
              <button
                onClick={downloadExcelReport}
                className="flex items-center gap-1.5 px-4 py-2.5 text-xs font-bold border border-slate-200 hover:bg-slate-50 text-slate-700 rounded-xl transition-all cursor-pointer"
              >
                <FileSpreadsheet className="w-4 h-4 text-emerald-600" /> Unduh Format Excel
              </button>
              <button
                onClick={() => setShowPrintModal(true)}
                className="flex items-center gap-1.5 px-4 py-2.5 text-xs font-bold bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl shadow-md shadow-indigo-100 transition-all cursor-pointer"
              >
                <Printer className="w-4 h-4" /> Cetak Raport Resmi (PDF)
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            
            {/* Student Metadata Card */}
            <div className="border border-slate-200 bg-slate-50/50 p-5 rounded-2xl space-y-3 md:col-span-1 flex flex-col justify-between">
              <div className="space-y-3">
                <div className="flex items-center gap-3">
                  <img
                    src={currentUser?.avatar}
                    alt={currentUser?.name}
                    className="w-12 h-12 rounded-xl object-cover border border-slate-200"
                  />
                  <div>
                    <h4 className="font-extrabold text-slate-900">{myReportCard.studentName}</h4>
                    <span className="text-[10px] font-black uppercase text-indigo-700 bg-indigo-50 border border-indigo-100 px-1.5 py-0.5 rounded-full">
                      {myReportCard.package}
                    </span>
                  </div>
                </div>

                <div className="space-y-1.5 text-xs border-t border-slate-200 pt-3">
                  <p className="text-slate-400">Siswa ID: <span className="font-bold text-slate-800 float-right">{myReportCard.studentId}</span></p>
                  <p className="text-slate-400">Tahun Akademik: <span className="font-bold text-slate-800 float-right">{myReportCard.academicYear}</span></p>
                  <p className="text-slate-400">Kehadiran (Absen): <span className="font-bold text-slate-800 float-right">{myReportCard.attendanceRate}%</span></p>
                  <p className="text-slate-400">Status Akademik: <span className="font-bold text-emerald-600 float-right">{myReportCard.status}</span></p>
                </div>
              </div>

              <div className="p-3.5 bg-indigo-50 rounded-xl border border-indigo-100 text-[11px] text-indigo-800">
                <span className="font-bold block mb-0.5">Catatan Sikap & Karakter:</span>
                "{myReportCard.characterNote}"
              </div>
            </div>

            {/* Grades Table */}
            <div className="md:col-span-2 border border-slate-200 rounded-2xl overflow-hidden">
              <div className="bg-slate-50 p-4 border-b border-slate-200">
                <h4 className="text-xs font-black text-slate-400 uppercase tracking-wider">Hasil Penilaian Kompetensi Siswa</h4>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="border-b border-slate-200 text-[10px] text-slate-400 font-bold uppercase tracking-wider">
                      <th className="p-3">Mata Pelajaran</th>
                      <th className="p-3 text-center">Uji Pre-test</th>
                      <th className="p-3 text-center">Uji Post-test</th>
                      <th className="p-3 text-center">Nilai Akhir (Raport)</th>
                      <th className="p-3">Sikap Akademik / Catatan</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-50 text-xs">
                    {myReportCard.grades.map((g, idx) => (
                      <tr key={idx} className="hover:bg-slate-50/20">
                        <td className="p-3 font-bold text-slate-900">{g.subject}</td>
                        <td className="p-3 text-center font-semibold text-slate-500">
                          {g.preTestScore !== null ? `${g.preTestScore}` : '-'}
                        </td>
                        <td className="p-3 text-center font-semibold text-slate-500">
                          {g.postTestScore !== null ? `${g.postTestScore}` : '-'}
                        </td>
                        <td className="p-3 text-center">
                          <span className={`px-2 py-1 rounded font-black text-xs ${
                            g.finalScore >= 80 ? 'bg-emerald-50 text-emerald-700' : 'bg-indigo-50 text-indigo-700'
                          }`}>
                            {g.finalScore}
                          </span>
                        </td>
                        <td className="p-3 text-slate-500 max-w-xs truncate" title={g.teacherNote}>
                          {g.teacherNote}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Pristine Print-Preview official report card (National PKBM format modal) */}
      {showPrintModal && (
        <div className="fixed inset-0 bg-black/55 backdrop-blur-xs flex items-center justify-center p-4 z-50 overflow-y-auto">
          <div className="bg-white rounded-2xl w-full max-w-4xl p-8 space-y-6 relative border-4 border-double border-slate-300">
            
            {/* Modal action bar (Do not show when printing) */}
            <div className="flex justify-between items-center pb-4 border-b border-slate-200 print:hidden">
              <span className="text-xs font-bold text-slate-400 flex items-center gap-1.5">
                <Printer className="w-4 h-4" /> Layout Siap Cetak (Raport Hasil Belajar Resmi PKBM)
              </span>
              <div className="flex gap-2">
                <button
                  onClick={handlePrint}
                  className="px-4 py-2 text-xs font-black bg-indigo-600 text-white rounded-xl shadow-xs hover:bg-indigo-700 cursor-pointer"
                >
                  Konfirmasi Cetak / Simpan PDF
                </button>
                <button
                  onClick={() => setShowPrintModal(false)}
                  className="px-4 py-2 text-xs font-bold bg-slate-100 text-slate-600 rounded-xl hover:bg-slate-200 cursor-pointer"
                >
                  Tutup
                </button>
              </div>
            </div>

            {/* Print Area - Standard Physical Document format */}
            <div className="space-y-8 p-4 text-black font-serif print:p-0">
              {/* Official PKBM Header */}
              <div className="text-center border-b-4 border-double border-black pb-4">
                <p className="text-xs font-bold font-sans uppercase tracking-widest">KEMENTERIAN PENDIDIKAN, KEBUDAYAAN, RISET, DAN TEKNOLOGI</p>
                <h2 className="text-xl font-bold font-sans uppercase tracking-normal">PUSAT KEGIATAN BELAJAR MASYARAKAT (PKBM)</h2>
                <h1 className="text-3xl font-black font-sans uppercase text-indigo-800 tracking-wider">BSC EDUSETARA NASIONAL</h1>
                <p className="text-xs font-sans mt-1">Izin Operasional No: 421.9/308-Disdik/2025 • Website: portal.bscedusetara.sch.id</p>
                <p className="text-[10px] font-sans text-slate-500">Jl. Raya Kesetaraan No. 12, DKI Jakarta, Indonesia</p>
              </div>

              {/* Title */}
              <div className="text-center">
                <h3 className="text-base font-bold uppercase tracking-widest decoration-dotted underline">LAPORAN HASIL BELAJAR PESERTA DIDIK</h3>
                <p className="text-xs font-mono font-bold mt-1">PROGRAM KESETARAAN: {myReportCard.package.toUpperCase()}</p>
              </div>

              {/* Student Details Grid */}
              <div className="grid grid-cols-2 gap-4 text-xs font-sans">
                <div className="space-y-1">
                  <p><span className="w-32 inline-block text-slate-500">Nama Siswa</span>: <span className="font-bold uppercase text-black">{myReportCard.studentName}</span></p>
                  <p><span className="w-32 inline-block text-slate-500">Nomor Induk (NISN)</span>: <span className="font-mono font-bold">{myReportCard.studentId}</span></p>
                  <p><span className="w-32 inline-block text-slate-500">Tahun Pelajaran</span>: <span className="font-bold">{myReportCard.academicYear}</span></p>
                </div>
                <div className="space-y-1">
                  <p><span className="w-32 inline-block text-slate-500">Persentase Kehadiran</span>: <span className="font-bold">{myReportCard.attendanceRate}% (Sangat Baik)</span></p>
                  <p><span className="w-32 inline-block text-slate-500">Status Kelulusan</span>: <span className="font-bold text-indigo-700 uppercase decoration-double underline">{myReportCard.status}</span></p>
                  <p><span className="w-32 inline-block text-slate-500">Tanggal Terbit</span>: <span className="font-bold">23 Juli 2026</span></p>
                </div>
              </div>

              {/* Official Academic Table */}
              <table className="w-full text-left border-collapse border border-black text-xs font-sans">
                <thead>
                  <tr className="bg-slate-100 text-black border-b border-black">
                    <th className="p-2 border-r border-black font-bold">No</th>
                    <th className="p-2 border-r border-black font-bold">Mata Pelajaran (Kesetaraan)</th>
                    <th className="p-2 border-r border-black text-center font-bold">Uji Awal (Pre-test)</th>
                    <th className="p-2 border-r border-black text-center font-bold">Uji Akhir (Post-test)</th>
                    <th className="p-2 border-r border-black text-center font-bold">Nilai Akhir (Raport)</th>
                    <th className="p-2 font-bold">Catatan Sikap & Catatan Kelulusan Pengajar</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-black">
                  {myReportCard.grades.map((g, idx) => (
                    <tr key={idx}>
                      <td className="p-2 border-r border-black text-center">{idx + 1}</td>
                      <td className="p-2 border-r border-black font-bold text-black">{g.subject}</td>
                      <td className="p-2 border-r border-black text-center">{g.preTestScore !== null ? g.preTestScore : '-'}</td>
                      <td className="p-2 border-r border-black text-center">{g.postTestScore !== null ? g.postTestScore : '-'}</td>
                      <td className="p-2 border-r border-black text-center font-bold">{g.finalScore}</td>
                      <td className="p-2 italic text-slate-700">"{g.teacherNote}"</td>
                    </tr>
                  ))}
                </tbody>
              </table>

              {/* Character Notes Section */}
              <div className="border border-black p-4 rounded text-xs font-sans space-y-1">
                <span className="font-black text-black uppercase block">DESKRIPSI SIKAP DAN PERKEMBANGAN KARAKTER:</span>
                <p className="text-slate-700 italic">
                  "{myReportCard.characterNote} Peserta didik menunjukkan motivasi mandiri yang prima, disiplin tinggi dalam menonton video modul pengajaran, serta responsif dalam mengikuti uji evaluasi akhir."
                </p>
              </div>

              {/* Official Signatures Blocks */}
              <div className="grid grid-cols-3 gap-6 pt-12 text-center text-xs font-sans print:pt-6">
                <div>
                  <p>Orang Tua / Wali Murid</p>
                  <div className="h-20" />
                  <p className="font-bold underline">.........................................</p>
                </div>

                <div>
                  <p>Staff Administrasi Operator</p>
                  <div className="h-20 flex items-center justify-center relative">
                    <span className="text-[10px] text-blue-600/35 uppercase border border-dashed border-blue-400 p-1 rounded transform rotate-12 absolute z-10 select-none">TERVERIFIKASI SISTEM</span>
                  </div>
                  <p className="font-bold underline">Budi Santoso, S.Kom.</p>
                  <p className="text-[10px] text-slate-500">NIP: 19890212 202301 1002</p>
                </div>

                <div>
                  <p>Kepala PKBM EduSetara</p>
                  <div className="h-20 flex items-center justify-center relative">
                    {/* Simulated digital stamp */}
                    <div className="w-16 h-16 border-4 border-double border-indigo-700 rounded-full flex items-center justify-center text-[8px] font-black uppercase text-indigo-700 transform -rotate-12 absolute z-10 select-none bg-white/20">
                      PKBM STAMP
                    </div>
                  </div>
                  <p className="font-bold underline">Drs. H. Ahmad Sudrajat, M.Pd.</p>
                  <p className="text-[10px] text-slate-500">NIP: 19741021 199903 1001</p>
                </div>
              </div>

            </div>
          </div>
        </div>
      )}

    </div>
  );
};
