import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";

// Standard Express server setup
const app = express();
const PORT = 3000;

app.use(express.json());

// Lazy-loaded Gemini AI client helper
let aiClient: GoogleGenAI | null = null;

function getGeminiClient(): GoogleGenAI {
  if (!aiClient) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      throw new Error("GEMINI_API_KEY is not defined. Silakan atur kunci API Anda di Settings > Secrets.");
    }
    aiClient = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        }
      }
    });
  }
  return aiClient;
}

// API Health Check
app.get("/api/health", (req, res) => {
  res.json({ status: "ok", service: "EduSetara Tutor API" });
});

// POST /api/tutor/chat
app.post("/api/tutor/chat", async (req, res) => {
  try {
    const { lessonTitle, lessonDescription, messages } = req.body;

    if (!lessonTitle || !messages || !Array.isArray(messages)) {
      return res.status(400).json({ error: "lessonTitle dan messages (array) wajib dikirimkan." });
    }

    const ai = getGeminiClient();

    // System instruction specifically tailored for learning PKBM (Paket A, B, C) based on S.O.K.S & MKL framework
    const systemInstruction = `Anda adalah S.O.K.S AI Tutor interaktif bernama "Tutor Kesetaraan S.O.K.S" yang sangat berempati, bijak, sabar, dan inspiratif. 
Tugas utama Anda adalah mendampingi warga belajar pendidikan kesetaraan (Paket A setara SD, Paket B setara SMP, Paket C setara SMA) di EduSetara PKBM menggunakan prinsip Matriks Kosmo-Linguistik (MKL) & Protokol Kesadaran S.O.K.S.

Saat ini siswa sedang mempelajari modul berikut:
- Judul Modul: "${lessonTitle}"
- Rincian Modul: "${lessonDescription || 'Tidak ada deskripsi rincian.'}"

Aturan Komunikasi S.O.K.S & MKL yang WAJIB dipatuhi:
1. Formulasi Artikel Resonan (MKL):
   - 40% Fakta & Ilmu Akurat: Sajikan teori/fakta ilmiah secara gamblang dan mudah dipahami.
   - 30% Narasi Empati & Motivasi: Rangkul siswa, redakan cemas/takut gagal (Protokol Homeostasis), dan puji keberanian belajar mereka.
   - 20% Pertanyaan Reflektif (Delta): Ajukan 1 pertanyaan pemikir kritis di akhir tanggapan untuk memancing keheningan batin & pemikiran mendalam (Protokol Algoritma Sentrifugal).
2. JIKA SISWA MENANYAKAN JAWABAN KUIS / TEST:
   - BERIKAN PETUNJUK (HINTS), konsep kunci, dan analogi kehidupan nyata.
   - JANGAN PERNAH memberikan kunci jawaban langsung secara mentah! Tuntun mereka agar berhasil menjawab secara mandiri.
3. Gaya Bahasa: Santun, hangat, profesional, komunikatif, dan memosisikan siswa sebagai sosok yang berharga dan memiliki fitrah kebaikan. Maksimal 3-4 paragraf yang terstruktur rapi dengan markdown.`;

    // Map incoming messages array to Gemini-compatible contents array
    const contents = messages.map((msg: any) => ({
      role: msg.role === "assistant" ? "model" : "user",
      parts: [{ text: msg.text }]
    }));

    // Call generateContent
    const response = await ai.models.generateContent({
      model: "gemini-3.6-flash",
      contents,
      config: {
        systemInstruction,
        temperature: 0.7,
      }
    });

    const replyText = response.text || "Maaf, saya tidak dapat memproses tanggapan saat ini.";
    res.json({ text: replyText });

  } catch (error: any) {
    console.error("Gemini API Error in Tutor Chat:", error);
    res.status(500).json({ 
      error: error.message || "Terjadi kesalahan internal pada layanan Tutor AI." 
    });
  }
});

// POST /api/guru/generate-resonant-module (Prompt 2: Studio Guru Modul Resonan)
app.post("/api/guru/generate-resonant-module", async (req, res) => {
  try {
    const { topic, rawMaterial } = req.body;
    if (!topic && !rawMaterial) {
      return res.status(400).json({ error: "Topik atau Materi Mentah wajib diisi." });
    }

    const ai = getGeminiClient();

    const promptText = `Ubah materi pembelajaran berikut menjadi Modul Artikel Resonan (A-res) yang ramah, berempati, dan mudah diserap oleh warga belajar PKBM Paket A, B, C.

Topik/Materi Mentah:
"${rawMaterial || topic}"

Format Output yang WAJIB Dihasilkan (Gunakan Markdown Rapi):
1. Inti Fakta (Data Core - 40%): Sajikan 3–5 poin fakta ilmiah/akademis utama dengan bahasa yang sangat sederhana.
2. Kontekstualisasi Empatis (30%): Berikan narasi/contoh analogi yang dekat dengan pekerjaan atau kehidupan harian warga belajar PKBM.
3. Kotak Refleksi Siswa (20%): Buat 2 pertanyaan terbuka yang menanyakan pendapat atau pengalaman pribadi siswa terkait materi tersebut.
4. Micro-Summary (10%): Buat rangkuman 1 kalimat ringkas untuk mengikat pemahaman.`;

    const response = await ai.models.generateContent({
      model: "gemini-3.6-flash",
      contents: promptText,
      config: {
        temperature: 0.7,
      }
    });

    res.json({ text: response.text || "Gagal menghasilkan modul resonan." });
  } catch (error: any) {
    console.error("Error generating resonant module:", error);
    res.status(500).json({ error: error.message || "Gagal memproses pembuatan modul." });
  }
});

// POST /api/guru/generate-verpal-quiz (Prompt 3: Pembuat Kuis Verpal Engine)
app.post("/api/guru/generate-verpal-quiz", async (req, res) => {
  try {
    const { subject, topic } = req.body;
    if (!subject && !topic) {
      return res.status(400).json({ error: "Mata pelajaran atau topik wajib diisi." });
    }

    const ai = getGeminiClient();

    const promptText = `Buat 3 soal kuis studi kasus berstruktur Verpal Engine untuk mata pelajaran "${subject || 'Umum'}" dengan topik "${topic || 'Integritas Informasi'}".

Struktur Setiap Soal:
Berikan sebuah narasi studi kasus singkat atau potongan berita pendek (2–3 kalimat).
Mintalah siswa menganalisis dan membedakan:
a) Realitas Fisik (Rp): Mana fakta objek/angka nyata dalam narasi tersebut?
b) Aktivitas Faktual (Af): Tindakan/kejadian nyata apa yang terjadi?
c) Distorsi/Manipulasi (Im): Mana opini, asumsi, atau hoaks yang berpotensi menyesatkan?

Sertakan kunci jawaban dan penjelasan berbasis fitrah / logika jernih di akhir setiap soal.`;

    const response = await ai.models.generateContent({
      model: "gemini-3.6-flash",
      contents: promptText,
      config: {
        temperature: 0.7,
      }
    });

    res.json({ text: response.text || "Gagal menghasilkan kuis verpal." });
  } catch (error: any) {
    console.error("Error generating verpal quiz:", error);
    res.status(500).json({ error: error.message || "Gagal memproses pembuatan kuis verpal." });
  }
});

// POST /api/guru/generate-video-script (Studio Perekaman Video Pembelajaran S.O.K.S & MKL LitOS)
app.post("/api/guru/generate-video-script", async (req, res) => {
  try {
    const { subject, level, topic, durationMinutes } = req.body;
    if (!topic) {
      return res.status(400).json({ error: "Topik materi video wajib diisi." });
    }

    const ai = getGeminiClient();

    const promptText = `Anda adalah Master Scriptwriter & Sutradara Pembelajaran AI untuk Studio Perekaman Video Kesetaraan (Paket A/B/C) BSC EduSetara.

Tugas: Buat skrip video pembelajaran berdurasi ${durationMinutes || 3}–5 menit untuk mata pelajaran "${subject || 'Umum'}" jenjang "${level || 'Paket C'}" dengan topik:
"${topic}"

Skrip ini WAJIB memuat 5 Protokol S.O.K.S, Matriks Kosmo-Linguistik (MKL LitOS Engine v2.0), dan siap ditayangkan di Smart Teleprompter dengan petunjuk vokal.

Gunakan struktur tag eksplisit berikut agar teleprompter dapat melakukan pewarnaan highlight otomatis:
- Gunakan tag [HOOK/HOMEOSTASIS] untuk pembukaan yang menenangkan batin dan meredakan rasa cemas siswa.
- Gunakan tag [MOTIVASI] untuk injeksi manfaat nyata materi di masa depan/karier.
- Gunakan tag [DATA] untuk 40% Fakta & Poin Sains Akurat.
- Gunakan tag [EMPATI] untuk 30% Narasi Empati & Analogi Kehidupan Sehari-hari Warga Belajar.
- Gunakan tag [REFLEKSI] untuk 20% Pertanyaan Pemicu Kesadaran Kritis / Pembawa Kesadaran.
- Sertakan petunjuk intonasi vokal LitOS dalam kurung siku seperti: [Jeda Napas λ], [Tekanan Vokal μ], [Ketegasan Logic τ].

Buat skrip interaktif, hangat, ilmiah, dan beresonansi tinggi (Nilai Resonansi Target: Φ ≥ 9.98).`;

    const response = await ai.models.generateContent({
      model: "gemini-3.6-flash",
      contents: promptText,
      config: {
        temperature: 0.7,
      }
    });

    res.json({ text: response.text || "Gagal menghasilkan skrip video pembelajaran." });
  } catch (error: any) {
    console.error("Error generating video script:", error);
    res.status(500).json({ error: error.message || "Gagal memproses skrip video." });
  }
});

// Configure Vite middleware in Dev vs Static routing in Production
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`[EduSetara] Server running on http://localhost:${PORT}`);
  });
}

startServer();
