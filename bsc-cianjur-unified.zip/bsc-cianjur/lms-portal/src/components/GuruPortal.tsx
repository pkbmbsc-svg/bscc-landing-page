import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Lesson, Test, Question, TestAttempt } from '../types';
import { 
  Video, Plus, PlusCircle, Check, Award, Eye, 
  HelpCircle, BookOpen, Star, Sparkles, MessageSquareCode, Trash2, Code 
} from 'lucide-react';
import { SOKSPromptStudio } from './SOKSPromptStudio';
import { StudioVideoGuru } from './StudioVideoGuru';

export const GuruPortal: React.FC = () => {
  const { currentUser, lessons, tests, attempts, addLesson, addTest, teacherKPIs } = useApp();

  const [activeTab, setActiveTab] = useState<'KONTEN' | 'STUDIO_VIDEO' | 'TEST' | 'NILAI' | 'PROMPT_STUDIO'>('STUDIO_VIDEO');

  // Personal Teacher KPI info
  const myKPI = teacherKPIs.find(kpi => kpi.teacherId === currentUser?.id) || {
    teacherId: currentUser?.id || 'usr-guru1',
    name: currentUser?.name || 'Guru Pengajar',
    subject: 'Pengajar Bidang Studi',
    videosUploaded: 0,
    testsCreated: 0,
    averageStudentScore: 0,
    studentInteractionRate: 0,
    kpiRating: 4.5
  };

  // Lesson creator states
  const [showAddLesson, setShowAddLesson] = useState(false);
  const [lesTitle, setLesTitle] = useState('');
  const [lesSubject, setLesSubject] = useState('PPKn');
  const [lesPkg, setLesPkg] = useState<'Paket A' | 'Paket B' | 'Paket C'>('Paket C');
  const [lesUrl, setLesUrl] = useState('https://www.youtube.com/watch?v=dQw4w9WgXcQ');
  const [lesDuration, setLesDuration] = useState('12:00');
  const [lesDesc, setLesDesc] = useState('');
  const [lessonAddedSuccess, setLessonAddedSuccess] = useState(false);

  // Test / Quiz Builder states
  const [selectedLessonForTest, setSelectedLessonForTest] = useState<string>('');
  const [testType, setTestType] = useState<'pretest' | 'posttest'>('posttest');
  const [questions, setQuestions] = useState<Omit<Question, 'id'>[]>([
    { text: '', options: ['', '', '', ''], correctAnswerIndex: 0 }
  ]);
  const [testAddedSuccess, setTestAddedSuccess] = useState(false);

  // Filter lessons that belong to this teacher
  const myLessons = lessons.filter(l => l.teacherId === currentUser?.id);

  // MKL Resonance Score Analyzer (Matriks Kosmo-Linguistik S.O.K.S)
  const mklResonance = (() => {
    if (!lesDesc || lesDesc.trim().length === 0) return { score: 0, factScore: 0, empathyScore: 0, deltaScore: 0, status: 'Belum Diisi' };

    const wordCount = lesDesc.trim().split(/\s+/).length;
    const hasQuestion = lesDesc.includes('?') || /(mengapa|bagaimana|pendapat|penerapan|menurutmu|pikirkan)/i.test(lesDesc);
    const hasEmpathy = /(semangat|hebat|mari|bersama|bangkit|sukses|luar biasa|sahabat|saudara)/i.test(lesDesc);
    
    const factScore = Math.min(4.0, (wordCount / 10) * 0.8);
    const empathyScore = hasEmpathy ? 3.0 : 1.5;
    const deltaScore = hasQuestion ? 2.98 : 1.0;

    const totalScore = parseFloat((factScore + empathyScore + deltaScore).toFixed(2));
    
    let status = 'Rendah (Kurang Reflektif)';
    if (totalScore >= 9.5) status = 'Resonansi Maksimal (MKL Ideal)';
    else if (totalScore >= 7.5) status = 'Cukup Resonan';

    return {
      score: Math.min(10, totalScore),
      factScore: Math.min(4.0, factScore),
      empathyScore,
      deltaScore,
      status
    };
  })();

  const handleCreateLesson = (e: React.FormEvent) => {
    e.preventDefault();
    if (!lesTitle || !lesDesc) return;

    const newId = addLesson({
      title: lesTitle,
      subject: lesSubject,
      package: lesPkg,
      videoUrl: lesUrl,
      videoDuration: lesDuration,
      description: lesDesc
    });

    setLessonAddedSuccess(true);
    setTimeout(() => {
      setLessonAddedSuccess(false);
      setShowAddLesson(false);
      // Automatically select this lesson to build a test for it next!
      setSelectedLessonForTest(newId);
      setActiveTab('TEST');
    }, 1500);

    // Reset forms
    setLesTitle('');
    setLesDesc('');
  };

  // Test creation helpers
  const handleAddQuestionField = () => {
    setQuestions([...questions, { text: '', options: ['', '', '', ''], correctAnswerIndex: 0 }]);
  };

  const handleRemoveQuestionField = (idx: number) => {
    if (questions.length === 1) return;
    setQuestions(questions.filter((_, i) => i !== idx));
  };

  const handleQuestionTextChange = (idx: number, text: string) => {
    const updated = [...questions];
    updated[idx].text = text;
    setQuestions(updated);
  };

  const handleOptionChange = (qIdx: number, optIdx: number, val: string) => {
    const updated = [...questions];
    updated[qIdx].options[optIdx] = val;
    setQuestions(updated);
  };

  const handleCorrectAnswerChange = (qIdx: number, optIdx: number) => {
    const updated = [...questions];
    updated[qIdx].correctAnswerIndex = optIdx;
    setQuestions(updated);
  };

  const handleCreateTest = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedLessonForTest) return;

    // Validate that questions are filled out
    const validQuestions: Question[] = questions.map((q, idx) => ({
      id: `q-${Date.now()}-${idx}`,
      text: q.text || 'Pertanyaan Baru',
      options: q.options.map(o => o || 'Pilihan Jawaban'),
      correctAnswerIndex: q.correctAnswerIndex
    }));

    const newTest: Test = {
      id: `test-${testType}-${Date.now()}`,
      lessonId: selectedLessonForTest,
      type: testType,
      questions: validQuestions
    };

    addTest(newTest);

    setTestAddedSuccess(true);
    setTimeout(() => {
      setTestAddedSuccess(false);
      // Reset Quiz Designer
      setQuestions([{ text: '', options: ['', '', '', ''], correctAnswerIndex: 0 }]);
    }, 2000);
  };

  // Get student test logs for this teacher's lessons
  const myLessonIds = myLessons.map(l => l.id);
  const relevantAttempts = attempts.filter(a => myLessonIds.includes(a.lessonId) || myLessons.length === 0);

  // Find associated lesson title
  const getLessonTitle = (lessonId: string) => {
    return lessons.find(l => l.id === lessonId)?.title || 'Pelajaran';
  };

  // Find associated lesson package
  const getLessonPkg = (lessonId: string) => {
    return lessons.find(l => l.id === lessonId)?.package || 'Paket C';
  };

  return (
    <div className="space-y-8 animate-fade-in">
      {/* Branding Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
        <div className="flex items-center gap-4">
          <img
            src={currentUser?.avatar || "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=150"}
            alt={currentUser?.name}
            className="w-16 h-16 rounded-2xl object-cover border border-slate-200"
          />
          <div>
            <span className="text-xs font-bold text-amber-600 bg-amber-50 px-3 py-1 rounded-full uppercase tracking-widest">
              Guru Pengajar: {currentUser?.subject || 'Bahasa'}
            </span>
            <h1 className="text-2xl font-black text-slate-900 mt-1">{currentUser?.name}</h1>
            <p className="text-sm text-slate-500">Mengunggah Video Edukasi, Mendesain Pre/Post Test, dan Meninjau Nilai Siswa</p>
          </div>
        </div>

        {/* Dynamic Self KPI widget for Requirement 3 */}
        <div className="bg-gradient-to-br from-indigo-50 to-slate-50 p-4 rounded-2xl border border-indigo-100 flex items-center gap-4">
          <div>
            <p className="text-[10px] font-black text-indigo-500 uppercase tracking-wider">KPI Rating Saya</p>
            <div className="flex items-baseline gap-1 mt-1">
              <span className="text-2xl font-black text-indigo-900">{myKPI.kpiRating}</span>
              <span className="text-xs text-slate-400">/ 5.0</span>
            </div>
            <div className="flex text-amber-400 mt-1">
              {[...Array(5)].map((_, i) => (
                <Star key={i} className={`w-3.5 h-3.5 ${i < Math.floor(myKPI.kpiRating) ? 'fill-current' : 'text-slate-200'}`} />
              ))}
            </div>
          </div>
          <div className="border-l border-indigo-100 pl-4 space-y-1">
            <p className="text-[10px] text-slate-500">Nilai Siswa: <span className="font-bold text-slate-800">{myKPI.averageStudentScore}/100</span></p>
            <p className="text-[10px] text-slate-500">Konten Modul: <span className="font-bold text-slate-800">{myKPI.videosUploaded} Video</span></p>
            <p className="text-[10px] text-slate-500">Interaksi Aktif: <span className="font-bold text-slate-800">{myKPI.studentInteractionRate}%</span></p>
          </div>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="flex border-b border-slate-200 gap-1 bg-slate-100 p-1.5 rounded-2xl max-w-2xl overflow-x-auto no-scrollbar">
        <button
          onClick={() => setActiveTab('STUDIO_VIDEO')}
          className={`px-3.5 py-2 text-xs font-black rounded-xl transition-all cursor-pointer flex items-center gap-1.5 whitespace-nowrap ${
            activeTab === 'STUDIO_VIDEO' ? 'bg-amber-500 text-slate-950 shadow-md' : 'text-amber-700 bg-amber-50 hover:bg-amber-100'
          }`}
        >
          <Video className="w-4 h-4 text-slate-950" />
          <span>Studio Video Broadcast AI</span>
        </button>
        <button
          onClick={() => setActiveTab('KONTEN')}
          className={`px-3.5 py-2 text-xs font-bold rounded-xl transition-all cursor-pointer whitespace-nowrap ${
            activeTab === 'KONTEN' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600 hover:text-indigo-600'
          }`}
        >
          Modul Video ({myLessons.length})
        </button>
        <button
          onClick={() => {
            setActiveTab('TEST');
            if (myLessons.length > 0 && !selectedLessonForTest) {
              setSelectedLessonForTest(myLessons[0].id);
            }
          }}
          className={`px-3.5 py-2 text-xs font-bold rounded-xl transition-all cursor-pointer whitespace-nowrap ${
            activeTab === 'TEST' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600 hover:text-indigo-600'
          }`}
        >
          Desain Ujian (Pre/Post)
        </button>
        <button
          onClick={() => setActiveTab('NILAI')}
          className={`px-3.5 py-2 text-xs font-bold rounded-xl transition-all cursor-pointer whitespace-nowrap ${
            activeTab === 'NILAI' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600 hover:text-indigo-600'
          }`}
        >
          Nilai Kuis ({relevantAttempts.length})
        </button>
        <button
          onClick={() => setActiveTab('PROMPT_STUDIO')}
          className={`px-3.5 py-2 text-xs font-bold rounded-xl transition-all cursor-pointer flex items-center gap-1.5 whitespace-nowrap ${
            activeTab === 'PROMPT_STUDIO' ? 'bg-indigo-600 text-white shadow-sm' : 'text-indigo-700 bg-indigo-50 hover:bg-indigo-100'
          }`}
        >
          <Sparkles className="w-3.5 h-3.5" />
          <span>Studio Prompt & Generator</span>
        </button>
      </div>

      {/* KONTEN / VIDEO MODUL TAB */}
      {activeTab === 'KONTEN' && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6 space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h3 className="text-lg font-bold text-slate-900">Video Pembelajaran Kesetaraan Saya</h3>
              <p className="text-xs text-slate-400">Daftar video modul yang diajarkan dan dapat ditonton oleh Siswa Belajar Paket A, B, dan C</p>
            </div>
            <button
              onClick={() => setShowAddLesson(!showAddLesson)}
              className="flex items-center gap-1 bg-indigo-600 text-white px-4 py-2 text-xs font-bold rounded-xl hover:bg-indigo-700 transition-all cursor-pointer"
            >
              <Plus className="w-4 h-4" /> Unggah Video Pembelajaran
            </button>
          </div>

          {/* Create Lesson Drawer */}
          {showAddLesson && (
            <form onSubmit={handleCreateLesson} className="p-5 border border-slate-200 bg-slate-50 rounded-2xl space-y-4 animate-fade-in">
              <div className="flex items-center justify-between">
                <h4 className="text-sm font-bold text-slate-800 flex items-center gap-1">
                  <Sparkles className="w-4 h-4 text-amber-500 animate-pulse" /> Form Unggah Video & Materi Baru
                </h4>
                {lessonAddedSuccess && (
                  <span className="text-xs font-bold text-emerald-600 flex items-center gap-1 bg-emerald-50 px-2.5 py-0.5 rounded">
                    <Check className="w-3.5 h-3.5" /> Video Berhasil Ditambahkan!
                  </span>
                )}
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
                <div className="md:col-span-2">
                  <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Judul Pelajaran</label>
                  <input
                    type="text"
                    required
                    placeholder="Contoh: Dinamika Penduduk Indonesia"
                    value={lesTitle}
                    onChange={(e) => setLesTitle(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-200 bg-white rounded-lg text-sm"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Mata Pelajaran</label>
                  <select
                    value={lesSubject}
                    onChange={(e) => setLesSubject(e.target.value)}
                    className="w-full px-2 py-2 border border-slate-200 bg-white rounded-lg text-sm"
                  >
                    <option value="PPKn">PPKn (Kewarganegaraan)</option>
                    <option value="Bahasa Indonesia">Bahasa Indonesia</option>
                    <option value="Matematika">Matematika</option>
                    <option value="IPA">IPA (Sains)</option>
                    <option value="IPS">IPS (Sosial)</option>
                    <option value="Sosiologi">Sosiologi</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Program Paket Kesetaraan</label>
                  <select
                    value={lesPkg}
                    onChange={(e) => setLesPkg(e.target.value as any)}
                    className="w-full px-2 py-2 border border-slate-200 bg-white rounded-lg text-sm"
                  >
                    <option value="Paket A">Paket A (Setara SD/Sederajat)</option>
                    <option value="Paket B">Paket B (Setara SMP/Sederajat)</option>
                    <option value="Paket C">Paket C (Setara SMA/Sederajat)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Link Video (YouTube/Embed)</label>
                  <input
                    type="text"
                    placeholder="Contoh: https://www.youtube.com/watch?v=..."
                    value={lesUrl}
                    onChange={(e) => setLesUrl(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-200 bg-white rounded-lg text-sm font-mono text-xs"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Durasi Video</label>
                  <input
                    type="text"
                    placeholder="Contoh: 14:15"
                    value={lesDuration}
                    onChange={(e) => setLesDuration(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-200 bg-white rounded-lg text-sm"
                  />
                </div>
              </div>

              <div>
                <div className="flex justify-between items-center mb-1">
                  <label className="block text-xs font-bold text-slate-500 uppercase">Deskripsi & Teks Modul Pembelajaran</label>
                  <span className="text-[10px] font-black uppercase text-indigo-700 bg-indigo-50 border border-indigo-100 px-2 py-0.5 rounded-full flex items-center gap-1">
                    <Sparkles className="w-3 h-3 text-indigo-600" /> MKL Resonansi Analyzer (S.O.K.S)
                  </span>
                </div>
                <textarea
                  rows={3}
                  required
                  placeholder="Berikan ringkasan poin penting, narasi penyemangat, dan ajukan 1 pertanyaan reflektif untuk memicu pemikiran kritis siswa..."
                  value={lesDesc}
                  onChange={(e) => setLesDesc(e.target.value)}
                  className="w-full p-3 border border-slate-200 bg-white rounded-lg text-sm focus:border-indigo-500"
                />

                {/* MKL Resonance Live Indicator Box */}
                {lesDesc.trim().length > 0 && (
                  <div className="mt-2 p-3.5 bg-indigo-950 text-white rounded-xl space-y-2 border border-indigo-900 shadow-xs animate-fade-in">
                    <div className="flex justify-between items-center">
                      <div className="flex items-center gap-2">
                        <Award className="w-4 h-4 text-amber-400" />
                        <span className="text-xs font-bold">Skor Resonansi Artikel MKL (A-res):</span>
                        <span className="text-sm font-black text-amber-400">{mklResonance.score} / 10.0</span>
                      </div>
                      <span className={`text-[10px] font-black px-2 py-0.5 rounded-full ${
                        mklResonance.score >= 9.5 ? 'bg-emerald-500 text-slate-950' : 'bg-amber-500 text-slate-950'
                      }`}>
                        {mklResonance.status}
                      </span>
                    </div>

                    <div className="grid grid-cols-3 gap-2 text-[10px] pt-1 border-t border-indigo-900/80">
                      <div>
                        <span className="text-slate-400 block">40% Data & Ilmu Akurat</span>
                        <strong className="text-emerald-400">{mklResonance.factScore.toFixed(1)} / 4.0 Poin</strong>
                      </div>
                      <div>
                        <span className="text-slate-400 block">30% Narasi Empati</span>
                        <strong className="text-emerald-400">{mklResonance.empathyScore.toFixed(1)} / 3.0 Poin</strong>
                      </div>
                      <div>
                        <span className="text-slate-400 block">20% Pertanyaan Reflektif (Delta)</span>
                        <strong className={mklResonance.deltaScore >= 2.0 ? "text-emerald-400" : "text-amber-400"}>
                          {mklResonance.deltaScore.toFixed(2)} / 3.0 Poin
                        </strong>
                      </div>
                    </div>
                  </div>
                )}
              </div>

              <div className="flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowAddLesson(false)}
                  className="px-4 py-2 text-xs font-bold bg-slate-200 text-slate-700 rounded-lg cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 text-xs font-bold bg-indigo-600 text-white rounded-lg cursor-pointer"
                >
                  Simpan & Unggah Video
                </button>
              </div>
            </form>
          )}

          {myLessons.length === 0 ? (
            <div className="text-center py-12 bg-slate-50 border border-dashed border-slate-200 rounded-2xl">
              <Video className="w-12 h-12 text-slate-300 mx-auto mb-3 animate-pulse" />
              <p className="text-sm font-semibold text-slate-600">Belum ada video diupload</p>
              <p className="text-xs text-slate-400 mt-1">Klik tombol "Unggah Video" untuk memulai modul video pembelajaran.</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
              {myLessons.map((les) => {
                const preTest = tests.find(t => t.lessonId === les.id && t.type === 'pretest');
                const postTest = tests.find(t => t.lessonId === les.id && t.type === 'posttest');

                return (
                  <div key={les.id} className="border border-slate-200 rounded-2xl bg-slate-50/50 hover:bg-slate-50 p-4.5 flex flex-col justify-between gap-4 shadow-2xs hover:shadow-xs transition-all">
                    <div>
                      <div className="flex justify-between items-center mb-2.5">
                        <span className="text-[10px] font-bold text-indigo-700 bg-indigo-50 border border-indigo-100 px-2 py-0.5 rounded-full">
                          {les.subject}
                        </span>
                        <span className="text-[10px] font-black uppercase text-slate-600 bg-slate-100 px-2 py-0.5 rounded">
                          {les.package}
                        </span>
                      </div>
                      <h4 className="font-bold text-slate-900 line-clamp-1">{les.title}</h4>
                      <p className="text-xs text-slate-400 mt-1 font-mono">Durasi: {les.videoDuration}</p>
                      <p className="text-xs text-slate-500 mt-2 line-clamp-2">{les.description}</p>
                    </div>

                    <div className="border-t border-slate-200 pt-3 flex flex-col gap-2">
                      <div className="flex justify-between items-center text-xs">
                        <span className="text-slate-400 font-semibold flex items-center gap-1">
                          <BookOpen className="w-3.5 h-3.5 text-slate-400" /> Assessment:
                        </span>
                        <div className="flex gap-1">
                          <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded ${
                            preTest ? 'bg-emerald-50 text-emerald-700 border border-emerald-100' : 'bg-rose-50 text-rose-700 border border-rose-100'
                          }`}>
                            Pre: {preTest ? `${preTest.questions.length}Q` : 'Blm Ada'}
                          </span>
                          <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded ${
                            postTest ? 'bg-emerald-50 text-emerald-700 border border-emerald-100' : 'bg-rose-50 text-rose-700 border border-rose-100'
                          }`}>
                            Post: {postTest ? `${postTest.questions.length}Q` : 'Blm Ada'}
                          </span>
                        </div>
                      </div>

                      <button
                        onClick={() => {
                          setSelectedLessonForTest(les.id);
                          setActiveTab('TEST');
                        }}
                        className="w-full py-2 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 font-bold rounded-xl text-xs transition-all cursor-pointer"
                      >
                        Desain Soal Kuis
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* DESIGN TEST TAB */}
      {activeTab === 'TEST' && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6 space-y-6">
          <div>
            <h3 className="text-lg font-bold text-slate-900">Desain Pre-test & Post-test Modul</h3>
            <p className="text-xs text-slate-400">Rancang kuis pilihan ganda yang wajib diisi siswa sebelum (Pre-test) dan sesudah (Post-test) menonton video modul</p>
          </div>

          {myLessons.length === 0 ? (
            <div className="text-center py-12 text-slate-400 text-sm">
              Anda harus membuat video pembelajaran terlebih dahulu untuk membuat tes ujian.
            </div>
          ) : (
            <form onSubmit={handleCreateTest} className="space-y-6">
              {testAddedSuccess && (
                <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-sm font-bold flex items-center gap-2">
                  <Check className="w-5 h-5 text-emerald-600" /> Kuis Tes Berhasil Disimpan & Diterbitkan!
                </div>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Pilih Video Pelajaran</label>
                  <select
                    value={selectedLessonForTest}
                    onChange={(e) => setSelectedLessonForTest(e.target.value)}
                    className="w-full p-2.5 border border-slate-200 rounded-xl text-sm bg-white"
                  >
                    {myLessons.map(l => (
                      <option key={l.id} value={l.id}>
                        ({l.package === 'Paket A' ? 'Setara SD' : l.package === 'Paket B' ? 'Setara SMP' : 'Setara SMA'}) {l.title}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Jenis Tes Kuis</label>
                  <div className="flex bg-slate-100 p-1 rounded-xl">
                    <button
                      type="button"
                      onClick={() => setTestType('pretest')}
                      className={`flex-1 py-1.5 text-xs font-bold rounded-lg transition-all cursor-pointer ${
                        testType === 'pretest' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600'
                      }`}
                    >
                      Pre-test (Sebelum Nonton)
                    </button>
                    <button
                      type="button"
                      onClick={() => setTestType('posttest')}
                      className={`flex-1 py-1.5 text-xs font-bold rounded-lg transition-all cursor-pointer ${
                        testType === 'posttest' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600'
                      }`}
                    >
                      Post-test (Setelah Nonton)
                    </button>
                  </div>
                </div>
              </div>

              {/* Questions Area */}
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h4 className="text-sm font-bold text-slate-800">Daftar Pertanyaan Pilihan Ganda</h4>
                  <button
                    type="button"
                    onClick={handleAddQuestionField}
                    className="flex items-center gap-1 text-xs font-bold text-indigo-600 hover:underline"
                  >
                    <PlusCircle className="w-4 h-4" /> Tambah Pertanyaan
                  </button>
                </div>

                {questions.map((q, qIdx) => (
                  <div key={qIdx} className="p-4 border border-slate-200 rounded-2xl bg-slate-50/50 space-y-4">
                    <div className="flex items-start justify-between">
                      <span className="text-xs font-black text-indigo-700 bg-indigo-50 border border-indigo-100 px-2 py-0.5 rounded">
                        Pertanyaan #{qIdx + 1}
                      </span>
                      {questions.length > 1 && (
                        <button
                          type="button"
                          onClick={() => handleRemoveQuestionField(qIdx)}
                          className="text-xs text-rose-600 font-bold hover:underline"
                        >
                          Hapus Soal
                        </button>
                      )}
                    </div>

                    <div>
                      <input
                        type="text"
                        required
                        placeholder="Ketik teks pertanyaan ujian..."
                        value={q.text}
                        onChange={(e) => handleQuestionTextChange(qIdx, e.target.value)}
                        className="w-full px-3 py-2 border border-slate-200 bg-white rounded-lg text-sm"
                      />
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      {q.options.map((opt, optIdx) => (
                        <div key={optIdx} className="flex items-center gap-2">
                          <input
                            type="radio"
                            name={`correct-${qIdx}`}
                            checked={q.correctAnswerIndex === optIdx}
                            onChange={() => handleCorrectAnswerChange(qIdx, optIdx)}
                            className="text-indigo-600 focus:ring-indigo-500 h-4 w-4"
                            title="Tandai jawaban benar"
                          />
                          <input
                            type="text"
                            required
                            placeholder={`Pilihan ${String.fromCharCode(65 + optIdx)}`}
                            value={opt}
                            onChange={(e) => handleOptionChange(qIdx, optIdx, e.target.value)}
                            className="flex-1 px-3 py-1.5 border border-slate-200 bg-white rounded-lg text-xs"
                          />
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>

              <div className="pt-2 border-t border-slate-200 flex justify-end">
                <button
                  type="submit"
                  className="px-6 py-3 bg-indigo-600 text-white text-xs font-black rounded-xl hover:bg-indigo-700 shadow-md shadow-indigo-100 transition-all cursor-pointer"
                >
                  Terbitkan Kuis Soal Sekarang
                </button>
              </div>
            </form>
          )}
        </div>
      )}

      {/* NILAI TAB */}
      {activeTab === 'NILAI' && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6 space-y-6">
          <div>
            <h3 className="text-lg font-bold text-slate-900">Riwayat Nilai Siswa Belajar</h3>
            <p className="text-xs text-slate-400">Pantau siswa yang telah menyelesaikan Pre-test & Post-test di kelas modul Anda</p>
          </div>

          {relevantAttempts.length === 0 ? (
            <div className="text-center py-12 text-slate-400 text-sm">
              Belum ada siswa yang mengisi tes kuis video modul Anda.
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-slate-200 text-[10px] text-slate-400 font-bold uppercase tracking-wider">
                    <th className="pb-2">Nama Siswa</th>
                    <th className="pb-2">Modul Video</th>
                    <th className="pb-2">Jenjang</th>
                    <th className="pb-2 text-center">Jenis Tes</th>
                    <th className="pb-2 text-center">Jawaban Benar</th>
                    <th className="pb-2 text-center">Nilai Skor</th>
                    <th className="pb-2 text-right">Tanggal Submit</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-sm">
                  {relevantAttempts.map((att, idx) => (
                    <tr key={idx} className="hover:bg-slate-50/40">
                      <td className="py-3.5 font-bold text-slate-900">{att.studentName}</td>
                      <td className="py-3.5 text-slate-700 font-medium">{getLessonTitle(att.lessonId)}</td>
                      <td className="py-3.5">
                        <span className="px-1.5 py-0.5 text-[10px] font-bold bg-slate-100 text-slate-700 rounded">
                          {getLessonPkg(att.lessonId)}
                        </span>
                      </td>
                      <td className="py-3.5 text-center">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-black uppercase ${
                          att.type === 'pretest' 
                            ? 'bg-amber-50 text-amber-700 border border-amber-100' 
                            : 'bg-indigo-50 text-indigo-700 border border-indigo-100'
                        }`}>
                          {att.type}
                        </span>
                      </td>
                      <td className="py-3.5 text-center text-slate-600 font-semibold">{att.correctCount} / {att.totalQuestions}</td>
                      <td className="py-3.5 text-center">
                        <span className={`px-2 py-0.5 rounded text-xs font-bold ${
                          att.score >= 80 ? 'bg-emerald-50 text-emerald-700' : 'bg-amber-50 text-amber-700'
                        }`}>
                          {att.score} / 100
                        </span>
                      </td>
                      <td className="py-3.5 text-right text-xs text-slate-400 font-medium">{att.completedAt}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* STUDIO VIDEO BROADCAST AI TAB */}
      {activeTab === 'STUDIO_VIDEO' && <StudioVideoGuru />}

      {/* PROMPT STUDIO & AI GENERATOR TAB */}
      {activeTab === 'PROMPT_STUDIO' && <SOKSPromptStudio />}
    </div>
  );
};
