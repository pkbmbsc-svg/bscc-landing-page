import React, { useState, useRef } from 'react';
import { useApp } from '../context/AppContext';
import { Student, ReportCard, GradeItem } from '../types';
import { 
  Users, UserCheck, UserX, Upload, Download, RefreshCw, 
  Search, Filter, Check, AlertTriangle, FileSpreadsheet, PlusCircle, Trash2 
} from 'lucide-react';

export const OperatorPortal: React.FC = () => {
  const { 
    students, reportCards, approveStudent, rejectStudent, 
    addStudent, syncExternalReportCards, updateReportCard 
  } = useApp();

  const [searchQuery, setSearchQuery] = useState('');
  const [packageFilter, setPackageFilter] = useState<'ALL' | 'Paket A' | 'Paket B' | 'Paket C'>('ALL');
  const [activeTab, setActiveTab] = useState<'REGISTRASI' | 'SISWA' | 'SYNC'>('REGISTRASI');

  // New Student Modal/Form State
  const [showAddForm, setShowAddForm] = useState(false);
  const [newStudName, setNewStudName] = useState('');
  const [newStudEmail, setNewStudEmail] = useState('');
  const [newStudPkg, setNewStudPkg] = useState<'Paket A' | 'Paket B' | 'Paket C'>('Paket C');
  const [newStudGender, setNewStudGender] = useState<'Laki-laki' | 'Perempuan'>('Laki-laki');

  // External Sync File Upload States
  const [importType, setImportType] = useState<'RAPORT' | 'SISWA'>('RAPORT');
  const [isDragging, setIsDragging] = useState(false);
  const [csvInput, setCsvInput] = useState('');
  const [syncResults, setSyncResults] = useState<{ successCount: number; errors: string[] } | null>(null);
  const [syncPreview, setSyncPreview] = useState<any[]>([]);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const pendingStudents = students.filter(s => s.status === 'Menunggu');
  const activeStudents = students.filter(s => s.status === 'Aktif' || s.status === 'Lulus');

  // Filtering students
  const filteredStudents = activeStudents.filter(s => {
    const matchesSearch = s.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          s.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          s.id.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesPkg = packageFilter === 'ALL' || s.package === packageFilter;
    return matchesSearch && matchesPkg;
  });

  const handleCreateStudent = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newStudName || !newStudEmail) return;

    addStudent({
      name: newStudName,
      email: newStudEmail,
      package: newStudPkg,
      gender: newStudGender
    });

    // Reset Form
    setNewStudName('');
    setNewStudEmail('');
    setShowAddForm(false);
  };

  // CSV Template downloader
  const downloadCsvTemplate = () => {
    let csvContent = "data:text/csv;charset=utf-8,";
    let fileName = "template_sinkronisasi_raport.csv";
    
    if (importType === 'RAPORT') {
      csvContent += "studentName,email,package,subject,preTestScore,postTestScore,finalScore,teacherNote\n"
        + "Fajar Nugraha,fajar.nugraha@gmail.com,Paket C,Matematika,70,85,85,Sangat baik ada peningkatan\n"
        + "Siti Aminah,siti.aminah@gmail.com,Paket B,Bahasa Indonesia,80,90,90,Lancar mengulas bacaan\n"
        + "Andi Wijaya,andi.wijaya@gmail.com,Paket B,IPA,60,80,80,Bagus memahami anatomi\n"
        + "Sarah Kartika,sarah.kartika@gmail.com,Paket C,Sosiologi,,85,85,Siswa berprestasi baru di-sync\n";
    } else {
      fileName = "template_pendaftaran_siswa_massal.csv";
      csvContent += "name,email,package,gender\n"
        + "Budi Pratama,budi.pratama@gmail.com,Paket C,Laki-laki\n"
        + "Aisyah Rahma,aisyah.rahma@gmail.com,Paket B,Perempuan\n"
        + "Eko Susilo,eko.susilo@gmail.com,Paket A,Laki-laki\n"
        + "Dewi Lestari,dewi.lestari@gmail.com,Paket C,Perempuan\n";
    }
    
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", fileName);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Paste a Sample of CSV directly for immediate demo convenience
  const loadSampleCsvData = () => {
    let sample = '';
    if (importType === 'RAPORT') {
      sample = `studentName,email,package,subject,preTestScore,postTestScore,finalScore,teacherNote
Fajar Nugraha,fajar.nugraha@gmail.com,Paket C,Matematika,70,85,85,Memahami materi fungsi kuadrat.
Siti Aminah,siti.aminah@gmail.com,Paket B,Bahasa Indonesia,80,95,95,Kreatif dalam membuat ringkasan.
Andi Wijaya,andi.wijaya@gmail.com,Paket B,IPS,60,80,80,Bagus dalam interaksi kelompok sosial.
Sarah Kartika,sarah.kartika@gmail.com,Paket C,Sosiologi,40,82,82,Pendaftaran eksternal otomatis disinkronkan.`;
    } else {
      sample = `name,email,package,gender
Budi Pratama,budi.pratama@gmail.com,Paket C,Laki-laki
Aisyah Rahma,aisyah.rahma@gmail.com,Paket B,Perempuan
Eko Susilo,eko.susilo@gmail.com,Paket A,Laki-laki
Dewi Lestari,dewi.lestari@gmail.com,Paket C,Perempuan`;
    }
    setCsvInput(sample);
    parseCsv(sample, importType);
  };

  // Standard CSV Parser supporting dynamic imports
  const parseCsv = (text: string, type: 'RAPORT' | 'SISWA' = importType) => {
    const lines = text.split('\n').filter(line => line.trim() !== '');
    if (lines.length <= 1) {
      setSyncPreview([]);
      return;
    }

    const delimiter = lines[0].includes(';') ? ';' : ',';
    const headers = lines[0].split(delimiter).map(h => h.trim().replace(/^["']|["']$/g, ''));
    const rows = [];

    for (let i = 1; i < lines.length; i++) {
      const values = lines[i].split(delimiter).map(v => v.trim().replace(/^["']|["']$/g, ''));
      if (values.length < headers.length) continue;

      const obj: any = {};
      headers.forEach((header, idx) => {
        obj[header] = values[idx];
      });
      rows.push(obj);
    }
    setSyncPreview(rows);
  };

  const processFile = (file: File) => {
    const reader = new FileReader();
    reader.onload = (event) => {
      const text = event.target?.result as string;
      setCsvInput(text);
      parseCsv(text, importType);
    };
    reader.readAsText(file);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    processFile(file);
  };

  // Drag and Drop support
  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files?.[0];
    if (file) {
      processFile(file);
    }
  };

  const handleCommitSync = () => {
    if (syncPreview.length === 0) return;

    if (importType === 'RAPORT') {
      const res = syncExternalReportCards(syncPreview);
      setSyncResults(res);
    } else {
      // Import type is SISWA
      let successCount = 0;
      const errors: string[] = [];

      syncPreview.forEach((row, index) => {
        const name = row.name || row.studentName;
        const email = row.email;
        const pkg = row.package || 'Paket C';
        const gender = row.gender || 'Laki-laki';

        if (!name || !email) {
          errors.push(`Baris ${index + 1}: Data nama atau email kosong.`);
          return;
        }

        // Check if student already registered by email
        const isExists = students.some(s => s.email.toLowerCase() === email.toLowerCase());
        if (isExists) {
          errors.push(`Baris ${index + 1}: Siswa dengan email "${email}" sudah terdaftar.`);
          return;
        }

        addStudent({
          name,
          email,
          package: pkg as any,
          gender: gender as any
        });
        successCount++;
      });

      setSyncResults({
        successCount,
        errors
      });
    }

    setSyncPreview([]);
    setCsvInput('');
    setTimeout(() => {
      setSyncResults(null);
    }, 5000);
  };

  // Inline grading updates for students
  const [editingStudentId, setEditingStudentId] = useState<string | null>(null);
  const [editGrades, setEditGrades] = useState<GradeItem[]>([]);

  const handleStartEditGrades = (rc: ReportCard) => {
    setEditingStudentId(rc.studentId);
    setEditGrades(JSON.parse(JSON.stringify(rc.grades)));
  };

  const handleGradeChange = (idx: number, field: keyof GradeItem, val: any) => {
    const updated = [...editGrades];
    if (field === 'finalScore') {
      updated[idx].finalScore = Math.min(100, Math.max(0, Number(val)));
    } else if (field === 'preTestScore') {
      updated[idx].preTestScore = val === '' ? null : Math.min(100, Math.max(0, Number(val)));
    } else if (field === 'postTestScore') {
      updated[idx].postTestScore = val === '' ? null : Math.min(100, Math.max(0, Number(val)));
    } else if (field === 'teacherNote') {
      updated[idx].teacherNote = val;
    }
    setEditGrades(updated);
  };

  const handleSaveGrades = (rc: ReportCard) => {
    updateReportCard({
      ...rc,
      grades: editGrades,
      updatedAt: new Date().toISOString()
    });
    setEditingStudentId(null);
  };

  return (
    <div className="space-y-8 animate-fade-in">
      {/* Branding Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
        <div>
          <span className="text-xs font-bold text-blue-600 uppercase tracking-widest bg-blue-50 px-3 py-1 rounded-full">Portal Administrasi Operator</span>
          <h1 className="text-2xl font-black text-slate-900 mt-2">Budi Santoso, S.Kom.</h1>
          <p className="text-sm text-slate-500 mt-1">Mengelola Data Pendaftaran, Registrasi Siswa, dan Sinkronisasi Laporan Nilai Eksternal</p>
        </div>
        
        <div className="flex gap-2">
          <button
            onClick={() => {
              setActiveTab('SYNC');
              loadSampleCsvData();
            }}
            className="flex items-center gap-2 px-4 py-2 text-xs font-bold bg-indigo-50 text-indigo-700 rounded-xl hover:bg-indigo-100 transition-all cursor-pointer"
          >
            <RefreshCw className="w-3.5 h-3.5" /> Uji Coba Sinkronisasi
          </button>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex border-b border-slate-200 gap-1 bg-slate-100 p-1 rounded-xl max-w-md">
        <button
          onClick={() => setActiveTab('REGISTRASI')}
          className={`flex-1 py-2 text-xs font-bold rounded-lg transition-all cursor-pointer ${
            activeTab === 'REGISTRASI' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600 hover:text-indigo-600'
          }`}
        >
          Konfirmasi Registrasi ({pendingStudents.length})
        </button>
        <button
          onClick={() => setActiveTab('SISWA')}
          className={`flex-1 py-2 text-xs font-bold rounded-lg transition-all cursor-pointer ${
            activeTab === 'SISWA' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600 hover:text-indigo-600'
          }`}
        >
          Data & Raport Siswa
        </button>
        <button
          onClick={() => setActiveTab('SYNC')}
          className={`flex-1 py-2 text-xs font-bold rounded-lg transition-all cursor-pointer ${
            activeTab === 'SYNC' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600 hover:text-indigo-600'
          }`}
        >
          Sinkronisasi Raport File
        </button>
      </div>

      {/* REGISTRASI TAB */}
      {activeTab === 'REGISTRASI' && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6 space-y-6">
          <div>
            <h3 className="text-lg font-bold text-slate-900">Pendaftaran Menunggu Persetujuan</h3>
            <p className="text-xs text-slate-400">Pendaftar baru yang mendaftar secara online dan membutuhkan verifikasi berkas paket kesetaraan</p>
          </div>

          {pendingStudents.length === 0 ? (
            <div className="text-center py-12 bg-slate-50 rounded-2xl border border-dashed border-slate-200">
              <Users className="w-12 h-12 text-slate-300 mx-auto mb-3" />
              <p className="text-sm font-semibold text-slate-600">Tidak ada pendaftaran tertunda</p>
              <p className="text-xs text-slate-400 mt-1">Semua pendaftar baru telah disetujui atau disinkronisasi.</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {pendingStudents.map((stud) => (
                <div key={stud.id} className="p-4 border border-slate-200 rounded-xl bg-slate-50/50 flex flex-col justify-between gap-4">
                  <div className="flex items-start justify-between">
                    <div>
                      <h4 className="text-sm font-bold text-slate-900">{stud.name}</h4>
                      <p className="text-xs text-slate-500 mt-0.5">{stud.email}</p>
                      <p className="text-xs text-slate-400 mt-1">Tgl Daftar: {stud.registrationDate}</p>
                    </div>
                    <div className="flex flex-col items-end gap-1">
                      <span className="text-[10px] font-black uppercase tracking-wider bg-amber-50 text-amber-700 border border-amber-200 px-2.5 py-0.5 rounded-full">
                        {stud.package} ({stud.package === 'Paket A' ? 'Setara SD' : stud.package === 'Paket B' ? 'Setara SMP' : 'Setara SMA'})
                      </span>
                      <span className="text-[10px] text-slate-400">{stud.gender}</span>
                    </div>
                  </div>

                  <div className="flex gap-2 border-t border-slate-200 pt-3">
                    <button
                      onClick={() => approveStudent(stud.id)}
                      className="flex-1 py-2 text-xs font-bold bg-emerald-600 text-white rounded-lg hover:bg-emerald-700 transition-all flex items-center justify-center gap-1.5 cursor-pointer"
                    >
                      <UserCheck className="w-4 h-4" /> Setujui & Berikan Akses
                    </button>
                    <button
                      onClick={() => rejectStudent(stud.id)}
                      className="px-3 py-2 text-xs font-bold bg-rose-50 text-rose-700 rounded-lg hover:bg-rose-100 transition-all flex items-center justify-center cursor-pointer"
                      title="Tolak Pendaftaran"
                    >
                      <UserX className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* SISWA & RAPORT TAB */}
      {activeTab === 'SISWA' && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6 space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h3 className="text-lg font-bold text-slate-900">Directory Siswa & Penilaian</h3>
              <p className="text-xs text-slate-400">Cari siswa, pantau keaktifan, serta sunting laporan raport hasil ujian pre/post test</p>
            </div>

            <button
              onClick={() => setShowAddForm(!showAddForm)}
              className="flex items-center gap-1.5 px-4 py-2 text-xs font-bold bg-indigo-600 text-white rounded-xl hover:bg-indigo-700 transition-all cursor-pointer"
            >
              <PlusCircle className="w-4 h-4" /> Tambah Siswa Manual
            </button>
          </div>

          {/* Quick Registration Form Drawer */}
          {showAddForm && (
            <form onSubmit={handleCreateStudent} className="p-5 border border-slate-200 bg-slate-50 rounded-xl space-y-4 animate-fade-in">
              <h4 className="text-sm font-bold text-slate-800">Formulir Pendaftaran Siswa Baru</h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-500 mb-1 uppercase">Nama Lengkap</label>
                  <input
                    type="text"
                    required
                    placeholder="Nama Siswa"
                    value={newStudName}
                    onChange={(e) => setNewStudName(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-200 bg-white rounded-lg text-sm"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-500 mb-1 uppercase">Email</label>
                  <input
                    type="email"
                    required
                    placeholder="email@domain.com"
                    value={newStudEmail}
                    onChange={(e) => setNewStudEmail(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-200 bg-white rounded-lg text-sm"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-500 mb-1 uppercase">Program Paket</label>
                  <select
                    value={newStudPkg}
                    onChange={(e) => setNewStudPkg(e.target.value as any)}
                    className="w-full px-2 py-2 border border-slate-200 bg-white rounded-lg text-sm"
                  >
                    <option value="Paket A">Paket A (Setara SD/Sederajat)</option>
                    <option value="Paket B">Paket B (Setara SMP/Sederajat)</option>
                    <option value="Paket C">Paket C (Setara SMA/Sederajat)</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-500 mb-1 uppercase">Jenis Kelamin</label>
                  <select
                    value={newStudGender}
                    onChange={(e) => setNewStudGender(e.target.value as any)}
                    className="w-full px-2 py-2 border border-slate-200 bg-white rounded-lg text-sm"
                  >
                    <option value="Laki-laki">Laki-laki</option>
                    <option value="Perempuan">Perempuan</option>
                  </select>
                </div>
              </div>
              <div className="flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowAddForm(false)}
                  className="px-4 py-2 text-xs font-bold bg-slate-200 text-slate-700 rounded-lg"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 text-xs font-bold bg-indigo-600 text-white rounded-lg"
                >
                  Daftarkan Siswa
                </button>
              </div>
            </form>
          )}

          {/* Filters Bar */}
          <div className="flex flex-col sm:flex-row gap-3">
            <div className="relative flex-1">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
              <input
                type="text"
                placeholder="Cari nama atau email siswa..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-9 pr-4 py-2.5 border border-slate-200 rounded-xl text-sm focus:outline-none"
              />
            </div>
            
            <div className="flex items-center gap-1.5">
              <Filter className="w-4 h-4 text-slate-400" />
              <select
                value={packageFilter}
                onChange={(e) => setPackageFilter(e.target.value as any)}
                className="px-3 py-2.5 border border-slate-200 bg-white rounded-xl text-xs font-bold"
              >
                <option value="ALL">Semua Jenjang</option>
                <option value="Paket A">Paket A (Setara SD/Sederajat)</option>
                <option value="Paket B">Paket B (Setara SMP/Sederajat)</option>
                <option value="Paket C">Paket C (Setara SMA/Sederajat)</option>
              </select>
            </div>
          </div>

          {/* Student Table */}
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-200 text-[10px] text-slate-400 font-bold uppercase tracking-wider">
                  <th className="pb-2">Siswa</th>
                  <th className="pb-2">Program</th>
                  <th className="pb-2">Tanggal Terdaftar</th>
                  <th className="pb-2">Nilai Raport Ter-update</th>
                  <th className="pb-2 text-right">Tindakan Nilai</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-sm">
                {filteredStudents.map((stud) => {
                  const card = reportCards.find(rc => rc.studentId === stud.id);
                  const isEditing = editingStudentId === stud.id;

                  return (
                    <tr key={stud.id} className="hover:bg-slate-50/40">
                      <td className="py-4">
                        <div>
                          <p className="font-bold text-slate-900">{stud.name}</p>
                          <p className="text-xs text-slate-500 font-mono">{stud.email}</p>
                        </div>
                      </td>
                      <td className="py-4">
                        <span className={`px-2 py-1 text-[11px] font-black rounded-lg border ${
                          stud.package === 'Paket A' 
                            ? 'bg-amber-50 border-amber-200 text-amber-800' 
                            : stud.package === 'Paket B'
                              ? 'bg-blue-50 border-blue-200 text-blue-800'
                              : 'bg-emerald-50 border-emerald-200 text-emerald-800'
                        }`}>
                          {stud.package} ({stud.package === 'Paket A' ? 'Setara SD' : stud.package === 'Paket B' ? 'Setara SMP' : 'Setara SMA'})
                        </span>
                      </td>
                      <td className="py-4 text-xs text-slate-500">{stud.registrationDate}</td>
                      <td className="py-4 text-xs">
                        {card ? (
                          <div className="flex flex-wrap gap-1">
                            {card.grades.map((g, idx) => (
                              <span key={idx} className="bg-indigo-50 border border-indigo-100 text-[10px] font-bold text-indigo-700 px-1.5 py-0.5 rounded">
                                {g.subject}: {g.finalScore}
                              </span>
                            ))}
                          </div>
                        ) : (
                          <span className="text-slate-400">Belum ada nilai</span>
                        )}
                      </td>
                      <td className="py-4 text-right">
                        {card && (
                          <>
                            {!isEditing ? (
                              <button
                                onClick={() => handleStartEditGrades(card)}
                                className="px-3 py-1 text-xs font-bold bg-slate-100 text-slate-700 hover:bg-indigo-50 hover:text-indigo-700 rounded-lg transition-all cursor-pointer"
                              >
                                Sunting Nilai
                              </button>
                            ) : (
                              <button
                                onClick={() => setEditingStudentId(null)}
                                className="px-3 py-1 text-xs font-bold bg-slate-200 text-slate-600 rounded-lg cursor-pointer"
                              >
                                Batal
                              </button>
                            )}
                          </>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          {/* Inline Edit Panel when EditingStudentId matches */}
          {editingStudentId && (() => {
            const rc = reportCards.find(card => card.studentId === editingStudentId);
            if (!rc) return null;
            return (
              <div className="p-5 border border-indigo-100 bg-indigo-50/20 rounded-xl space-y-4 animate-fade-in">
                <div className="flex items-center justify-between">
                  <h4 className="text-sm font-bold text-slate-900">
                    Mengedit Nilai Raport: <span className="text-indigo-700">{rc.studentName}</span> ({rc.package})
                  </h4>
                  <div className="flex gap-2">
                    <button
                      onClick={() => setEditingStudentId(null)}
                      className="px-3 py-1.5 text-xs font-bold bg-slate-100 text-slate-700 rounded-lg"
                    >
                      Batal
                    </button>
                    <button
                      onClick={() => handleSaveGrades(rc)}
                      className="px-3 py-1.5 text-xs font-bold bg-indigo-600 text-white rounded-lg shadow-sm"
                    >
                      Simpan Perubahan
                    </button>
                  </div>
                </div>

                <div className="space-y-3">
                  {editGrades.map((g, idx) => (
                    <div key={idx} className="grid grid-cols-1 md:grid-cols-4 gap-3 bg-white p-3 rounded-lg border border-slate-200">
                      <div className="flex items-center">
                        <span className="text-xs font-black text-slate-700">{g.subject}</span>
                      </div>
                      <div>
                        <label className="block text-[9px] font-bold text-slate-400 uppercase">Pre-test Score</label>
                        <input
                          type="number"
                          placeholder="null"
                          value={g.preTestScore !== null ? g.preTestScore : ''}
                          onChange={(e) => handleGradeChange(idx, 'preTestScore', e.target.value)}
                          className="w-full px-2 py-1 border border-slate-200 rounded text-xs mt-0.5"
                        />
                      </div>
                      <div>
                        <label className="block text-[9px] font-bold text-slate-400 uppercase">Post-test Score</label>
                        <input
                          type="number"
                          placeholder="null"
                          value={g.postTestScore !== null ? g.postTestScore : ''}
                          onChange={(e) => handleGradeChange(idx, 'postTestScore', e.target.value)}
                          className="w-full px-2 py-1 border border-slate-200 rounded text-xs mt-0.5"
                        />
                      </div>
                      <div>
                        <label className="block text-[9px] font-bold text-slate-400 uppercase">Final Score (Raport)</label>
                        <input
                          type="number"
                          value={g.finalScore}
                          onChange={(e) => handleGradeChange(idx, 'finalScore', e.target.value)}
                          className="w-full px-2 py-1 border border-slate-200 rounded text-xs font-bold text-indigo-700 mt-0.5"
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            );
          })()}
        </div>
      )}

      {/* SYNC TAB */}
      {activeTab === 'SYNC' && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6 space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h3 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                <Upload className="w-5 h-5 text-indigo-600" /> 
                {importType === 'RAPORT' 
                  ? 'Sinkronisasi Raport Siswa dari File Eksternal' 
                  : 'Pendaftaran Massal (Bulk Register) Siswa'
                }
              </h3>
              <p className="text-xs text-slate-400">
                {importType === 'RAPORT' 
                  ? 'Unggah berkas nilai CSV/Excel hasil ujian, atau tempelkan data untuk sinkronisasi nilai otomatis secara komprehensif.'
                  : 'Unggah data siswa baru dalam bentuk CSV/Excel untuk mendaftarkan banyak siswa sekaligus secara cepat.'
                }
              </p>
            </div>

            <div className="flex gap-2 shrink-0">
              <button
                onClick={downloadCsvTemplate}
                className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-bold border border-slate-200 text-slate-700 rounded-xl hover:bg-slate-50 transition-all cursor-pointer"
              >
                <Download className="w-4 h-4" /> Unduh Template CSV
              </button>
              <button
                onClick={loadSampleCsvData}
                className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-bold bg-indigo-50 text-indigo-700 rounded-xl hover:bg-indigo-100 transition-all cursor-pointer"
              >
                <FileSpreadsheet className="w-4 h-4" /> Muat Contoh Data
              </button>
            </div>
          </div>

          {/* Import Type Switcher */}
          <div className="flex bg-slate-100 p-1 rounded-xl max-w-md">
            <button
              onClick={() => {
                setImportType('RAPORT');
                setSyncPreview([]);
                setCsvInput('');
              }}
              className={`flex-1 py-1.5 text-xs font-bold rounded-lg transition-all cursor-pointer ${
                importType === 'RAPORT' ? 'bg-white text-indigo-700 shadow-sm' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Sinkronisasi Raport (Nilai)
            </button>
            <button
              onClick={() => {
                setImportType('SISWA');
                setSyncPreview([]);
                setCsvInput('');
              }}
              className={`flex-1 py-1.5 text-xs font-bold rounded-lg transition-all cursor-pointer ${
                importType === 'SISWA' ? 'bg-white text-indigo-700 shadow-sm' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Impor Massal Siswa Baru
            </button>
          </div>

          {/* Sync success alert */}
          {syncResults && (
            <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-sm space-y-1">
              <div className="font-bold flex items-center gap-2">
                <Check className="w-5 h-5 text-emerald-600" />
                Proses Impor Berhasil!
              </div>
              <p className="text-xs text-emerald-700">
                Sebanyak <span className="font-bold">{syncResults.successCount} data {importType === 'RAPORT' ? 'nilai raport' : 'siswa baru'}</span> berhasil diproses dan disimpan ke database lokal PKBM.
              </p>
              {syncResults.errors.length > 0 && (
                <div className="mt-2 text-xs text-rose-700 bg-rose-50 p-2.5 rounded border border-rose-100">
                  <span className="font-bold">Beberapa baris dilewati akibat error/duplikasi:</span>
                  <ul className="list-disc pl-4 mt-1">
                    {syncResults.errors.map((err, i) => <li key={i}>{err}</li>)}
                  </ul>
                </div>
              )}
            </div>
          )}

          {/* File Upload Zone */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div 
                onClick={() => fileInputRef.current?.click()}
                onDragOver={handleDragOver}
                onDragLeave={handleDragLeave}
                onDrop={handleDrop}
                className={`border-2 border-dashed rounded-2xl p-8 text-center cursor-pointer transition-all group ${
                  isDragging 
                    ? 'border-indigo-600 bg-indigo-50/30 shadow-inner' 
                    : 'border-slate-200 hover:border-indigo-500 bg-slate-50/50 hover:bg-indigo-50/10'
                }`}
              >
                <Upload className={`w-10 h-10 mx-auto mb-3 transition-colors ${isDragging ? 'text-indigo-600' : 'text-slate-400 group-hover:text-indigo-600'}`} />
                <p className="text-sm font-bold text-slate-700">
                  {isDragging ? 'Lepas berkas di sini...' : 'Tarik & Lepas berkas atau Klik untuk memilih'}
                </p>
                <p className="text-xs text-slate-400 mt-1">
                  Mendukung berkas CSV atau TXT terformat ({importType === 'RAPORT' ? 'Format Raport' : 'Format Data Siswa'})
                </p>
                <input
                  type="file"
                  ref={fileInputRef}
                  onChange={handleFileUpload}
                  accept=".csv,.txt"
                  className="hidden"
                />
              </div>

              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="text-xs font-bold text-slate-500 uppercase">
                    Atau Tempelkan (Paste) Kode CSV {importType === 'RAPORT' ? 'Nilai' : 'Siswa'}
                  </label>
                  {csvInput && (
                    <button onClick={() => {setCsvInput(''); setSyncPreview([]);}} className="text-xs text-rose-600 font-semibold hover:underline cursor-pointer">Hapus</button>
                  )}
                </div>
                <textarea
                  rows={5}
                  value={csvInput}
                  onChange={(e) => {
                    setCsvInput(e.target.value);
                    parseCsv(e.target.value);
                  }}
                  placeholder={
                    importType === 'RAPORT'
                      ? "studentName,email,package,subject,preTestScore,postTestScore,finalScore,teacherNote\nContoh: Andi Wijaya,andi.wijaya@gmail.com,Paket B,IPA,60,80,80,Sangat aktif."
                      : "name,email,package,gender\nContoh: Budi Pratama,budi.pratama@gmail.com,Paket C,Laki-laki"
                  }
                  className="w-full p-3 border border-slate-200 bg-slate-50/50 rounded-xl text-xs font-mono outline-none focus:ring-2 focus:ring-indigo-500 focus:bg-white text-slate-800"
                />
              </div>
            </div>

            {/* Sync Preview Panel */}
            <div className="border border-slate-100 rounded-2xl bg-slate-50 p-5 space-y-4 flex flex-col justify-between">
              <div>
                <h4 className="text-sm font-bold text-slate-900 flex items-center gap-1.5">
                  <RefreshCw className="w-4 h-4 text-indigo-600 animate-spin-slow" /> Preview Hasil ({syncPreview.length} Baris)
                </h4>
                <p className="text-xs text-slate-400 mt-0.5">Tinjau baris data yang akan dimasukkan ke sistem kesetaraan PKBM</p>
                
                {syncPreview.length === 0 ? (
                  <div className="py-12 text-center text-xs text-slate-400">
                    Belum ada berkas terunggah atau data yang ditempel.
                  </div>
                ) : (
                  <div className="mt-3 space-y-2 max-h-64 overflow-y-auto pr-1">
                    {syncPreview.map((row, idx) => {
                      if (importType === 'RAPORT') {
                        // Check if student exists in our database
                        const exists = students.some(s => s.name.toLowerCase() === row.studentName?.toLowerCase() || (row.email && s.email.toLowerCase() === row.email?.toLowerCase()));
                        return (
                          <div key={idx} className="p-3 bg-white border border-slate-100 rounded-xl text-xs flex justify-between items-start gap-3 shadow-2xs">
                            <div className="text-left">
                              <p className="font-bold text-slate-900">{row.studentName || 'N/A'}</p>
                              <p className="text-[10px] text-slate-500 mt-0.5">{row.subject || 'Mata Pelajaran'} • Final: <span className="font-extrabold text-indigo-600">{row.finalScore || '0'}</span></p>
                              <p className="text-[10px] text-slate-400 italic mt-1 font-medium">"{row.teacherNote || '-'}"</p>
                            </div>
                            <div className="flex flex-col items-end gap-1 shrink-0">
                              <span className="text-[9px] font-bold bg-slate-100 text-slate-700 px-1.5 py-0.5 rounded">
                                {row.package || 'Paket C'}
                              </span>
                              {exists ? (
                                <span className="text-[9px] font-semibold text-emerald-600 bg-emerald-50 px-1.5 py-0.5 rounded border border-emerald-100">Update Raport</span>
                              ) : (
                                <span className="text-[9px] font-semibold text-blue-600 bg-blue-50 px-1.5 py-0.5 rounded border border-blue-100" title="Siswa baru akan didaftarkan otomatis">Auto-Daftar</span>
                              )}
                            </div>
                          </div>
                        );
                      } else {
                        // SISWA mode
                        const name = row.name || row.studentName;
                        const email = row.email;
                        const exists = students.some(s => s.email.toLowerCase() === email?.toLowerCase());
                        return (
                          <div key={idx} className="p-3 bg-white border border-slate-100 rounded-xl text-xs flex justify-between items-start gap-3 shadow-2xs">
                            <div className="text-left">
                              <p className="font-bold text-slate-900">{name || 'N/A'}</p>
                              <p className="text-[10px] text-slate-500 mt-0.5">{email || 'N/A'}</p>
                              <p className="text-[10px] text-slate-400 mt-1 font-medium">Gender: {row.gender || 'Laki-laki'}</p>
                            </div>
                            <div className="flex flex-col items-end gap-1 shrink-0">
                              <span className="text-[9px] font-bold bg-slate-100 text-slate-700 px-1.5 py-0.5 rounded">
                                {row.package || 'Paket C'}
                              </span>
                              {exists ? (
                                <span className="text-[9px] font-semibold text-rose-600 bg-rose-50 px-1.5 py-0.5 rounded border border-rose-100">Duplikat Email</span>
                              ) : (
                                <span className="text-[9px] font-semibold text-emerald-600 bg-emerald-50 px-1.5 py-0.5 rounded border border-emerald-100">Siap Impor</span>
                              )}
                            </div>
                          </div>
                        );
                      }
                    })}
                  </div>
                )}
              </div>

              {syncPreview.length > 0 && (
                <button
                  onClick={handleCommitSync}
                  className="w-full py-3 bg-indigo-600 text-white rounded-xl text-xs font-black hover:bg-indigo-700 shadow-lg shadow-indigo-100 transition-all flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <Check className="w-4 h-4" /> 
                  {importType === 'RAPORT' 
                    ? `Jalankan Sinkronisasi ${syncPreview.length} Baris Nilai`
                    : `Impor Massal ${syncPreview.length} Siswa`
                  }
                </button>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
