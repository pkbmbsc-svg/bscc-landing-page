export type Role = 'KEPALA_SEKOLAH' | 'OPERATOR' | 'GURU' | 'SISWA';

export interface User {
  id: string;
  name: string;
  email: string;
  role: Role;
  package?: 'Paket A' | 'Paket B' | 'Paket C'; // for students
  subject?: string; // for teachers
  avatar?: string;
}

export interface Student {
  id: string;
  name: string;
  email: string;
  package: 'Paket A' | 'Paket B' | 'Paket C';
  status: 'Aktif' | 'Lulus' | 'Menunggu';
  registrationDate: string;
  gender: 'Laki-laki' | 'Perempuan';
}

export interface Question {
  id: string;
  text: string;
  options: string[];
  correctAnswerIndex: number;
}

export interface Lesson {
  id: string;
  title: string;
  subject: string;
  package: 'Paket A' | 'Paket B' | 'Paket C';
  videoUrl: string; // YouTube or local path
  videoDuration: string; // e.g., "12:45"
  description: string;
  teacherId: string;
  teacherName: string;
}

export interface Test {
  id: string;
  lessonId: string;
  type: 'pretest' | 'posttest';
  questions: Question[];
}

export interface TestAttempt {
  id: string;
  studentId: string;
  studentName: string;
  lessonId: string;
  testId: string;
  type: 'pretest' | 'posttest';
  score: number; // percentage, e.g. 85
  correctCount: number;
  totalQuestions: number;
  completedAt: string;
}

export interface GradeItem {
  subject: string;
  preTestScore: number | null;
  postTestScore: number | null;
  finalScore: number;
  teacherNote: string;
}

export interface ReportCard {
  id: string;
  studentId: string;
  studentName: string;
  package: 'Paket A' | 'Paket B' | 'Paket C';
  grades: GradeItem[];
  attendanceRate: number; // e.g. 95%
  characterNote: string;
  status: 'Lulus' | 'Sedang Belajar' | 'Belum Lulus';
  updatedAt: string;
  academicYear: string;
  verpalIndex?: number; // Indeks Verpal (Validasi Kebenaran & Kritis) e.g. 92/100
  focusLevel?: number; // Level Homeostasis & Fokus Belajar e.g. 95%
  coherenceScore?: number; // Skor Koherensi Karya Vokasi e.g. 90/100
}

// S.O.K.S Protocol Data Interfaces
export interface StudentGoal {
  id: string;
  studentId: string;
  targetCareer: string;
  motivationReason: string;
  targetGraduationYear: string;
  skillsToMaster: string[];
  createdAt: string;
}

export interface VocationalProject {
  id: string;
  studentId: string;
  studentName: string;
  package: 'Paket A' | 'Paket B' | 'Paket C';
  title: string;
  category: string; // e.g., 'UMKM & Kewirausahaan', 'Teknologi Terapan', 'Seni & Kerajinan', 'Lingkungan'
  description: string;
  impactNote: string; // Impact on community
  imageUrl?: string;
  status: 'Draft' | 'Ditinjau' | 'Disetujui' | 'Terpublikasi';
  coherenceScore?: number; // 0 - 100
  createdAt: string;
}

export interface VerpalQuizItem {
  id: string;
  title: string;
  contextSnippet: string;
  statement: string;
  isFact: boolean; // True if verified fact (Rp), False if hoax/manipulation (Im)
  explanation: string;
  category: 'Literasi Digital' | 'Sains & Kesehatan' | 'Sosial & Ekonomi' | 'Etika Komunikasi';
}

// KPI interfaces for Principal Dashboard
export interface TeacherKPI {
  teacherId: string;
  name: string;
  subject: string;
  videosUploaded: number;
  testsCreated: number;
  averageStudentScore: number;
  studentInteractionRate: number; // percentage
  resonanceScore?: number; // MKL Resonansi Score (Phi) e.g. 9.85 / 10
  kpiRating: number; // 1-5 scale
}

export interface OperatorKPI {
  operatorId: string;
  name: string;
  syncsProcessed: number;
  registrationsApproved: number;
  dataUpdatesCount: number;
  systemAccuracy: number; // percentage e.g. 99%
  kpiRating: number; // 1-5 scale
}

export interface StudentKPI {
  studentId: string;
  name: string;
  package: 'Paket A' | 'Paket B' | 'Paket C';
  lessonsWatched: number;
  testsCompleted: number;
  averageScore: number;
  completionRate: number; // percentage
}
