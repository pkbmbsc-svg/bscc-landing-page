import React, { createContext, useContext, useState, useEffect } from 'react';
import { 
  User, Student, Lesson, Test, TestAttempt, ReportCard, 
  TeacherKPI, OperatorKPI, StudentKPI, GradeItem,
  StudentGoal, VocationalProject, VerpalQuizItem
} from '../types';
import { 
  INITIAL_USERS, INITIAL_STUDENTS, INITIAL_LESSONS, 
  INITIAL_TESTS, INITIAL_ATTEMPTS, INITIAL_REPORT_CARDS,
  INITIAL_TEACHER_KPI, INITIAL_OPERATOR_KPI, INITIAL_STUDENT_KPI,
  INITIAL_STUDENT_GOALS, INITIAL_VOCATIONAL_PROJECTS, INITIAL_VERPAL_ITEMS
} from '../initialData';

interface AppContextType {
  currentUser: User | null;
  users: User[];
  students: Student[];
  lessons: Lesson[];
  tests: Test[];
  attempts: TestAttempt[];
  reportCards: ReportCard[];
  teacherKPIs: TeacherKPI[];
  operatorKPIs: OperatorKPI[];
  studentKPIs: StudentKPI[];
  studentGoals: StudentGoal[];
  vocationalProjects: VocationalProject[];
  verpalItems: VerpalQuizItem[];
  login: (userId: string) => void;
  logout: () => void;
  setCurrentUserRole: (role: any) => void;
  addStudent: (student: Omit<Student, 'id' | 'status' | 'registrationDate'>) => void;
  approveStudent: (studentId: string) => void;
  rejectStudent: (studentId: string) => void;
  addLesson: (lesson: Omit<Lesson, 'id' | 'teacherId' | 'teacherName'>) => string;
  addTest: (test: Test) => void;
  submitTestAttempt: (attempt: Omit<TestAttempt, 'id' | 'completedAt'>) => void;
  updateReportCard: (reportCard: ReportCard) => void;
  syncExternalReportCards: (importedData: any[]) => { successCount: number; errors: string[] };
  triggerOperatorActivity: (operatorId: string, activityType: 'sync' | 'update' | 'approve') => void;
  saveStudentGoal: (goal: Omit<StudentGoal, 'id' | 'createdAt'>) => void;
  addVocationalProject: (project: Omit<VocationalProject, 'id' | 'createdAt' | 'status'>) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Load state from localStorage or seed initial data
  const [currentUser, setCurrentUser] = useState<User | null>(() => {
    const saved = localStorage.getItem('es_current_user');
    return saved ? JSON.parse(saved) : INITIAL_USERS[0]; // Default to Kepala Sekolah for demo convenience
  });

  const [users, setUsers] = useState<User[]>(() => {
    const saved = localStorage.getItem('es_users');
    return saved ? JSON.parse(saved) : INITIAL_USERS;
  });

  const [students, setStudents] = useState<Student[]>(() => {
    const saved = localStorage.getItem('es_students');
    return saved ? JSON.parse(saved) : INITIAL_STUDENTS;
  });

  const [lessons, setLessons] = useState<Lesson[]>(() => {
    const saved = localStorage.getItem('es_lessons');
    return saved ? JSON.parse(saved) : INITIAL_LESSONS;
  });

  const [tests, setTests] = useState<Test[]>(() => {
    const saved = localStorage.getItem('es_tests');
    return saved ? JSON.parse(saved) : INITIAL_TESTS;
  });

  const [attempts, setAttempts] = useState<TestAttempt[]>(() => {
    const saved = localStorage.getItem('es_attempts');
    return saved ? JSON.parse(saved) : INITIAL_ATTEMPTS;
  });

  const [reportCards, setReportCards] = useState<ReportCard[]>(() => {
    const saved = localStorage.getItem('es_report_cards');
    return saved ? JSON.parse(saved) : INITIAL_REPORT_CARDS;
  });

  const [teacherKPIs, setTeacherKPIs] = useState<TeacherKPI[]>(() => {
    const saved = localStorage.getItem('es_teacher_kpis');
    return saved ? JSON.parse(saved) : INITIAL_TEACHER_KPI;
  });

  const [operatorKPIs, setOperatorKPIs] = useState<OperatorKPI[]>(() => {
    const saved = localStorage.getItem('es_operator_kpis');
    return saved ? JSON.parse(saved) : INITIAL_OPERATOR_KPI;
  });

  const [studentKPIs, setStudentKPIs] = useState<StudentKPI[]>(() => {
    const saved = localStorage.getItem('es_student_kpis');
    return saved ? JSON.parse(saved) : INITIAL_STUDENT_KPI;
  });

  const [studentGoals, setStudentGoals] = useState<StudentGoal[]>(() => {
    const saved = localStorage.getItem('es_student_goals');
    return saved ? JSON.parse(saved) : INITIAL_STUDENT_GOALS;
  });

  const [vocationalProjects, setVocationalProjects] = useState<VocationalProject[]>(() => {
    const saved = localStorage.getItem('es_vocational_projects');
    return saved ? JSON.parse(saved) : INITIAL_VOCATIONAL_PROJECTS;
  });

  const [verpalItems] = useState<VerpalQuizItem[]>(INITIAL_VERPAL_ITEMS);

  // Save state to localStorage whenever it changes
  useEffect(() => {
    localStorage.setItem('es_current_user', JSON.stringify(currentUser));
  }, [currentUser]);

  useEffect(() => {
    localStorage.setItem('es_users', JSON.stringify(users));
  }, [users]);

  useEffect(() => {
    localStorage.setItem('es_students', JSON.stringify(students));
  }, [students]);

  useEffect(() => {
    localStorage.setItem('es_lessons', JSON.stringify(lessons));
  }, [lessons]);

  useEffect(() => {
    localStorage.setItem('es_tests', JSON.stringify(tests));
  }, [tests]);

  useEffect(() => {
    localStorage.setItem('es_attempts', JSON.stringify(attempts));
  }, [attempts]);

  useEffect(() => {
    localStorage.setItem('es_report_cards', JSON.stringify(reportCards));
  }, [reportCards]);

  useEffect(() => {
    localStorage.setItem('es_teacher_kpis', JSON.stringify(teacherKPIs));
  }, [teacherKPIs]);

  useEffect(() => {
    localStorage.setItem('es_operator_kpis', JSON.stringify(operatorKPIs));
  }, [operatorKPIs]);

  useEffect(() => {
    localStorage.setItem('es_student_kpis', JSON.stringify(studentKPIs));
  }, [studentKPIs]);

  useEffect(() => {
    localStorage.setItem('es_student_goals', JSON.stringify(studentGoals));
  }, [studentGoals]);

  useEffect(() => {
    localStorage.setItem('es_vocational_projects', JSON.stringify(vocationalProjects));
  }, [vocationalProjects]);

  // Auth Operations
  const login = (userId: string) => {
    const user = users.find(u => u.id === userId);
    if (user) {
      setCurrentUser(user);
    }
  };

  const logout = () => {
    setCurrentUser(null);
  };

  const setCurrentUserRole = (role: any) => {
    if (currentUser) {
      const updatedUser = { ...currentUser, role };
      setCurrentUser(updatedUser);
      setUsers(prev => prev.map(u => u.id === currentUser.id ? updatedUser : u));
    }
  };

  // Student Registrations (Operator Actions)
  const addStudent = (studentData: Omit<Student, 'id' | 'status' | 'registrationDate'>) => {
    const newId = `std-${String(students.length + 1).padStart(3, '0')}`;
    const newStudent: Student = {
      ...studentData,
      id: newId,
      status: 'Menunggu',
      registrationDate: new Date().toISOString().split('T')[0]
    };
    
    // Add to students list
    setStudents(prev => [newStudent, ...prev]);

    // Create a new corresponding User account for multi-login
    const newUser: User = {
      id: newId,
      name: studentData.name,
      email: studentData.email,
      role: 'SISWA',
      package: studentData.package,
      avatar: `https://images.unsplash.com/photo-${studentData.gender === 'Laki-laki' ? '1500648767791-00dcc994a43e' : '1438761681033-6461ffad8d80'}?w=150`
    };
    setUsers(prev => [...prev, newUser]);

    // Initialize an empty report card for the student
    const newReportCard: ReportCard = {
      id: `rep-${String(reportCards.length + 1).padStart(3, '0')}`,
      studentId: newId,
      studentName: studentData.name,
      package: studentData.package,
      academicYear: '2025/2026 - Genap',
      grades: [
        { subject: 'PPKn', preTestScore: null, postTestScore: null, finalScore: 0, teacherNote: '-' },
        { subject: 'Bahasa Indonesia', preTestScore: null, postTestScore: null, finalScore: 0, teacherNote: '-' },
        { subject: 'Matematika', preTestScore: null, postTestScore: null, finalScore: 0, teacherNote: '-' }
      ],
      attendanceRate: 100,
      characterNote: 'Siswa baru terdaftar.',
      status: 'Sedang Belajar',
      updatedAt: new Date().toISOString()
    };
    setReportCards(prev => [...prev, newReportCard]);

    // Initialize Student KPI
    const newStudentKPI: StudentKPI = {
      studentId: newId,
      name: studentData.name,
      package: studentData.package,
      lessonsWatched: 0,
      testsCompleted: 0,
      averageScore: 0,
      completionRate: 0
    };
    setStudentKPIs(prev => [...prev, newStudentKPI]);
  };

  const approveStudent = (studentId: string) => {
    setStudents(prev => prev.map(s => s.id === studentId ? { ...s, status: 'Aktif' } : s));
    triggerOperatorActivity('usr-op1', 'approve');
  };

  const rejectStudent = (studentId: string) => {
    setStudents(prev => prev.filter(s => s.id !== studentId));
    setUsers(prev => prev.filter(u => u.id !== studentId));
    setReportCards(prev => prev.filter(r => r.studentId !== studentId));
    setStudentKPIs(prev => prev.filter(s => s.studentId !== studentId));
  };

  // Lesson Management (Teacher Actions)
  const addLesson = (lessonData: Omit<Lesson, 'id' | 'teacherId' | 'teacherName'>) => {
    const newId = `les-${String(lessons.length + 1).padStart(3, '0')}`;
    const newLesson: Lesson = {
      ...lessonData,
      id: newId,
      teacherId: currentUser?.id || 'usr-guru1',
      teacherName: currentUser?.name || 'Siti Rahmah, S.Pd.'
    };

    setLessons(prev => [...prev, newLesson]);

    // Update teacher KPI metrics
    setTeacherKPIs(prev => prev.map(kpi => {
      if (kpi.teacherId === (currentUser?.id || 'usr-guru1')) {
        return {
          ...kpi,
          videosUploaded: kpi.videosUploaded + 1,
          kpiRating: Math.min(5, kpi.kpiRating + 0.05)
        };
      }
      return kpi;
    }));

    return newId;
  };

  // Test Management
  const addTest = (newTest: Test) => {
    setTests(prev => {
      // Remove any duplicate tests for the same lesson & type
      const filtered = prev.filter(t => !(t.lessonId === newTest.lessonId && t.type === newTest.type));
      return [...filtered, newTest];
    });

    // Update teacher KPI metric for testsCreated
    if (currentUser?.role === 'GURU') {
      setTeacherKPIs(prev => prev.map(kpi => {
        if (kpi.teacherId === currentUser.id) {
          return {
            ...kpi,
            testsCreated: kpi.testsCreated + 1
          };
        }
        return kpi;
      }));
    }
  };

  // Test Attempt Submissions (Student Actions)
  const submitTestAttempt = (attemptData: Omit<TestAttempt, 'id' | 'completedAt'>) => {
    const newId = `att-${String(attempts.length + 1).padStart(3, '0')}`;
    const newAttempt: TestAttempt = {
      ...attemptData,
      id: newId,
      completedAt: new Date().toISOString().replace('T', ' ').substring(0, 19)
    };

    setAttempts(prev => [...prev, newAttempt]);

    // 1. Update Student KPI
    setStudentKPIs(prev => prev.map(kpi => {
      if (kpi.studentId === attemptData.studentId) {
        const studentAttempts = [...attempts, newAttempt].filter(a => a.studentId === attemptData.studentId);
        const postTestAttempts = studentAttempts.filter(a => a.type === 'posttest');
        const avgScore = postTestAttempts.length > 0 
          ? Math.round(postTestAttempts.reduce((sum, a) => sum + a.score, 0) / postTestAttempts.length)
          : 0;

        // Distinct lessons watched (which is distinct lessons where attempts were made)
        const distinctLessons = new Set(studentAttempts.map(a => a.lessonId)).size;

        return {
          ...kpi,
          testsCompleted: studentAttempts.length,
          lessonsWatched: Math.max(kpi.lessonsWatched, distinctLessons),
          averageScore: avgScore,
          completionRate: Math.round((distinctLessons / lessons.filter(l => l.package === kpi.package).length) * 100)
        };
      }
      return kpi;
    }));

    // 2. Update Teacher KPI (re-evaluate average student score)
    const targetLesson = lessons.find(l => l.id === attemptData.lessonId);
    if (targetLesson) {
      setTeacherKPIs(prev => prev.map(kpi => {
        if (kpi.teacherId === targetLesson.teacherId) {
          // Find all attempts for this teacher's lessons
          const teacherLessonIds = lessons.filter(l => l.teacherId === targetLesson.teacherId).map(l => l.id);
          const teacherAttempts = [...attempts, newAttempt].filter(a => teacherLessonIds.includes(a.lessonId) && a.type === 'posttest');
          const avgScore = teacherAttempts.length > 0 
            ? parseFloat((teacherAttempts.reduce((sum, a) => sum + a.score, 0) / teacherAttempts.length).toFixed(1))
            : kpi.averageStudentScore;

          return {
            ...kpi,
            averageStudentScore: avgScore,
            studentInteractionRate: Math.min(100, kpi.studentInteractionRate + 1)
          };
        }
        return kpi;
      }));
    }

    // 3. Update Student's Report Card dynamically
    setReportCards(prev => prev.map(rep => {
      if (rep.studentId === attemptData.studentId && targetLesson) {
        const grades = [...rep.grades];
        const subjectIdx = grades.findIndex(g => g.subject.toLowerCase() === targetLesson.subject.toLowerCase());
        
        if (subjectIdx !== -1) {
          const item = grades[subjectIdx];
          if (attemptData.type === 'pretest') {
            item.preTestScore = attemptData.score;
          } else {
            item.postTestScore = attemptData.score;
          }
          
          // Calculate final score: weighted or simply post-test or average
          const pre = item.preTestScore !== null ? item.preTestScore : 0;
          const post = item.postTestScore !== null ? item.postTestScore : 0;
          // Let final score be primarily post-test score if available, otherwise average
          item.finalScore = item.postTestScore !== null ? post : Math.round((pre + post) / 2);
          
          if (item.finalScore >= 80) {
            item.teacherNote = 'Sangat baik, memahami materi dengan prima.';
          } else if (item.finalScore >= 70) {
            item.teacherNote = 'Cukup memuaskan, terus pertahankan motivasi belajar.';
          } else {
            item.teacherNote = 'Perlu bimbingan dan pembahasan ulang video pelajaran.';
          }
        } else {
          // Subject not in report card yet, add it
          const newItem: GradeItem = {
            subject: targetLesson.subject,
            preTestScore: attemptData.type === 'pretest' ? attemptData.score : null,
            postTestScore: attemptData.type === 'posttest' ? attemptData.score : null,
            finalScore: attemptData.score,
            teacherNote: 'Pembelajaran mandiri modul video.'
          };
          grades.push(newItem);
        }

        return {
          ...rep,
          grades,
          updatedAt: new Date().toISOString()
        };
      }
      return rep;
    }));
  };

  // Edit/Update Report Cards (Operator / Teacher Actions)
  const updateReportCard = (updatedCard: ReportCard) => {
    setReportCards(prev => prev.map(rc => rc.studentId === updatedCard.studentId ? updatedCard : rc));
    triggerOperatorActivity('usr-op1', 'update');
  };

  // Sync External Report Cards (Operator CSV Sync Action)
  const syncExternalReportCards = (importedData: any[]) => {
    let successCount = 0;
    const errors: string[] = [];

    const updatedReportCards = [...reportCards];

    importedData.forEach((row, index) => {
      const { studentName, email, package: pkg, subject, preTestScore, postTestScore, finalScore, teacherNote } = row;
      
      if (!studentName || !subject || finalScore === undefined) {
        errors.push(`Baris ${index + 1}: Data nama, mata pelajaran, atau nilai akhir kosong.`);
        return;
      }

      // Find student by name (case-insensitive) or email
      let student = students.find(s => s.name.toLowerCase() === studentName.toLowerCase() || (email && s.email.toLowerCase() === email.toLowerCase()));

      if (!student) {
        // Automatically create/register student if not exists! (comprehensive synchronization!)
        const newId = `std-${String(students.length + 1).padStart(3, '0')}`;
        student = {
          id: newId,
          name: studentName,
          email: email || `${studentName.toLowerCase().replace(/\s+/g, '')}@gmail.com`,
          package: pkg || 'Paket C',
          status: 'Aktif',
          registrationDate: new Date().toISOString().split('T')[0],
          gender: 'Laki-laki'
        };

        // Add to students list
        setStudents(prev => [student!, ...prev]);

        // Add User Account
        const newUser: User = {
          id: newId,
          name: student.name,
          email: student.email,
          role: 'SISWA',
          package: student.package,
          avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150'
        };
        setUsers(prev => [...prev, newUser]);

        // Initialize Student KPI
        const newKPI: StudentKPI = {
          studentId: newId,
          name: student.name,
          package: student.package,
          lessonsWatched: 1,
          testsCompleted: 1,
          averageScore: Number(finalScore),
          completionRate: 50
        };
        setStudentKPIs(prev => [...prev, newKPI]);

        // Create Report Card
        const newReport: ReportCard = {
          id: `rep-${String(reportCards.length + 1).padStart(3, '0')}`,
          studentId: newId,
          studentName: student.name,
          package: student.package,
          academicYear: '2025/2026 - Genap',
          grades: [
            {
              subject,
              preTestScore: preTestScore !== undefined ? Number(preTestScore) : null,
              postTestScore: postTestScore !== undefined ? Number(postTestScore) : null,
              finalScore: Number(finalScore),
              teacherNote: teacherNote || 'Sinkronisasi data eksternal.'
            }
          ],
          attendanceRate: 95,
          characterNote: 'Terdaftar otomatis via sinkronisasi.',
          status: 'Sedang Belajar',
          updatedAt: new Date().toISOString()
        };
        updatedReportCards.push(newReport);
        successCount++;
        return;
      }

      // If student exists, update or add the grade item in their report card
      let reportCard = updatedReportCards.find(rc => rc.studentId === student!.id);
      
      if (!reportCard) {
        // Create an empty one
        reportCard = {
          id: `rep-${String(updatedReportCards.length + 1).padStart(3, '0')}`,
          studentId: student.id,
          studentName: student.name,
          package: student.package,
          academicYear: '2025/2026 - Genap',
          grades: [],
          attendanceRate: 95,
          characterNote: 'Sinkronisasi data otomatis.',
          status: 'Sedang Belajar',
          updatedAt: new Date().toISOString()
        };
        updatedReportCards.push(reportCard);
      }

      const grades = [...reportCard.grades];
      const gradeIdx = grades.findIndex(g => g.subject.toLowerCase() === subject.toLowerCase());

      const newGradeItem: GradeItem = {
        subject,
        preTestScore: preTestScore !== undefined && preTestScore !== '' ? Number(preTestScore) : null,
        postTestScore: postTestScore !== undefined && postTestScore !== '' ? Number(postTestScore) : null,
        finalScore: Number(finalScore),
        teacherNote: teacherNote || 'Sinkronisasi file eksternal.'
      };

      if (gradeIdx !== -1) {
        grades[gradeIdx] = newGradeItem;
      } else {
        grades.push(newGradeItem);
      }

      reportCard.grades = grades;
      reportCard.updatedAt = new Date().toISOString();
      successCount++;
    });

    setReportCards(updatedReportCards);
    triggerOperatorActivity('usr-op1', 'sync');

    return { successCount, errors };
  };

  // Helper to boost Operator metrics when they perform operations
  const triggerOperatorActivity = (operatorId: string, activityType: 'sync' | 'update' | 'approve') => {
    setOperatorKPIs(prev => prev.map(kpi => {
      if (kpi.operatorId === operatorId) {
        return {
          ...kpi,
          syncsProcessed: activityType === 'sync' ? kpi.syncsProcessed + 1 : kpi.syncsProcessed,
          registrationsApproved: activityType === 'approve' ? kpi.registrationsApproved + 1 : kpi.registrationsApproved,
          dataUpdatesCount: kpi.dataUpdatesCount + 1,
          systemAccuracy: Math.min(100, kpi.systemAccuracy + 0.02),
          kpiRating: Math.min(5, kpi.kpiRating + 0.02)
        };
      }
      return kpi;
    }));
  };

  const saveStudentGoal = (goal: Omit<StudentGoal, 'id' | 'createdAt'>) => {
    const newGoal: StudentGoal = {
      ...goal,
      id: `goal-${Date.now()}`,
      createdAt: new Date().toISOString().split('T')[0]
    };
    setStudentGoals(prev => {
      const filtered = prev.filter(g => g.studentId !== goal.studentId);
      return [...filtered, newGoal];
    });
  };

  const addVocationalProject = (project: Omit<VocationalProject, 'id' | 'createdAt' | 'status'>) => {
    const newProject: VocationalProject = {
      ...project,
      id: `prj-${Date.now()}`,
      status: 'Terpublikasi',
      coherenceScore: Math.floor(Math.random() * 15) + 85, // 85-99
      createdAt: new Date().toISOString().split('T')[0]
    };
    setVocationalProjects(prev => [newProject, ...prev]);
  };

  return (
    <AppContext.Provider value={{
      currentUser, users, students, lessons, tests, attempts, reportCards,
      teacherKPIs, operatorKPIs, studentKPIs,
      studentGoals, vocationalProjects, verpalItems,
      login, logout, setCurrentUserRole,
      addStudent, approveStudent, rejectStudent,
      addLesson, addTest, submitTestAttempt,
      updateReportCard, syncExternalReportCards,
      triggerOperatorActivity,
      saveStudentGoal, addVocationalProject
    }}>
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
