import React, { useState, useRef, useEffect } from 'react';
import { 
  Video, Mic, MicOff, Camera, RefreshCw, Play, Pause, Square, Download, 
  Sparkles, Sliders, Image as ImageIcon, Upload, Check, AlertCircle, 
  Zap, Volume2, Type, ChevronRight, ChevronLeft, Eye, ShieldCheck, Heart, Radio, Monitor,
  Layers, Layout, Plus, Trash2, FileText, Maximize2, Grid, Presentation
} from 'lucide-react';
import { useApp } from '../context/AppContext';

interface BackgroundPreset {
  id: string;
  name: string;
  type: 'color' | 'gradient' | 'canvas' | 'custom';
  bgStyle: string;
  iconBg: string;
}

export interface PresentationSlide {
  id: string;
  title: string;
  soksTag: 'HOMEOSTASIS' | 'DATA CORE' | 'EMPATI' | 'REFLEKSI';
  imageUrl?: string;
  summary: string;
  bulletPoints: string[];
}

export type LayoutMode = 'FULL_CAMERA' | 'PIP' | 'SPLIT' | 'OVERLAY';

export const StudioVideoGuru: React.FC = () => {
  const { currentUser } = useApp();

  // Active Side Panel tab
  const [activeSideTab, setActiveSideTab] = useState<'TELEPROMPTER' | 'PRESENTATION' | 'AI_SCRIPT'>('PRESENTATION');

  // Webcam & Canvas state
  const [cameraActive, setCameraActive] = useState(false);
  const [useSimulatedAvatar, setUseSimulatedAvatar] = useState(false);
  const [micActive, setMicActive] = useState(true);
  const [cameraError, setCameraError] = useState<string | null>(null);

  // Background Studio Engine state
  const [selectedBgPreset, setSelectedBgPreset] = useState<string>('preset-studio');
  const [customBgUrl, setCustomBgUrl] = useState<string | null>(null);
  const [bgBlurLevel, setBgBlurLevel] = useState<number>(0); // 0 to 10
  const [chromaFilter, setChromaFilter] = useState<boolean>(false);

  // Layout Mode state (Flex Layout Composition)
  const [layoutMode, setLayoutMode] = useState<LayoutMode>('PIP');

  // Presentation Slide Deck State
  const [slideDeck, setSlideDeck] = useState<PresentationSlide[]>([
    {
      id: 'slide-1',
      title: 'Orientasi & Penenangan Batin (Homeostasis)',
      soksTag: 'HOMEOSTASIS',
      summary: 'Membangun kesadaran awal & kesiapan mental warga belajar Paket C.',
      bulletPoints: [
        'Menurunkan kecemasan materi (E -> 0)',
        'Pengenalan topik: Pengelolaan Sampah & Ekonomi Sirkular',
        'Menciptakan ruang belajar kondusif & inklusif'
      ]
    },
    {
      id: 'slide-2',
      title: 'Prinsip 3R & Pengolahan Sampah Terpadu',
      soksTag: 'DATA CORE',
      summary: 'Data & Sains Akurat (40% Komposisi S.O.K.S)',
      bulletPoints: [
        'Reduce: Pengurangan sampah plastik sekali pakai',
        'Reuse: Pemanfaatan ulang wadah daur ulang',
        'Recycle: Konversi ke pupuk komposting & produk bernilai tinggi'
      ]
    },
    {
      id: 'slide-3',
      title: 'Dampak Sosial & Nilai Ekonomi Bagi Warga',
      soksTag: 'EMPATI',
      summary: 'Narasi Empati & Analogi Kehidupan Sehari-hari (30%)',
      bulletPoints: [
        'Peluang pendapatan tambahan Bank Sampah RT/RW',
        'Lingkungan bersih & bebas genangan penyakit',
        'Penguatan kebersamaan warga komunitas PKBM'
      ]
    },
    {
      id: 'slide-4',
      title: 'Rencana Aksi Mandiri Warga Belajar',
      soksTag: 'REFLEKSI',
      summary: 'Pertanyaan Pemicu Kesadaran Kritis (20%)',
      bulletPoints: [
        'Apa 1 jenis sampah rumah tangga yang siap Anda pilah hari ini?',
        'Langkah sederhana mewujudkan komposter mandiri',
        'Komitmen aksi lingkungan BSC EduSetara'
      ]
    }
  ]);
  const [currentSlideIndex, setCurrentSlideIndex] = useState<number>(0);

  // Lower-Third & Branding state
  const [showLowerThird, setShowLowerThird] = useState(true);
  const [teacherName, setTeacherName] = useState(currentUser?.name || 'Drs. Ahmad Fauzi, M.Pd.');
  const [subjectTitle, setSubjectTitle] = useState('Pendidikan Kewarganegaraan');
  const [pkgLevel, setPkgLevel] = useState<'Paket A' | 'Paket B' | 'Paket C'>('Paket C');
  const [runningText, setRunningText] = useState('BSC EDUSETARA • MODUL VIDEO LESSONS S.O.K.S MKL RESO-ENGINE');

  // Recording State
  const [isRecording, setIsRecording] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [recordSeconds, setRecordSeconds] = useState(0);
  const [recordedChunks, setRecordedChunks] = useState<Blob[]>([]);
  const [recordedVideoUrl, setRecordedVideoUrl] = useState<string | null>(null);
  const [resonanceScore, setResonanceScore] = useState<number>(9.98);

  // Teleprompter state
  const [teleprompterText, setTeleprompterText] = useState<string>(`[HOOK/HOMEOSTASIS]
Assalamu'alaikum dan semangat pagi rekan-rekan warga belajar Paket C BSC EduSetara! [Jeda Napas λ]
Tenangkan pikiran sejenak, tarik napas perlahan... Pembelajaran hari ini akan berjalan santai, menyenangkan, dan sangat relevan dengan kehidupan kita sehari-hari.

[MOTIVASI]
Memahami topik ini akan memberi Anda wawasan praktis yang sangat berguna untuk karier, pekerjaan, dan pemahaman organisasi modern. [Tekanan Vokal μ]

[DATA]
Secara akademis, Ekosistem adalah tatanan kesatuan secara utuh dan menyeluruh antara segenap unsur lingkungan hidup yang saling mempengaruhi. Ada dua komponen utama: Biotik (makhluk hidup) dan Abiotik (benda tak hidup). [Ketegasan Logic τ]

[EMPATI]
Bayangkan seperti pasar tradisional di lingkungan rumah tempat kita belanja setiap pagi. Pedagang, pembeli, produk, dan tempatnya saling melengkapi. Jika salah satu lenyap, keseimbangan aktivitas warga pasti akan terganggu. [Jeda Napas λ]

[REFLEKSI]
Sekarang, coba amati lingkungan tempat tinggal atau tempat kerja Anda sendiri. Apa satu contoh interaksi positif antara komponen hidup dan lingkungan sekitar yang paling Anda rasakan manfaatnya?`);

  const [isScrolling, setIsScrolling] = useState(false);
  const [scrollSpeed, setScrollSpeed] = useState<number>(2); // 1-5 speed
  const [fontSize, setFontSize] = useState<'sm' | 'md' | 'lg' | 'xl'>('lg');

  // AI Script Assistant Form
  const [scriptSubject, setScriptSubject] = useState('IPAS / Sains Terpadu');
  const [scriptLevel, setScriptLevel] = useState<'Paket A' | 'Paket B' | 'Paket C'>('Paket C');
  const [scriptTopic, setScriptTopic] = useState('Daur Ulang Sampah & Ekonomi Sirkular Warga');
  const [scriptDuration, setScriptDuration] = useState<number>(3);
  const [isGeneratingScript, setIsGeneratingScript] = useState(false);

  // Refs for media & canvas
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const recordTimerRef = useRef<any>(null);
  const teleprompterRef = useRef<HTMLDivElement | null>(null);
  const animFrameRef = useRef<number | null>(null);

  // Background presets list
  const bgPresets: BackgroundPreset[] = [
    { id: 'preset-studio', name: 'Studio Virtual S.O.K.S', type: 'gradient', bgStyle: 'from-slate-900 via-indigo-950 to-slate-900', iconBg: 'bg-indigo-900' },
    { id: 'preset-class', name: 'Ruang Kelas Modern', type: 'gradient', bgStyle: 'from-blue-900 via-slate-900 to-indigo-900', iconBg: 'bg-blue-900' },
    { id: 'preset-vokasi', name: 'Vokasi & Alam (Pertanian)', type: 'gradient', bgStyle: 'from-emerald-950 via-slate-900 to-teal-950', iconBg: 'bg-emerald-900' },
    { id: 'preset-blackboard', name: 'Papan Tulis Digital Neon', type: 'gradient', bgStyle: 'from-slate-950 via-cyan-950 to-slate-950', iconBg: 'bg-cyan-950' },
    { id: 'preset-warm', name: 'Warm Studio Ambient', type: 'gradient', bgStyle: 'from-amber-950 via-slate-900 to-stone-900', iconBg: 'bg-amber-900' },
  ];

  // Start webcam
  const startCamera = async () => {
    try {
      setCameraError(null);
      setUseSimulatedAvatar(false);

      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        throw new Error("Browser atau lingkungan iframe ini belum mendukung akses langsung perangkat media.");
      }

      const stream = await navigator.mediaDevices.getUserMedia({ 
        video: { width: { ideal: 1280 }, height: { ideal: 720 } }, 
        audio: micActive 
      });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.onloadedmetadata = () => {
          if (videoRef.current) {
            videoRef.current.play().catch((playErr) => {
              console.warn("Video play request interrupted or handled gracefully:", playErr);
            });
          }
        };
      }
      setCameraActive(true);
    } catch (err: any) {
      console.error("Camera access error:", err);
      setCameraActive(false);
      
      if (err.name === 'NotAllowedError' || err.message?.includes('Permission denied') || err.name === 'PermissionDeniedError') {
        setCameraError("Izin kamera ditolak oleh browser/iframe. Anda dapat menggunakan 'Mode Virtual Presenter Studio (Avatar AI)' untuk melakukan simulasi perekaman video secara penuh tanpa kamera fisik.");
      } else {
        setCameraError(`Gagal mengakses kamera: ${err.message || 'Perangkat kamera tidak ditemukan.'}`);
      }
    }
  };

  // Enable Avatar Virtual Presenter Simulation Mode
  const enableSimulatedAvatar = () => {
    stopCamera();
    setCameraError(null);
    setUseSimulatedAvatar(true);
    setCameraActive(true);
  };

  // Stop webcam
  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
    setCameraActive(false);
    setUseSimulatedAvatar(false);
  };

  // Helper to draw camera feed or virtual avatar in a specific bounding box
  const drawCameraFeed = (
    ctx: CanvasRenderingContext2D, 
    video: HTMLVideoElement | null, 
    x: number, 
    y: number, 
    w: number, 
    h: number,
    borderRadius: number = 0
  ) => {
    ctx.save();

    if (borderRadius > 0) {
      ctx.beginPath();
      ctx.roundRect(x, y, w, h, borderRadius);
      ctx.clip();
    }

    if (cameraActive && !useSimulatedAvatar && video && video.readyState >= 2) {
      ctx.filter = chromaFilter ? 'contrast(1.1) saturate(1.15)' : 'none';
      const aspect = video.videoWidth / video.videoHeight;
      let drawW = w;
      let drawH = w / aspect;

      if (drawH < h) {
        drawH = h;
        drawW = h * aspect;
      }

      const drawX = x + (w - drawW) / 2;
      const drawY = y + (h - drawH) / 2;

      ctx.drawImage(video, drawX, drawY, drawW, drawH);
      ctx.filter = 'none';
    } else if (cameraActive && useSimulatedAvatar) {
      // Draw Avatar
      ctx.filter = 'none';
      const cx = x + w / 2;
      const cy = y + h / 2 + (h * 0.1);
      const time = Date.now() * 0.003;
      const floatY = Math.sin(time) * 4;

      // Aura
      const grad = ctx.createRadialGradient(cx, cy, 20, cx, cy, w * 0.5);
      grad.addColorStop(0, 'rgba(99, 102, 241, 0.4)');
      grad.addColorStop(1, 'rgba(15, 23, 42, 0.8)');
      ctx.fillStyle = grad;
      ctx.fillRect(x, y, w, h);

      // Shoulders
      ctx.fillStyle = '#1e1b4b';
      ctx.beginPath();
      ctx.ellipse(cx, y + h - (h * 0.15) + floatY, w * 0.35, h * 0.28, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = '#6366f1';
      ctx.lineWidth = 2;
      ctx.stroke();

      // Head
      ctx.fillStyle = '#312e81';
      ctx.beginPath();
      ctx.arc(cx, cy - (h * 0.22) + floatY, w * 0.18, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = '#818cf8';
      ctx.lineWidth = 2;
      ctx.stroke();

      // Headset Band
      ctx.strokeStyle = '#f59e0b';
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.arc(cx, cy - (h * 0.23) + floatY, w * 0.2, Math.PI * 1.1, Math.PI * 1.9);
      ctx.stroke();

      // Teacher Name Badge
      ctx.fillStyle = '#ffffff';
      ctx.font = `bold ${Math.max(10, Math.floor(w * 0.04))}px sans-serif`;
      ctx.textAlign = 'center';
      ctx.fillText(teacherName, cx, cy - (h * 0.2) + floatY);

      // Audio Wave Animation
      ctx.strokeStyle = '#34d399';
      ctx.lineWidth = 2;
      for (let i = -2; i <= 2; i++) {
        const waveH = 8 + Math.sin(time * 5 + i * 0.8) * 8;
        ctx.beginPath();
        ctx.moveTo(cx + i * 10, cy + (h * 0.05) + floatY - waveH / 2);
        ctx.lineTo(cx + i * 10, cy + (h * 0.05) + floatY + waveH / 2);
        ctx.stroke();
      }
    } else {
      // Inactive Standby
      ctx.fillStyle = '#0f172a';
      ctx.fillRect(x, y, w, h);
      ctx.fillStyle = '#94a3b8';
      ctx.font = `bold ${Math.max(11, Math.floor(w * 0.035))}px sans-serif`;
      ctx.textAlign = 'center';
      ctx.fillText('STANDBY STUDIO', x + w / 2, y + h / 2);
    }

    ctx.restore();
  };

  // Helper to draw slide card on canvas
  const drawSlideOnCanvas = (
    ctx: CanvasRenderingContext2D,
    slide: PresentationSlide,
    x: number,
    y: number,
    w: number,
    h: number,
    compact: boolean = false
  ) => {
    ctx.save();

    // Card Glassmorphic Background
    ctx.fillStyle = 'rgba(15, 23, 42, 0.94)';
    ctx.strokeStyle = '#3b82f6';
    ctx.lineWidth = 2;

    ctx.beginPath();
    ctx.roundRect(x, y, w, h, 16);
    ctx.fill();
    ctx.stroke();

    // Tag Color
    let tagBg = '#8b5cf6';
    let tagText = 'S.O.K.S ORIENTASI';
    if (slide.soksTag === 'DATA CORE') { tagBg = '#f59e0b'; tagText = 'DATA CORE 40%'; }
    else if (slide.soksTag === 'EMPATI') { tagBg = '#06b6d4'; tagText = 'EMPATI 30%'; }
    else if (slide.soksTag === 'REFLEKSI') { tagBg = '#10b981'; tagText = 'REFLEKSI 20%'; }

    // Tag Badge
    ctx.fillStyle = tagBg;
    ctx.beginPath();
    ctx.roundRect(x + 20, y + 20, compact ? 130 : 170, 28, 6);
    ctx.fill();

    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 11px sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText(tagText, x + 20 + (compact ? 65 : 85), y + 38);

    // Slide Image (If Custom Image Uploaded)
    if (slide.imageUrl) {
      const slideImg = new Image();
      slideImg.src = slide.imageUrl;
      if (slideImg.complete && slideImg.naturalWidth > 0) {
        ctx.drawImage(slideImg, x + 20, y + 60, w - 40, h - 80);
        ctx.restore();
        return;
      }
    }

    // Title
    ctx.textAlign = 'left';
    ctx.fillStyle = '#f8fafc';
    ctx.font = compact ? 'bold 15px sans-serif' : 'bold 22px sans-serif';
    const titleText = slide.title.length > 36 ? slide.title.substring(0, 33) + '...' : slide.title;
    ctx.fillText(titleText, x + 20, y + (compact ? 72 : 82));

    // Summary
    ctx.fillStyle = '#94a3b8';
    ctx.font = compact ? '12px sans-serif' : '14px sans-serif';
    ctx.fillText(slide.summary, x + 20, y + (compact ? 96 : 112));

    // Divider
    ctx.strokeStyle = '#334155';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(x + 20, y + (compact ? 108 : 128));
    ctx.lineTo(x + w - 20, y + (compact ? 108 : 128));
    ctx.stroke();

    // Bullet Points
    const startY = compact ? 128 : 160;
    const lineSpacing = compact ? 22 : 32;

    slide.bulletPoints.slice(0, compact ? 3 : 4).forEach((bullet, idx) => {
      // Bullet Dot
      ctx.fillStyle = tagBg;
      ctx.beginPath();
      ctx.arc(x + 28, startY + idx * lineSpacing - 4, 4, 0, Math.PI * 2);
      ctx.fill();

      // Bullet Text
      ctx.fillStyle = '#e2e8f0';
      ctx.font = compact ? '12px sans-serif' : '15px sans-serif';
      const cleanBullet = bullet.length > 42 ? bullet.substring(0, 39) + '...' : bullet;
      ctx.fillText(cleanBullet, x + 42, startY + idx * lineSpacing);
    });

    ctx.restore();
  };

  // Canvas composite drawing loop
  useEffect(() => {
    let active = true;

    const renderCanvas = () => {
      if (!active) return;
      const canvas = canvasRef.current;
      const video = videoRef.current;

      if (canvas) {
        const ctx = canvas.getContext('2d');
        if (ctx) {
          const width = canvas.width;
          const height = canvas.height;

          // 1. Draw Studio Background
          if (customBgUrl) {
            const img = new Image();
            img.src = customBgUrl;
            if (img.complete && img.naturalWidth !== 0) {
              ctx.drawImage(img, 0, 0, width, height);
            } else {
              drawPresetBackground(ctx, width, height);
            }
          } else {
            drawPresetBackground(ctx, width, height);
          }

          if (bgBlurLevel > 0) {
            ctx.filter = `blur(${bgBlurLevel}px)`;
          }

          const currentSlide = slideDeck[currentSlideIndex] || slideDeck[0];

          // 2. Draw According to Flex Layout Mode
          if (layoutMode === 'FULL_CAMERA') {
            // Full Camera Mode
            drawCameraFeed(ctx, video, 0, 0, width, height, 0);
          } else if (layoutMode === 'PIP') {
            // Picture-in-Picture: Slide as Main Stage, Camera in Corner Inset
            drawSlideOnCanvas(ctx, currentSlide, 30, 30, width - 60, height - 160, false);

            // PIP Box in Bottom-Right
            const pipW = 340;
            const pipH = 200;
            const pipX = width - pipW - 35;
            const pipY = height - pipH - 140;

            // PIP Glow & Border
            ctx.fillStyle = '#0f172a';
            ctx.shadowColor = '#6366f1';
            ctx.shadowBlur = 15;
            ctx.beginPath();
            ctx.roundRect(pipX - 3, pipY - 3, pipW + 6, pipH + 6, 16);
            ctx.fill();
            ctx.shadowBlur = 0;

            drawCameraFeed(ctx, video, pipX, pipY, pipW, pipH, 14);

            // PIP Border Line
            ctx.strokeStyle = '#f59e0b';
            ctx.lineWidth = 3;
            ctx.beginPath();
            ctx.roundRect(pipX, pipY, pipW, pipH, 14);
            ctx.stroke();
          } else if (layoutMode === 'SPLIT') {
            // Split Screen (50:50)
            const splitW = width / 2 - 30;
            const splitH = height - 150;

            // Left: Camera
            drawCameraFeed(ctx, video, 20, 25, splitW, splitH, 16);

            // Right: Presentation Slide
            drawSlideOnCanvas(ctx, currentSlide, width / 2 + 10, 25, splitW, splitH, false);
          } else if (layoutMode === 'OVERLAY') {
            // Camera Full Background + Floating Slide Card
            drawCameraFeed(ctx, video, 0, 0, width, height, 0);

            // Floating Slide Card at Top-Right
            const ovW = 510;
            const ovH = 340;
            const ovX = width - ovW - 30;
            const ovY = 30;

            drawSlideOnCanvas(ctx, currentSlide, ovX, ovY, ovW, ovH, true);
          }

          // 3. Draw Studio Branding / Lower Third Overlay
          if (showLowerThird) {
            const ltY = height - 110;
            ctx.fillStyle = 'rgba(15, 23, 42, 0.90)';
            ctx.fillRect(30, ltY, 480, 75);

            // Left Accent Bar
            ctx.fillStyle = '#f59e0b';
            ctx.fillRect(30, ltY, 8, 75);

            // Teacher Name
            ctx.textAlign = 'left';
            ctx.fillStyle = '#ffffff';
            ctx.font = 'bold 19px sans-serif';
            ctx.fillText(teacherName, 52, ltY + 30);

            // Subject & Jenjang
            ctx.fillStyle = '#38bdf8';
            ctx.font = 'bold 13px sans-serif';
            ctx.fillText(`${subjectTitle} • ${pkgLevel}`, 52, ltY + 54);

            // Active S.O.K.S Tag Badge on Top Right
            ctx.fillStyle = 'rgba(79, 70, 229, 0.88)';
            ctx.fillRect(width - 240, 25, 215, 36);
            ctx.fillStyle = '#ffffff';
            ctx.font = 'bold 12px sans-serif';
            ctx.fillText(`S.O.K.S: ${currentSlide.soksTag}`, width - 225, 48);

            // Running Text Bar at Bottom
            ctx.fillStyle = '#020617';
            ctx.fillRect(0, height - 28, width, 28);
            ctx.fillStyle = '#cbd5e1';
            ctx.font = 'bold 11px monospace';
            ctx.fillText(runningText, 15, height - 10);
          }
        }
      }

      animFrameRef.current = requestAnimationFrame(renderCanvas);
    };

    renderCanvas();

    return () => {
      active = false;
      if (animFrameRef.current) cancelAnimationFrame(animFrameRef.current);
    };
  }, [cameraActive, useSimulatedAvatar, selectedBgPreset, customBgUrl, bgBlurLevel, chromaFilter, showLowerThird, teacherName, subjectTitle, pkgLevel, runningText, layoutMode, slideDeck, currentSlideIndex]);

  // Helper to draw preset background on canvas
  const drawPresetBackground = (ctx: CanvasRenderingContext2D, width: number, height: number) => {
    const preset = bgPresets.find(p => p.id === selectedBgPreset) || bgPresets[0];
    
    let grad: CanvasGradient;
    if (preset.id === 'preset-vokasi') {
      grad = ctx.createLinearGradient(0, 0, width, height);
      grad.addColorStop(0, '#022c22');
      grad.addColorStop(0.5, '#0f172a');
      grad.addColorStop(1, '#064e3b');
    } else if (preset.id === 'preset-blackboard') {
      grad = ctx.createLinearGradient(0, 0, 0, height);
      grad.addColorStop(0, '#030712');
      grad.addColorStop(1, '#083344');
    } else if (preset.id === 'preset-warm') {
      grad = ctx.createLinearGradient(0, 0, width, height);
      grad.addColorStop(0, '#451a03');
      grad.addColorStop(0.6, '#0f172a');
      grad.addColorStop(1, '#1c1917');
    } else if (preset.id === 'preset-class') {
      grad = ctx.createLinearGradient(0, 0, width, height);
      grad.addColorStop(0, '#1e3a8a');
      grad.addColorStop(0.5, '#0f172a');
      grad.addColorStop(1, '#312e81');
    } else {
      // Default Studio Virtual
      grad = ctx.createLinearGradient(0, 0, width, height);
      grad.addColorStop(0, '#0f172a');
      grad.addColorStop(0.5, '#1e1b4b');
      grad.addColorStop(1, '#020617');
    }

    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, width, height);
  };

  // Recording controls
  const startRecording = () => {
    if (!canvasRef.current) return;

    try {
      setRecordedChunks([]);
      setRecordedVideoUrl(null);
      setRecordSeconds(0);

      const canvasStream = canvasRef.current.captureStream(30);

      if (streamRef.current && streamRef.current.getAudioTracks().length > 0) {
        const audioTrack = streamRef.current.getAudioTracks()[0];
        canvasStream.addTrack(audioTrack);
      }

      const options = { mimeType: 'video/webm;codecs=vp8,opus' };
      const mediaRecorder = new MediaRecorder(canvasStream, options);

      mediaRecorder.ondataavailable = (event) => {
        if (event.data && event.data.size > 0) {
          setRecordedChunks((prev) => [...prev, event.data]);
        }
      };

      mediaRecorder.onstop = () => {
        clearInterval(recordTimerRef.current);
      };

      mediaRecorderRef.current = mediaRecorder;
      mediaRecorder.start(1000);
      setIsRecording(true);
      setIsPaused(false);

      recordTimerRef.current = setInterval(() => {
        setRecordSeconds((prev) => prev + 1);
      }, 1000);

      setIsScrolling(true);
    } catch (err: any) {
      console.error("Recording error:", err);
      alert("Gagal memulai perekaman video: " + err.message);
    }
  };

  const pauseRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      if (isPaused) {
        mediaRecorderRef.current.resume();
        setIsPaused(false);
        recordTimerRef.current = setInterval(() => {
          setRecordSeconds((prev) => prev + 1);
        }, 1000);
      } else {
        mediaRecorderRef.current.pause();
        setIsPaused(true);
        clearInterval(recordTimerRef.current);
      }
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
      setIsPaused(false);
      clearInterval(recordTimerRef.current);
      setIsScrolling(false);
    }
  };

  // Compile WebM / MP4 video link
  useEffect(() => {
    if (!isRecording && recordedChunks.length > 0) {
      const blob = new Blob(recordedChunks, { type: 'video/webm' });
      const url = URL.createObjectURL(blob);
      setRecordedVideoUrl(url);
    }
  }, [isRecording, recordedChunks]);

  // Teleprompter Auto-scroll Loop
  useEffect(() => {
    let scrollTimer: any = null;

    if (isScrolling && teleprompterRef.current) {
      scrollTimer = setInterval(() => {
        if (teleprompterRef.current) {
          teleprompterRef.current.scrollTop += scrollSpeed * 1.5;
        }
      }, 50);
    }

    return () => {
      if (scrollTimer) clearInterval(scrollTimer);
    };
  }, [isScrolling, scrollSpeed]);

  // Handle custom background image upload
  const handleCustomBgUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const url = URL.createObjectURL(file);
      setCustomBgUrl(url);
      setSelectedBgPreset('custom');
    }
  };

  // Handle Presentation Slide Upload (PPT / PDF / Images)
  const handleSlideUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    const newUploadedSlides: PresentationSlide[] = [];

    (Array.from(files) as File[]).forEach((file, index) => {
      const imageUrl = URL.createObjectURL(file);
      const soksTags: ('HOMEOSTASIS' | 'DATA CORE' | 'EMPATI' | 'REFLEKSI')[] = [
        'HOMEOSTASIS', 'DATA CORE', 'EMPATI', 'REFLEKSI'
      ];
      const tag = soksTags[index % soksTags.length];

      newUploadedSlides.push({
        id: `slide-upload-${Date.now()}-${index}`,
        title: file.name.replace(/\.[^/.]+$/, ""),
        soksTag: tag,
        imageUrl,
        summary: `Materi Visual Slide #${index + 1} (${file.name})`,
        bulletPoints: [
          `Berkas: ${file.name}`,
          `Kategori S.O.K.S: ${tag}`,
          'Siap ditampilkan di panggung studio video'
        ]
      });
    });

    setSlideDeck((prev) => [...prev, ...newUploadedSlides]);
    setCurrentSlideIndex(slideDeck.length);
  };

  // Generate Script via AI API
  const handleGenerateScript = async () => {
    if (!scriptTopic.trim()) return;
    setIsGeneratingScript(true);

    try {
      const res = await fetch('/api/guru/generate-video-script', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          subject: scriptSubject,
          level: scriptLevel,
          topic: scriptTopic,
          durationMinutes: scriptDuration
        })
      });

      if (!res.ok) throw new Error("Gagal menghasilkan skrip video");
      const data = await res.json();
      setTeleprompterText(data.text || '');
      setActiveSideTab('TELEPROMPTER');
    } catch (err: any) {
      alert("Error: " + err.message);
    } finally {
      setIsGeneratingScript(false);
    }
  };

  // Format record time (MM:SS)
  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  // Helper to parse and highlight teleprompter tags
  const renderFormattedTeleprompter = (rawText: string) => {
    const lines = rawText.split('\n');

    return lines.map((line, idx) => {
      if (line.includes('[HOOK/HOMEOSTASIS]')) {
        return (
          <div key={idx} className="my-3 p-3 bg-purple-950/80 border-l-4 border-purple-500 rounded-r-xl">
            <span className="text-[10px] font-black tracking-widest text-purple-300 uppercase block mb-1">
              [HOOK / HOMEOSTASIS] • Meredakan Kecemasan Siswa
            </span>
            <p className="text-purple-100 font-medium">{line.replace('[HOOK/HOMEOSTASIS]', '')}</p>
          </div>
        );
      }

      if (line.includes('[MOTIVASI]')) {
        return (
          <div key={idx} className="my-3 p-3 bg-rose-950/80 border-l-4 border-rose-500 rounded-r-xl">
            <span className="text-[10px] font-black tracking-widest text-rose-300 uppercase block mb-1">
              [INJEKSI MOTIVASI] • Poin Manfaat Masa Depan / Karier
            </span>
            <p className="text-rose-100 font-medium">{line.replace('[MOTIVASI]', '')}</p>
          </div>
        );
      }

      if (line.includes('[DATA]')) {
        return (
          <div key={idx} className="my-3 p-3 bg-amber-950/80 border-l-4 border-amber-500 rounded-r-xl">
            <span className="text-[10px] font-black tracking-widest text-amber-300 uppercase block mb-1">
              [DATA CORE - 40%] • Poin Fakta & Sains Akurat
            </span>
            <p className="text-amber-100 font-medium">{line.replace('[DATA]', '')}</p>
          </div>
        );
      }

      if (line.includes('[EMPATI]')) {
        return (
          <div key={idx} className="my-3 p-3 bg-cyan-950/80 border-l-4 border-cyan-500 rounded-r-xl">
            <span className="text-[10px] font-black tracking-widest text-cyan-300 uppercase block mb-1">
              [NARASI EMPATI - 30%] • Analogi Kehidupan Sehari-hari Warga
            </span>
            <p className="text-cyan-100 font-medium">{line.replace('[EMPATI]', '')}</p>
          </div>
        );
      }

      if (line.includes('[REFLEKSI]')) {
        return (
          <div key={idx} className="my-3 p-3 bg-emerald-950/80 border-l-4 border-emerald-500 rounded-r-xl">
            <span className="text-[10px] font-black tracking-widest text-emerald-300 uppercase block mb-1">
              [PERTANYAAN REFLEKTIF - 20%] • Critical Thinking Trigger
            </span>
            <p className="text-emerald-100 font-medium">{line.replace('[REFLEKSI]', '')}</p>
          </div>
        );
      }

      return (
        <p key={idx} className="my-2 leading-relaxed text-slate-200">
          {line.split(/(\[.*?\])/g).map((part, pIdx) => {
            if (part.startsWith('[') && part.endsWith(']')) {
              return (
                <span key={pIdx} className="inline-block mx-1 px-2 py-0.5 bg-indigo-900/90 text-indigo-300 font-mono text-[11px] font-bold rounded border border-indigo-700/60">
                  {part}
                </span>
              );
            }
            return part;
          })}
        </p>
      );
    });
  };

  const currentSlide = slideDeck[currentSlideIndex] || slideDeck[0];

  return (
    <div className="bg-slate-950 text-slate-100 rounded-3xl p-6 border border-slate-800 shadow-2xl space-y-6">
      {/* Broadcast Studio Header Bar */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-amber-500/20 border border-amber-500/40 rounded-2xl flex items-center justify-center text-amber-400 shrink-0">
            <Video className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-black uppercase tracking-widest text-amber-400 bg-amber-500/20 px-2.5 py-0.5 rounded-full border border-amber-500/30">
                Studio Broadcast Perekaman Video AI
              </span>
              <span className="text-[10px] font-bold text-emerald-400 bg-emerald-950/80 px-2 py-0.5 rounded-full border border-emerald-800 flex items-center gap-1">
                <Radio className="w-3 h-3 animate-pulse text-emerald-400" /> Live Reso: Φ = {resonanceScore}
              </span>
            </div>
            <h2 className="text-xl font-black text-white mt-1">Virtual Studio, Presentation Stage & Teleprompter</h2>
          </div>
        </div>

        {/* Live Camera Toggle & Mic Controls */}
        <div className="flex flex-wrap items-center gap-2">
          {!cameraActive ? (
            <>
              <button
                onClick={startCamera}
                className="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs rounded-xl transition-all cursor-pointer shadow-lg shadow-indigo-950 flex items-center gap-2"
              >
                <Camera className="w-4 h-4" />
                <span>Aktifkan Kamera Studio</span>
              </button>

              <button
                onClick={enableSimulatedAvatar}
                className="px-4 py-2.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs rounded-xl transition-all cursor-pointer shadow-lg shadow-amber-950 flex items-center gap-2"
              >
                <Sparkles className="w-4 h-4" />
                <span>Mode Virtual Presenter (Avatar AI)</span>
              </button>
            </>
          ) : (
            <div className="flex items-center gap-2">
              {useSimulatedAvatar && (
                <span className="px-3 py-1.5 bg-amber-950 border border-amber-500/50 text-amber-300 font-bold text-xs rounded-xl flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-amber-400" /> Mode Virtual Presenter Aktif
                </span>
              )}
              <button
                onClick={stopCamera}
                className="px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-rose-400 font-bold text-xs rounded-xl transition-all cursor-pointer border border-slate-700 flex items-center gap-2"
              >
                <Camera className="w-4 h-4" />
                <span>Matikan Kamera / Avatar</span>
              </button>
            </div>
          )}

          <button
            onClick={() => setMicActive(!micActive)}
            className={`p-2.5 rounded-xl border transition-all cursor-pointer ${
              micActive ? 'bg-slate-800 text-slate-200 border-slate-700' : 'bg-rose-950 text-rose-400 border-rose-800'
            }`}
            title={micActive ? 'Mikrofon Aktif' : 'Mikrofon Muted'}
          >
            {micActive ? <Mic className="w-4 h-4" /> : <MicOff className="w-4 h-4" />}
          </button>
        </div>
      </div>

      {cameraError && (
        <div className="p-4 bg-rose-950/90 border border-rose-800 rounded-2xl text-xs text-rose-200 space-y-2 shadow-xl">
          <div className="flex items-start gap-2">
            <AlertCircle className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
            <div>
              <strong className="block font-bold text-rose-300 mb-0.5">Akses Kamera Ditolak / Dibatasi Frame Browser</strong>
              <p className="leading-relaxed">{cameraError}</p>
            </div>
          </div>
          <div className="flex flex-wrap items-center gap-2 pt-1">
            <button
              onClick={enableSimulatedAvatar}
              className="px-3.5 py-1.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs rounded-lg cursor-pointer transition-all flex items-center gap-1.5 shadow"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>Gunakan Mode Virtual Presenter (Avatar Studio)</span>
            </button>
            <button
              onClick={() => window.open(window.location.href, '_blank')}
              className="px-3.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs rounded-lg cursor-pointer transition-all flex items-center gap-1.5 border border-slate-700"
            >
              <Monitor className="w-3.5 h-3.5" />
              <span>Buka di Tab Baru (Izinkan Kamera)</span>
            </button>
            <button
              onClick={startCamera}
              className="px-3 py-1.5 bg-slate-900 hover:bg-slate-800 text-slate-300 font-bold text-xs rounded-lg cursor-pointer transition-all border border-slate-800"
            >
              Coba Minta Izin Lagi
            </button>
          </div>
        </div>
      )}

      {/* Hidden Video element for WebCam capture */}
      <video ref={videoRef} className="hidden" playsInline muted />

      {/* Main 2-Panel Broadcast Stage */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* LEFT PANEL: Canvas Video Stage & Layout Controls (7 Cols) */}
        <div className="lg:col-span-7 space-y-4">
          
          {/* Main Canvas Screen */}
          <div className="relative bg-slate-900 rounded-2xl overflow-hidden border border-slate-800 shadow-2xl aspect-video flex items-center justify-center">
            
            {/* Canvas Renderer */}
            <canvas
              ref={canvasRef}
              width={1280}
              height={720}
              className="w-full h-full object-contain bg-slate-950"
            />

            {/* Recording Indicator Overlay */}
            {isRecording && (
              <div className="absolute top-4 left-4 bg-slate-950/90 border border-rose-500/50 backdrop-blur-md px-3 py-1.5 rounded-full flex items-center gap-2 text-xs font-mono font-bold text-white shadow-xl">
                <span className="w-2.5 h-2.5 rounded-full bg-rose-500 animate-ping" />
                <span className="text-rose-400">REC</span>
                <span className="text-slate-300">{formatTime(recordSeconds)}</span>
              </div>
            )}

            {/* Active Layout Badge */}
            <div className="absolute top-4 right-4 bg-slate-950/90 border border-indigo-500/40 backdrop-blur-md px-3 py-1.5 rounded-full flex items-center gap-2 text-[11px] font-bold text-indigo-300">
              <Layout className="w-3.5 h-3.5 text-amber-400" />
              <span>Layout: {layoutMode}</span>
            </div>
          </div>

          {/* Flex Layout Composition Selection Bar */}
          <div className="bg-slate-900 p-3.5 rounded-2xl border border-slate-800 space-y-2">
            <span className="text-[10px] font-black uppercase text-indigo-400 tracking-wider block">
              Pilihan Tampilan Layar Video (Flex Layout Composition):
            </span>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              <button
                onClick={() => setLayoutMode('FULL_CAMERA')}
                className={`p-2.5 rounded-xl border text-left transition-all cursor-pointer flex items-center gap-2 ${
                  layoutMode === 'FULL_CAMERA' 
                    ? 'bg-indigo-950 border-indigo-500 text-white shadow' 
                    : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:border-slate-700'
                }`}
              >
                <Camera className="w-4 h-4 text-indigo-400 shrink-0" />
                <div>
                  <strong className="block text-xs font-bold">Full Kamera</strong>
                  <span className="text-[9px] text-slate-400">Pengajar Penuh</span>
                </div>
              </button>

              <button
                onClick={() => setLayoutMode('PIP')}
                className={`p-2.5 rounded-xl border text-left transition-all cursor-pointer flex items-center gap-2 ${
                  layoutMode === 'PIP' 
                    ? 'bg-indigo-950 border-indigo-500 text-white shadow' 
                    : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:border-slate-700'
                }`}
              >
                <Layers className="w-4 h-4 text-amber-400 shrink-0" />
                <div>
                  <strong className="block text-xs font-bold">PiP Mode</strong>
                  <span className="text-[9px] text-slate-400">Slide + Kamera Inset</span>
                </div>
              </button>

              <button
                onClick={() => setLayoutMode('SPLIT')}
                className={`p-2.5 rounded-xl border text-left transition-all cursor-pointer flex items-center gap-2 ${
                  layoutMode === 'SPLIT' 
                    ? 'bg-indigo-950 border-indigo-500 text-white shadow' 
                    : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:border-slate-700'
                }`}
              >
                <Layout className="w-4 h-4 text-emerald-400 shrink-0" />
                <div>
                  <strong className="block text-xs font-bold">Split Screen</strong>
                  <span className="text-[9px] text-slate-400">50:50 Kamera & Slide</span>
                </div>
              </button>

              <button
                onClick={() => setLayoutMode('OVERLAY')}
                className={`p-2.5 rounded-xl border text-left transition-all cursor-pointer flex items-center gap-2 ${
                  layoutMode === 'OVERLAY' 
                    ? 'bg-indigo-950 border-indigo-500 text-white shadow' 
                    : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:border-slate-700'
                }`}
              >
                <Presentation className="w-4 h-4 text-cyan-400 shrink-0" />
                <div>
                  <strong className="block text-xs font-bold">Slide Overlay</strong>
                  <span className="text-[9px] text-slate-400">Floating Glass Card</span>
                </div>
              </button>
            </div>
          </div>

          {/* Recording Control Bar */}
          <div className="bg-slate-900 p-4 rounded-2xl border border-slate-800 flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              {!isRecording ? (
                <button
                  onClick={startRecording}
                  disabled={!cameraActive}
                  className={`px-5 py-2.5 text-xs font-black rounded-xl transition-all flex items-center gap-2 shadow-lg cursor-pointer ${
                    cameraActive 
                      ? 'bg-rose-600 hover:bg-rose-500 text-white shadow-rose-950' 
                      : 'bg-slate-800 text-slate-500 cursor-not-allowed'
                  }`}
                >
                  <span className="w-3 h-3 rounded-full bg-white animate-pulse" />
                  <span>Mulai Rekam Video</span>
                </button>
              ) : (
                <>
                  <button
                    onClick={pauseRecording}
                    className="px-4 py-2.5 bg-amber-600 hover:bg-amber-500 text-white font-black text-xs rounded-xl transition-all cursor-pointer flex items-center gap-1.5"
                  >
                    {isPaused ? <Play className="w-4 h-4" /> : <Pause className="w-4 h-4" />}
                    <span>{isPaused ? 'Lanjutkan' : 'Jeda'}</span>
                  </button>

                  <button
                    onClick={stopRecording}
                    className="px-4 py-2.5 bg-slate-800 hover:bg-rose-950 text-rose-400 border border-rose-800 font-black text-xs rounded-xl transition-all cursor-pointer flex items-center gap-1.5"
                  >
                    <Square className="w-4 h-4 fill-current" />
                    <span>Selesai & Simpan</span>
                  </button>
                </>
              )}
            </div>

            {/* Video Download Action */}
            {recordedVideoUrl && (
              <a
                href={recordedVideoUrl}
                download={`Video_Pembelajaran_SOKS_${Date.now()}.webm`}
                className="px-4 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-black text-xs rounded-xl transition-all flex items-center gap-2 shadow-md shadow-emerald-950 animate-bounce"
              >
                <Download className="w-4 h-4" />
                <span>Unduh Hasil Rekaman (MP4/WebM)</span>
              </a>
            )}
          </div>

          {/* Virtual Background & Studio Customization Controls */}
          <div className="bg-slate-900 p-5 rounded-2xl border border-slate-800 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="font-extrabold text-sm text-white flex items-center gap-2">
                <ImageIcon className="w-4 h-4 text-indigo-400" /> Custom Virtual Studio & Lower Third
              </h3>
              <label className="text-xs font-bold text-indigo-400 hover:underline cursor-pointer flex items-center gap-1">
                <Upload className="w-3.5 h-3.5" />
                <span>Unggah Latar Sendiri</span>
                <input type="file" accept="image/*" onChange={handleCustomBgUpload} className="hidden" />
              </label>
            </div>

            {/* Presets Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              {bgPresets.map((preset) => {
                const isSel = selectedBgPreset === preset.id;
                return (
                  <button
                    key={preset.id}
                    onClick={() => {
                      setSelectedBgPreset(preset.id);
                      setCustomBgUrl(null);
                    }}
                    className={`p-2.5 rounded-xl border text-left transition-all cursor-pointer flex items-center gap-2.5 ${
                      isSel ? 'bg-indigo-950 border-indigo-500 text-white shadow-md' : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:border-slate-700'
                    }`}
                  >
                    <div className={`w-6 h-6 rounded-lg ${preset.iconBg} border border-slate-700 shrink-0`} />
                    <span className="text-[11px] font-bold truncate">{preset.name}</span>
                  </button>
                );
              })}
            </div>

            {/* Lower Third Info Form Toggle */}
            <div className="pt-2 border-t border-slate-800/80 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-300">Tampilkan Lower Third / Header Branding</span>
                <input
                  type="checkbox"
                  checked={showLowerThird}
                  onChange={(e) => setShowLowerThird(e.target.checked)}
                  className="w-4 h-4 accent-indigo-500 rounded cursor-pointer"
                />
              </div>

              {showLowerThird && (
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-xs">
                  <div>
                    <label className="text-[10px] text-slate-400 block mb-1">Nama Pengajar</label>
                    <input
                      type="text"
                      value={teacherName}
                      onChange={(e) => setTeacherName(e.target.value)}
                      className="w-full p-2 bg-slate-950 border border-slate-800 rounded-lg text-white font-bold"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] text-slate-400 block mb-1">Mata Pelajaran</label>
                    <input
                      type="text"
                      value={subjectTitle}
                      onChange={(e) => setSubjectTitle(e.target.value)}
                      className="w-full p-2 bg-slate-950 border border-slate-800 rounded-lg text-white font-bold"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] text-slate-400 block mb-1">Jenjang</label>
                    <select
                      value={pkgLevel}
                      onChange={(e: any) => setPkgLevel(e.target.value)}
                      className="w-full p-2 bg-slate-950 border border-slate-800 rounded-lg text-white font-bold"
                    >
                      <option value="Paket A">Paket A (SD)</option>
                      <option value="Paket B">Paket B (SMP)</option>
                      <option value="Paket C">Paket C (SMA)</option>
                    </select>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* RIGHT PANEL: Presentation Stage, Teleprompter & AI Assistant (5 Cols) */}
        <div className="lg:col-span-5 flex flex-col space-y-4">
          
          {/* Side Tabs Header */}
          <div className="flex border-b border-slate-800 bg-slate-900 p-1 rounded-xl">
            <button
              onClick={() => setActiveSideTab('PRESENTATION')}
              className={`flex-1 py-2 text-xs font-bold rounded-lg transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
                activeSideTab === 'PRESENTATION' ? 'bg-amber-500 text-slate-950 shadow' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Presentation className="w-3.5 h-3.5" />
              <span>Slide Presentasi</span>
            </button>

            <button
              onClick={() => setActiveSideTab('TELEPROMPTER')}
              className={`flex-1 py-2 text-xs font-bold rounded-lg transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
                activeSideTab === 'TELEPROMPTER' ? 'bg-indigo-600 text-white shadow' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Type className="w-3.5 h-3.5" />
              <span>Teleprompter</span>
            </button>

            <button
              onClick={() => setActiveSideTab('AI_SCRIPT')}
              className={`flex-1 py-2 text-xs font-bold rounded-lg transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
                activeSideTab === 'AI_SCRIPT' ? 'bg-indigo-600 text-white shadow' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              <span>Skrip AI S.O.K.S</span>
            </button>
          </div>

          {/* TAB 1: PRESENTATION STAGE ENGINE */}
          {activeSideTab === 'PRESENTATION' && (
            <div className="bg-slate-900 p-5 rounded-2xl border border-slate-800 flex-1 flex flex-col justify-between space-y-4">
              
              {/* Header & Slide Navigator */}
              <div className="space-y-3 border-b border-slate-800 pb-3">
                <div className="flex items-center justify-between">
                  <div>
                    <span className="text-[10px] font-black uppercase text-amber-400 tracking-wider">
                      Modul Presentasi & Visual Stage Engine
                    </span>
                    <h3 className="font-extrabold text-sm text-white">Galeri Slide & Resonansi S.O.K.S</h3>
                  </div>

                  <label className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold rounded-xl cursor-pointer transition-all flex items-center gap-1.5 shadow">
                    <Upload className="w-3.5 h-3.5" />
                    <span>Unggah PPT/PDF/Gambar</span>
                    <input
                      type="file"
                      accept="image/*,.pdf,.ppt,.pptx"
                      multiple
                      onChange={handleSlideUpload}
                      className="hidden"
                    />
                  </label>
                </div>

                {/* Slide Nav Controls */}
                <div className="flex items-center justify-between bg-slate-950 p-2 rounded-xl border border-slate-800">
                  <button
                    onClick={() => setCurrentSlideIndex((prev) => Math.max(0, prev - 1))}
                    disabled={currentSlideIndex === 0}
                    className={`p-2 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                      currentSlideIndex === 0 ? 'text-slate-600 cursor-not-allowed' : 'bg-slate-800 text-white hover:bg-slate-700'
                    }`}
                  >
                    <ChevronLeft className="w-4 h-4" />
                  </button>

                  <div className="text-center">
                    <span className="text-xs font-black text-white">
                      Slide {currentSlideIndex + 1} dari {slideDeck.length}
                    </span>
                    <span className="block text-[10px] font-mono text-amber-400">
                      S.O.K.S Tag: [{currentSlide.soksTag}]
                    </span>
                  </div>

                  <button
                    onClick={() => setCurrentSlideIndex((prev) => Math.min(slideDeck.length - 1, prev + 1))}
                    disabled={currentSlideIndex === slideDeck.length - 1}
                    className={`p-2 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                      currentSlideIndex === slideDeck.length - 1 ? 'text-slate-600 cursor-not-allowed' : 'bg-slate-800 text-white hover:bg-slate-700'
                    }`}
                  >
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Active Slide Full Preview Box */}
              <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="px-2.5 py-0.5 bg-indigo-950 text-indigo-300 font-mono text-[10px] font-bold rounded-md border border-indigo-800">
                    S.O.K.S Stage: {currentSlide.soksTag}
                  </span>
                  <span className="text-[10px] text-slate-400">Tampil Otomatis pada Canvas Video</span>
                </div>

                <h4 className="font-extrabold text-base text-white">{currentSlide.title}</h4>
                <p className="text-xs text-slate-300">{currentSlide.summary}</p>

                <ul className="space-y-1.5 pt-1">
                  {currentSlide.bulletPoints.map((bp, bIdx) => (
                    <li key={bIdx} className="text-xs text-slate-300 flex items-center gap-2">
                      <span className="w-1.5 h-1.5 rounded-full bg-amber-400 shrink-0" />
                      <span>{bp}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Slide Thumbnails Carousel */}
              <div className="space-y-2">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
                  Daftar Slide Dalam Panggung ({slideDeck.length} Slide):
                </span>
                <div className="flex items-center gap-2 overflow-x-auto pb-2 no-scrollbar">
                  {slideDeck.map((sl, idx) => {
                    const isSel = idx === currentSlideIndex;
                    return (
                      <button
                        key={sl.id}
                        onClick={() => setCurrentSlideIndex(idx)}
                        className={`w-36 shrink-0 p-2.5 rounded-xl border text-left transition-all cursor-pointer space-y-1 ${
                          isSel ? 'bg-amber-950/80 border-amber-500 text-white shadow-md' : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:border-slate-700'
                        }`}
                      >
                        <span className="text-[9px] font-black uppercase text-amber-400 block truncate">
                          Slide #{idx + 1} • {sl.soksTag}
                        </span>
                        <p className="text-[11px] font-bold truncate leading-tight">{sl.title}</p>
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: SMART TELEPROMPTER */}
          {activeSideTab === 'TELEPROMPTER' && (
            <div className="bg-slate-900 p-5 rounded-2xl border border-slate-800 flex-1 flex flex-col justify-between space-y-4">
              
              {/* Teleprompter Top Bar Controls */}
              <div className="space-y-3 border-b border-slate-800 pb-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={() => setIsScrolling(!isScrolling)}
                      className={`px-3 py-1.5 rounded-lg text-xs font-black transition-all cursor-pointer flex items-center gap-1.5 ${
                        isScrolling ? 'bg-amber-500 text-slate-950' : 'bg-indigo-600 text-white'
                      }`}
                    >
                      {isScrolling ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
                      <span>{isScrolling ? 'Hentikan Scroll' : 'Mulai Scroll'}</span>
                    </button>

                    <button
                      onClick={() => {
                        setIsScrolling(false);
                        if (teleprompterRef.current) teleprompterRef.current.scrollTop = 0;
                      }}
                      className="px-2.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold rounded-lg cursor-pointer"
                      title="Reset Ke Atas"
                    >
                      Reset
                    </button>
                  </div>

                  {/* Font Size buttons */}
                  <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-lg border border-slate-800">
                    {(['sm', 'md', 'lg', 'xl'] as const).map((sz) => (
                      <button
                        key={sz}
                        onClick={() => setFontSize(sz)}
                        className={`px-2 py-0.5 text-[10px] font-black uppercase rounded ${
                          fontSize === sz ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-slate-200'
                        }`}
                      >
                        {sz}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Speed Slider */}
                <div className="flex items-center justify-between text-xs text-slate-400 gap-3">
                  <span className="font-bold shrink-0">Kecepatan Auto-Scroll:</span>
                  <input
                    type="range"
                    min="1"
                    max="5"
                    value={scrollSpeed}
                    onChange={(e) => setScrollSpeed(Number(e.target.value))}
                    className="w-full accent-indigo-500 cursor-pointer"
                  />
                  <span className="font-bold text-white font-mono shrink-0">{scrollSpeed}x</span>
                </div>
              </div>

              {/* Scrollable Teleprompter Box */}
              <div
                ref={teleprompterRef}
                className={`flex-1 bg-slate-950 p-5 rounded-2xl border border-slate-800 overflow-y-auto max-h-[420px] transition-all ${
                  fontSize === 'sm' ? 'text-xs' : fontSize === 'md' ? 'text-sm' : fontSize === 'lg' ? 'text-base' : 'text-lg'
                }`}
              >
                {renderFormattedTeleprompter(teleprompterText)}
              </div>

              {/* Teleprompter Text Direct Editor Accordion */}
              <details className="bg-slate-950 p-3 rounded-xl border border-slate-800/80 text-xs">
                <summary className="font-bold text-slate-300 cursor-pointer hover:text-indigo-400">
                  Edit Teks Teleprompter Secara Manual
                </summary>
                <textarea
                  rows={6}
                  value={teleprompterText}
                  onChange={(e) => setTeleprompterText(e.target.value)}
                  className="w-full mt-2 p-2.5 bg-slate-900 border border-slate-800 rounded-lg text-slate-200 font-mono text-xs focus:outline-none focus:border-indigo-500"
                />
              </details>
            </div>
          )}

          {/* TAB 3: AI SCRIPT GENERATOR ASSISTANT */}
          {activeSideTab === 'AI_SCRIPT' && (
            <div className="bg-slate-900 p-5 rounded-2xl border border-slate-800 space-y-4 flex-1">
              <div>
                <span className="text-[10px] font-black uppercase text-amber-400 tracking-wider">
                  S.O.K.S & MKL LitOS v2.0
                </span>
                <h3 className="font-black text-sm text-white">Generator Skrip Video Pembelajaran AI</h3>
                <p className="text-xs text-slate-400 mt-1">
                  Menyusun skrip berdaya serap tinggi berdurasi 3–5 menit sesuai formula 40/30/20 dan petunjuk intonasi vokal.
                </p>
              </div>

              <form onSubmit={(e) => { e.preventDefault(); handleGenerateScript(); }} className="space-y-3 text-xs">
                <div>
                  <label className="block text-slate-300 font-bold mb-1">Mata Pelajaran</label>
                  <input
                    type="text"
                    value={scriptSubject}
                    onChange={(e) => setScriptSubject(e.target.value)}
                    className="w-full p-2.5 bg-slate-950 border border-slate-800 rounded-xl text-white font-bold"
                    required
                  />
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="block text-slate-300 font-bold mb-1">Jenjang PKBM</label>
                    <select
                      value={scriptLevel}
                      onChange={(e: any) => setScriptLevel(e.target.value)}
                      className="w-full p-2.5 bg-slate-950 border border-slate-800 rounded-xl text-white font-bold"
                    >
                      <option value="Paket A">Paket A (SD)</option>
                      <option value="Paket B">Paket B (SMP)</option>
                      <option value="Paket C">Paket C (SMA)</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-slate-300 font-bold mb-1">Durasi Video</label>
                    <select
                      value={scriptDuration}
                      onChange={(e: any) => setScriptDuration(Number(e.target.value))}
                      className="w-full p-2.5 bg-slate-950 border border-slate-800 rounded-xl text-white font-bold"
                    >
                      <option value={3}>3 Menit (Intensif)</option>
                      <option value={5}>5 Menit (Standard)</option>
                      <option value={7}>7 Menit (Mendalam)</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-slate-300 font-bold mb-1">Topik Video / Materi Utama</label>
                  <textarea
                    rows={3}
                    value={scriptTopic}
                    onChange={(e) => setScriptTopic(e.target.value)}
                    placeholder="Contoh: Daur Ulang Sampah & Ekonomi Sirkular Warga"
                    className="w-full p-2.5 bg-slate-950 border border-slate-800 rounded-xl text-white"
                    required
                  />
                </div>

                <button
                  type="submit"
                  disabled={isGeneratingScript}
                  className="w-full py-3 bg-amber-500 hover:bg-amber-600 text-slate-950 font-black text-xs rounded-xl shadow-lg transition-all cursor-pointer flex items-center justify-center gap-2"
                >
                  {isGeneratingScript ? (
                    <>
                      <RefreshCw className="w-4 h-4 animate-spin" />
                      <span>Menyusun Skrip Video S.O.K.S...</span>
                    </>
                  ) : (
                    <>
                      <Zap className="w-4 h-4" />
                      <span>Generate & Muat ke Teleprompter</span>
                    </>
                  )}
                </button>
              </form>
            </div>
          )}

        </div>
      </div>
    </div>
  );
};
