# BSC Cianjur — Unified Project

Repo ini menggabungkan 3 file ZIP yang di-upload menjadi 1 struktur yang rapi.

## Hasil pengecekan

Ketiga ZIP ternyata berisi **2 aplikasi berbeda**, bukan 3 versi dari 1 aplikasi:

| ZIP asli | Isi | Status |
|---|---|---|
| `BSCC-Learning-Center-main.zip` | Landing page publik (versi lama, 27 Jul) | Versi lebih lama dari kolom berikutnya — **di-drop** |
| `pkbm-berkah-sadaya-cianjur.zip` | Landing page publik (versi terbaru, 27 Agu) | **Dipakai sebagai `website/`** |
| `bscc-edu-main__1_.zip` | Portal LMS internal (login Guru/Siswa/Operator/Kepsek + AI Tutor) | Aplikasi terpisah — **dipakai sebagai `lms-portal/`** |

### Kenapa 2 ZIP pertama digabung jadi satu

`BSCC-Learning-Center-main` dan `pkbm-berkah-sadaya-cianjur` adalah snapshot dari proyek yang sama persis (nama komponen, struktur folder, dan `pkbmData.ts` identik). Saya diff semua file — hasilnya `pkbm-berkah-sadaya-cianjur` adalah revisi yang lebih baru dan lebih lengkap di hampir setiap file (HeroSection, ProgramSection, FaqSection, SocialProofSection semua bertambah panjang & fitur, bukan berkurang), jadi itu yang saya jadikan acuan tunggal di `website/`.

**Satu fitur hilang yang perlu kamu tahu:** versi lama punya `AdminGalleryUploadModal.tsx` — modal admin untuk upload foto ke galeri sekaligus kirim webhook ke social media otomatis. Fitur ini sudah tidak ada di versi baru, digantikan tombol WhatsApp mengambang. Saya **tidak** mengembalikannya secara sepihak karena kelihatannya sengaja diganti — tapi kalau kamu masih butuh fitur upload+webhook itu, bilang saja, saya bisa portingkan kembali ke `website/`.

### Kenapa `bscc-edu-main` TIDAK digabung jadi satu codebase dengan website

Ini bukan versi lain dari website — ini aplikasi LMS terpisah:
- Punya `server.ts` (backend Express) yang website tidak punya
- Dependency berbeda (pakai `recharts` untuk dashboard)
- Struktur totally berbeda: `Login.tsx`, `GuruPortal`, `SiswaPortal`, `OperatorPortal`, `KepalaSekolahDashboard`, `AISmartTutor`, `StudioVideoGuru`

Tapi keduanya memang **saling terhubung secara desain**: di `website/src/components/Header.tsx` ada link nav `#vokasi-lms` bertuliskan "Portal {namaLms}" — ini mengarah ke aplikasi `lms-portal/`. Jadi struktur monorepo dengan 2 folder terpisah (`website/` + `lms-portal/`) adalah cara paling aman untuk "menyatukan" tanpa merusak arsitektur masing-masing — keduanya di-deploy sebagai 2 aplikasi/URL terpisah, saling link.

## Struktur

```
bsc-cianjur/
├── website/       # Landing page publik + form pendaftaran (React + Vite)
└── lms-portal/     # Portal LMS internal "BSC EduSetara" (React + Vite + Express server.ts)
```

## Verifikasi yang sudah dilakukan
- Diff penuh semua file `src/` antara 2 versi website — dikonfirmasi tidak ada import yang menggantung ke komponen yang sudah dihapus (`AdminGalleryUploadModal`).
- `.env.example` dan `metadata.json` dicek konsisten antar proyek.
- **Belum dijalankan** `npm install` / `tsc --noEmit` karena sandbox ini tidak ada akses jaringan — jalankan `npm install && npm run lint` di masing-masing folder sebelum deploy untuk memastikan tidak ada error TypeScript.

## Menjalankan

```bash
cd website && npm install && npm run dev      # landing page, port 3000
cd lms-portal && npm install && npm run dev   # portal LMS (tsx server.ts)
```

Masing-masing butuh `GEMINI_API_KEY` sendiri di `.env.local` (lihat `.env.example`).
