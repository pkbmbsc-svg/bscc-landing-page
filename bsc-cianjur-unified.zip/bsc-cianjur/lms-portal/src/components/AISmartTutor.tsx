import React, { useState, useRef, useEffect } from 'react';
import { 
  Bot, Send, Sparkles, HelpCircle, BookOpen, Volume2, VolumeX, 
  Copy, Check, RefreshCw, MessageSquare, Lightbulb, Compass, Heart, Award
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { Lesson } from '../types';

interface Message {
  id: string;
  sender: 'user' | 'tutor';
  text: string;
  timestamp: string;
}

interface AISmartTutorProps {
  currentLesson?: Lesson | null;
  onSelectLesson?: (lesson: Lesson) => void;
  compact?: boolean;
}

export const AISmartTutor: React.FC<AISmartTutorProps> = ({ 
  currentLesson, 
  onSelectLesson,
  compact = false 
}) => {
  const { currentUser, lessons } = useApp();
  const selectedPkg = currentUser?.package || 'Paket C';

  // Filter lessons matching student package if no specific lesson is passed
  const studentLessons = lessons.filter(l => l.package === selectedPkg);
  const activeLesson = currentLesson || studentLessons[0] || null;

  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'init-1',
      sender: 'tutor',
      text: `Halo ${currentUser?.name || 'Siswa'}! Saya adalah Tutor AI Kesetaraan berbasis Protokol S.O.K.S & Matriks Kosmo-Linguistik (MKL).\n\nSaya siap mendampingi kamu memahami modul "${activeLesson?.title || 'Pembelajaran PKBM'}" dengan keseimbangan 40% Fakta Ilmiah, 30% Narasi Empati, dan 20% Pertanyaan Reflektif.\n\nAda konsep atau soal yang ingin kita bedah bersama?`,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    }
  ]);

  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [speakingId, setSpeakingId] = useState<string | null>(null);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isLoading]);

  // Update initial message when lesson changes
  useEffect(() => {
    if (activeLesson) {
      setMessages([
        {
          id: `init-${activeLesson.id}`,
          sender: 'tutor',
          text: `Selamat datang di modul **${activeLesson.title}** (${activeLesson.subject} - ${activeLesson.package}).\n\nSaya menggunakan prinsip **Resonansi 40/30/20 MKL**: menyajikan fakta ilmiah yang akurat, narasi penyemangat untuk meredakan cemas, dan pertanyaan reflektif di akhir.\n\nSilakan tanyakan bagian mana dari modul ini yang terasa rumit!`,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        }
      ]);
    }
  }, [activeLesson?.id]);

  // Send message to Gemini API backend
  const handleSendMessage = async (textToSend: string) => {
    if (!textToSend.trim() || isLoading) return;

    const userMsg: Message = {
      id: `user-${Date.now()}`,
      sender: 'user',
      text: textToSend,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setIsLoading(true);

    try {
      // Map existing messages for payload
      const historyPayload = [...messages, userMsg].map(m => ({
        role: m.sender === 'user' ? 'user' : 'assistant',
        text: m.text
      }));

      const res = await fetch('/api/tutor/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          lessonTitle: activeLesson?.title || 'Modul Kesetaraan',
          lessonDescription: activeLesson?.description || '',
          messages: historyPayload
        })
      });

      if (!res.ok) {
        throw new Error('Gagal menghubungi pelayan AI Tutor');
      }

      const data = await res.json();
      const tutorReplyText = data.text || 'Maaf, saya belum dapat memproses jawaban saat ini.';

      const tutorMsg: Message = {
        id: `tutor-${Date.now()}`,
        sender: 'tutor',
        text: tutorReplyText,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };

      setMessages(prev => [...prev, tutorMsg]);
    } catch (err) {
      console.error('AI Tutor API Error:', err);
      // Fallback response built according to 40/30/20 MKL rule
      const fallbackMsg: Message = {
        id: `tutor-fb-${Date.now()}`,
        sender: 'tutor',
        text: `**40% Fakta & Konsep Kunci:**\nMateri "${activeLesson?.title || 'Pelajaran'}" membahas pentingnya memahami dasar teori dan penerapannya secara bertahap.\n\n**30% Narasi Empati & Motivasi:**\nJangan berkecil hati jika menemui kesulitan! Belajar di pendidikan kesetaraan adalah bukti keberanianmu membangun masa depan yang lebih baik.\n\n**20% Pertanyaan Reflektif:**\nBagaimana kamu bisa menerapkan konsep ini dalam kegiatan usahamu atau kehidupan sehari-hari?`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };
      setMessages(prev => [...prev, fallbackMsg]);
    } finally {
      setIsLoading(false);
    }
  };

  // Text-to-Speech Handler
  const handleSpeak = (id: string, text: string) => {
    if (!('speechSynthesis' in window)) return;

    if (speakingId === id) {
      window.speechSynthesis.cancel();
      setSpeakingId(null);
      return;
    }

    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text.replace(/[*_#]/g, ''));
    utterance.lang = 'id-ID';
    utterance.onend = () => setSpeakingId(null);
    utterance.onerror = () => setSpeakingId(null);

    setSpeakingId(id);
    window.speechSynthesis.speak(utterance);
  };

  // Copy Message Handler
  const handleCopy = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <div className={`bg-white border border-slate-200 rounded-2xl shadow-sm overflow-hidden flex flex-col ${
      compact ? 'h-[500px]' : 'h-[650px]'
    }`}>
      {/* Header Bar */}
      <div className="bg-slate-900 text-white p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 shrink-0">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-indigo-500 to-purple-500 flex items-center justify-center text-white shadow-md shadow-indigo-500/20">
            <Bot className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="font-black text-sm text-white">AI Smart Tutor (S.O.K.S & MKL)</h3>
              <span className="text-[9px] font-extrabold uppercase bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 px-2 py-0.5 rounded-full flex items-center gap-1">
                <Sparkles className="w-2.5 h-2.5" /> 40/30/20 Resonan
              </span>
            </div>
            <p className="text-[11px] text-slate-400">Mentor Belajar Kesetaraan & Pembimbing Kuis</p>
          </div>
        </div>

        {/* Lesson Switcher dropdown if passed */}
        {studentLessons.length > 0 && onSelectLesson && (
          <div className="flex items-center gap-2 text-xs">
            <label className="text-[10px] text-slate-400 font-bold uppercase shrink-0">Modul:</label>
            <select
              value={activeLesson?.id || ''}
              onChange={(e) => {
                const found = studentLessons.find(l => l.id === e.target.value);
                if (found) onSelectLesson(found);
              }}
              className="bg-slate-800 text-slate-200 border border-slate-700 rounded-lg px-2.5 py-1 text-xs focus:outline-hidden font-bold max-w-[200px] truncate"
            >
              {studentLessons.map(l => (
                <option key={l.id} value={l.id}>
                  {l.subject}: {l.title}
                </option>
              ))}
            </select>
          </div>
        )}
      </div>

      {/* MKL Ratio Principle Bar */}
      <div className="bg-indigo-950 text-indigo-200 px-4 py-2 border-b border-indigo-900/80 flex items-center justify-between text-[11px] font-bold shrink-0 overflow-x-auto">
        <div className="flex items-center gap-4 whitespace-nowrap">
          <span className="flex items-center gap-1 text-amber-300">
            <Lightbulb className="w-3.5 h-3.5" /> 40% Fakta & Teori
          </span>
          <span className="flex items-center gap-1 text-emerald-300">
            <Heart className="w-3.5 h-3.5" /> 30% Narasi Empati
          </span>
          <span className="flex items-center gap-1 text-indigo-300">
            <Compass className="w-3.5 h-3.5" /> 20% Pertanyaan Reflektif
          </span>
        </div>
        <span className="text-[10px] text-slate-400 uppercase tracking-widest hidden md:inline">Gemini 3.6 Flash</span>
      </div>

      {/* Messages Scroll Area */}
      <div className="flex-1 p-4 overflow-y-auto space-y-4 bg-slate-50/50">
        {messages.map((msg) => {
          const isUser = msg.sender === 'user';
          return (
            <div
              key={msg.id}
              className={`flex gap-3 max-w-[90%] sm:max-w-[80%] ${
                isUser ? 'ml-auto flex-row-reverse' : 'mr-auto flex-row'
              }`}
            >
              <div className={`w-8 h-8 rounded-xl flex items-center justify-center shrink-0 text-xs font-bold ${
                isUser 
                  ? 'bg-amber-500 text-white shadow-xs' 
                  : 'bg-indigo-600 text-white shadow-md shadow-indigo-200'
              }`}>
                {isUser ? currentUser?.name?.charAt(0) || 'S' : <Bot className="w-4 h-4" />}
              </div>

              <div className="space-y-1">
                <div className={`p-4 rounded-2xl text-xs leading-relaxed space-y-2 shadow-xs ${
                  isUser
                    ? 'bg-amber-500 text-white rounded-tr-none font-medium'
                    : 'bg-white text-slate-800 border border-slate-200 rounded-tl-none'
                }`}>
                  <p className="whitespace-pre-line font-sans">{msg.text}</p>

                  {/* If Tutor response, render MKL Badge Breakdown */}
                  {!isUser && (
                    <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-[10px] text-slate-400">
                      <span className="flex items-center gap-1 text-indigo-600 font-bold">
                        <Award className="w-3 h-3" /> Formulasi Artikel Resonan (MKL)
                      </span>
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => handleSpeak(msg.id, msg.text)}
                          className="hover:text-indigo-600 p-1 rounded-md transition-all cursor-pointer flex items-center gap-1"
                          title="Dengarkan Suara Tutor"
                        >
                          {speakingId === msg.id ? <VolumeX className="w-3.5 h-3.5 text-rose-500" /> : <Volume2 className="w-3.5 h-3.5" />}
                        </button>
                        <button
                          onClick={() => handleCopy(msg.id, msg.text)}
                          className="hover:text-indigo-600 p-1 rounded-md transition-all cursor-pointer flex items-center gap-1"
                          title="Salin Pesan"
                        >
                          {copiedId === msg.id ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                        </button>
                      </div>
                    </div>
                  )}
                </div>

                <div className={`text-[9px] text-slate-400 px-1 font-mono ${isUser ? 'text-right' : 'text-left'}`}>
                  {msg.timestamp}
                </div>
              </div>
            </div>
          );
        })}

        {isLoading && (
          <div className="flex gap-3 max-w-[80%] mr-auto items-center">
            <div className="w-8 h-8 rounded-xl bg-indigo-600 text-white flex items-center justify-center shrink-0">
              <Bot className="w-4 h-4 animate-spin" />
            </div>
            <div className="p-3 bg-white border border-slate-200 rounded-2xl rounded-tl-none text-xs text-indigo-700 font-bold flex items-center gap-2 shadow-xs">
              <Sparkles className="w-4 h-4 text-indigo-500 animate-pulse" />
              <span>S.O.K.S AI Tutor sedang memformulasikan tanggapan 40/30/20...</span>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Suggested Quick Action Prompts */}
      <div className="px-3 py-2 bg-slate-100 border-t border-slate-200 flex items-center gap-2 overflow-x-auto no-scrollbar shrink-0">
        <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest shrink-0">Aksi Cepat:</span>
        <button
          onClick={() => handleSendMessage("Bisa rangkumkan isi modul ini menggunakan prinsip 40% Fakta, 30% Empati, dan 20% Pertanyaan Reflektif?")}
          className="px-2.5 py-1 text-[10px] font-bold text-indigo-700 bg-white hover:bg-indigo-50 border border-indigo-200 rounded-lg transition-all cursor-pointer shrink-0"
        >
          📋 Rangkuman 40/30/20
        </button>
        <button
          onClick={() => handleSendMessage("Berikan saya petunjuk (hint) untuk menjawab soal kuis modul ini tanpa memberikan kunci jawabannya secara langsung.")}
          className="px-2.5 py-1 text-[10px] font-bold text-amber-700 bg-white hover:bg-amber-50 border border-amber-200 rounded-lg transition-all cursor-pointer shrink-0"
        >
          💡 Petunjuk Kuis
        </button>
        <button
          onClick={() => handleSendMessage("Saya merasa cemas dan ragu bisa menyelesaikan modul ini. Bisakah Tutor membimbing dan memotivasi saya?")}
          className="px-2.5 py-1 text-[10px] font-bold text-emerald-700 bg-white hover:bg-emerald-50 border border-emerald-200 rounded-lg transition-all cursor-pointer shrink-0"
        >
          🌿 Bimbingan Pereda Cemas
        </button>
        <button
          onClick={() => handleSendMessage("Bagaimana penerapan materi ini dalam dunia kerja atau karya usaha nyata?")}
          className="px-2.5 py-1 text-[10px] font-bold text-purple-700 bg-white hover:bg-purple-50 border border-purple-200 rounded-lg transition-all cursor-pointer shrink-0"
        >
          ⚡ Penerapan Vokasi
        </button>
      </div>

      {/* Input Form */}
      <form
        onSubmit={(e) => {
          e.preventDefault();
          handleSendMessage(input);
        }}
        className="p-3 bg-white border-t border-slate-200 flex items-center gap-2 shrink-0"
      >
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Tanyakan materi, konsep, atau petunjuk kuis di sini..."
          disabled={isLoading}
          className="flex-1 px-3.5 py-2.5 border border-slate-200 rounded-xl text-xs bg-slate-50 focus:bg-white focus:outline-hidden focus:border-indigo-500 transition-all text-slate-800"
        />
        <button
          type="submit"
          disabled={!input.trim() || isLoading}
          className={`p-2.5 rounded-xl text-white font-bold transition-all flex items-center justify-center shrink-0 cursor-pointer ${
            input.trim() && !isLoading
              ? 'bg-indigo-600 hover:bg-indigo-700 shadow-md shadow-indigo-100'
              : 'bg-slate-200 text-slate-400 cursor-not-allowed'
          }`}
        >
          <Send className="w-4 h-4" />
        </button>
      </form>
    </div>
  );
};
